% Comparison betwee Blind Test and Global RANS
clear 
close all
Global

addpath ./Functions
addpath ./BT1_DATA
addpath ./BT_Results
addpath ./clcdalpha
folder = './Images/';
up_BC = 'Stress_free';
corr_block = 1.08; %or 1.08
Tip_Speed_Ratio = [6];

for i=1:length(Tip_Speed_Ratio)
    TSR = [Tip_Speed_Ratio(i)/corr_block];
    folder = strcat(['./BT_Results/TSR_',num2str(TSR),num2str(date),'/corrected_velocity/',up_BC,'/']);    
    load(strcat([folder,'Res_corr_TSR','.mat']));
    Lr = 0.5;
    
    if TSR==3
        Nr = length(Res.Ux(:,1));
        Pre_processing
        openfig('TSR3_U_Data_R1.fig');
        axh = findobj(gcf,'Type','Axes');
        Axes = get(axh(1),'Children');
        r = get(Axes,'XData');
        Ux_val_ref = get(Axes,'YData');
        ob = gcf;
        Chebyshev
        figure('units','normalized','outerposition',[0 0 1 0.8]);
        plot(r{3},Ux_val_ref{3},'k.','markersize',15);axis tight
        hold on
        plot(r{2},Ux_val_ref{2},'k>','markersize',10);axis tight
        hold on
        plot(r{1},Ux_val_ref{1},'k*','markersize',10);
        hold on
        plot(r_pos{1},Ux_val{1},'r.','markersize',15);
        hold on
        plot(r_pos{2},Ux_val{2},'r>','markersize',10);
        hold on
        plot(r_pos{3},Ux_val{3},'r*','markersize',10);
        leg = legend('1D BT','3D BT','5D BT','1D RANS','3D RANS','5D RANS');
        set(leg,'location','southeast');
        Plot_options([],'Ux/U_{\infty}','TSR = 3');
        savefig(gcf,strcat([folder,'BT_vs_RANS_',num2str(TSR)],'.fig'));% 
        saveas(gcf,strcat([folder,'BT_vs_RANS_',num2str(TSR)],'.png'));%         
    end
    
%     if TSR == 6
        Nr = length(Res.Ux(:,1));
        Lr = 0.3;
        Pre_processing
        openfig('TSR6_U_Data_R1.fig');
        axh = findobj(gcf,'Type','Axes');
        Axes = get(axh(1),'Children');
        r = get(Axes,'XData');
        Ux_val_ref = get(Axes,'YData');
        ob = gcf;
        Chebyshev
        Ind_1=min(find(Matrices.XmGLC(1,:)-(x_T+1)<=0));
        Ind_3=min(find(Matrices.XmGLC(1,:)-(x_T+3)<=0));
        Ind_5=min(find(Matrices.XmGLC(1,:)-(x_T+5)<=0));
        figure('units','normalized','outerposition',[0 0 1 0.8]);
        plot(r{3},Ux_val_ref{3},'k.','markersize',15);axis tight
        hold on
        plot(r{2},Ux_val_ref{2},'k>','markersize',10);axis tight
        hold on
        plot(r{1},Ux_val_ref{1},'k*','markersize',10);
        hold on
        plot(Matrices.RmGLC(:,1),Res.Ux(:,36),'r.','markersize',15);
        hold on
        plot(Matrices.RmGLC(:,1),Res.Ux(:,Ind_3),'r>','markersize',10);
        hold on
        plot(Matrices.RmGLC(:,1),Res.Ux(:,Ind_5),'r*','markersize',10);
        leg = legend('1D BT','3D BT','5D BT','1D RANS','3D RANS','5D RANS');
        set(leg,'location','southeast');
        Plot_options([],'Ux/U_{\infty}',strcat(['TSR = ',num2str(TSR)]));
        savefig(gcf,strcat([folder,'BT_vs_RANS_',num2str(TSR)],'.fig'));% 
        saveas(gcf,strcat([folder,'BT_vs_RANS_',num2str(TSR)],'.png'));%    
%     end
    
    if TSR == 10
        Nr = length(Res.Ux(:,1));
        Lr = 0.8;
        Pre_processing
        
        openfig('TSR10_U_Data_R1.fig');
        axh = findobj(gcf,'Type','Axes');
        Axes = get(axh(1),'Children');
        r = get(Axes,'XData');
        Ux_val_ref = get(Axes,'YData');
        ob = gcf;
        Chebyshev
        figure('units','normalized','outerposition',[0 0 1 0.8]);
        plot(r{3},Ux_val_ref{3},'k.','markersize',15);axis tight
        hold on
        plot(r{2},Ux_val_ref{2},'k>','markersize',10);axis tight
        hold on
        plot(r{1},Ux_val_ref{1},'k*','markersize',10);
        hold on
        plot(Matrices.RmGLC(:,1),Res.Ux(:,Ind_1),'r.','markersize',15);
        hold on
        plot(Matrices.RmGLC(:,1),Res.Ux(:,Ind_3),'r>','markersize',10);
        hold on
        plot(Matrices.RmGLC(:,1),Res.Ux(:,Ind_5),'r*','markersize',10);
        leg = legend('1D BT','3D BT','5D BT','1D RANS','3D RANS','5D RANS');
        set(leg,'location','southeast');
        Plot_options([],'Ux/U_{\infty}','TSR = 10');
        savefig(gcf,strcat([folder,'BT_vs_RANS_',num2str(TSR)],'.fig'));% 
        saveas(gcf,strcat([folder,'BT_vs_RANS_',num2str(TSR)],'.png'));%    
    end
end