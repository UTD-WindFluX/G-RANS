%TKE_plot_standalone returns the plot of the Turbulent Kinetic Energy at 1,
%3 and 5 diameters downstream the turbine.
clear 
close all
clc
addpath ./Functions
addpath ./BT_Results
Global
up_BC = 'Slip';
initial_profile = 'Constant';
Pre_processing
folder = strcat(['./BT1_Dataset_new/RANS',num2str(TSR)]);
load(strcat([folder,'.mat']));
%%
Ind_1=min(find(Matrices.XmGLC(1,:)-(x_T+1)<=0));
Ind_3=min(find(Matrices.XmGLC(1,:)-(x_T+3)<=0));
Ind_5=min(find(Matrices.XmGLC(1,:)-(x_T+5)<=0));
r = [Matrices.RmGLC(:,1);-flip(Matrices.RmGLC(:,1))];
figure('units','normalized','outerposition',[0 0 1 1]);
semilogy(r,[Res.tke(:,Ind_1);flip(Res.tke(:,Ind_1))],'o-','color',[.85 .3 .1],'markersize',8,'markerfacecolor',[.85 .3 .1],'linewidth',2);
hold on
semilogy(r,[Res.tke(:,Ind_3);flip(Res.tke(:,Ind_3))],'o-','color',[.93 .69 .13],'markersize',8,'markerfacecolor',[.93 .69 .13],'linewidth',2);
hold on
semilogy(r,[Res.tke(:,Ind_5);flip(Res.tke(:,Ind_5))],'o-','color',[.49 .18 .56],'markersize',8,'markerfacecolor',[.49 .18 .56],'linewidth',2);
leg = legend('1D GRANS','3D GRANS','5D GRANS');
set(leg,'location','northeast');
Plot_options('\it r/D','\it U_x/U_{\infty}',strcat(['TSR = ',num2str(TSR)]));
axis tight
% savefig(gcf,strcat(['./BT_Results/BT1_Dataset_final/Tke_',num2str(TSR)],'.fig'));% 
% saveas(gcf,strcat(['./BT_Results/BT1_Dataset_final/Tke_',num2str(TSR)],'.png'));%