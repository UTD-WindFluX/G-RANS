% Comparison betwee Parabolic and Global RANS
clear 
close all
Global

addpath ./Functions
addpath ./Results_Plots_Parabolic_RANS
addpath ./BT_Results
addpath ./clcdalpha
folder = './Images/';
Tip_Speed_Ratio = [6];

for i=1:length(Tip_Speed_Ratio)
    TSR = [Tip_Speed_Ratio(i)];
    Nr = 40;
    Lr = 0.5;
    Pre_processing
    folder = strcat(['./BT_Results/TSR_',num2str(TSR),'/Slip/']);    
    load(strcat([folder,'Res_corr_TSR','.mat']));

    if TSR==3
        Pre_processing
        openfig('Ux_TSR3_R3_BC.fig');
        axh = findobj(gcf,'Type','Axes');
        Axes = get(axh(1),'Children');
        r = get(Axes,'XData');
        Ux_val_ref = get(Axes,'YData');
        ob = gcf;
        Chebyshev_parabolic
        figure('units','normalized','outerposition',[0 0 1 0.8]);
        plot(r{3},Ux_val_ref{3},'b.','markersize',15);axis tight
        hold on
        plot(r{2},Ux_val_ref{2},'b>','markersize',10);axis tight
        hold on
        plot(r{1},Ux_val_ref{1},'b*','markersize',10);
        hold on
        plot(r_pos{1},Ux_val{1},'r.','markersize',15);
        hold on
        plot(r_pos{2},Ux_val{2},'r>','markersize',10);
        hold on
        plot(r_pos{3},Ux_val{3},'r*','markersize',10);
        leg = legend('1D Par.','3D Par.','5D Par.','1D Glob.','3D Glob.','5D Glob.');
        set(leg,'location','southeast');
        Plot_options([],'Ux/U_{\infty}','TSR = 3');
        axis ([0 rmax 0.5 1.1]);
        savefig(gcf,strcat([folder,'Parab_vs_Global_',num2str(TSR)],'.fig'));%
        saveas(gcf,strcat([folder,'Parab_vs_Global_',num2str(TSR)],'.png'));%
    end
    
    if TSR == 6
        openfig('Ux_TSR6_R3_BC.fig');
        axh = findobj(gcf,'Type','Axes');
        Axes = get(axh(1),'Children');
        r = get(Axes,'XData');
        Ux_val_ref = get(Axes,'YData');
        ob = gcf;
        Chebyshev_parabolic
        figure('units','normalized','outerposition',[0 0 1 0.8]);
        plot(r{3},Ux_val_ref{3},'b.','markersize',15);axis tight
        hold on
        plot(r{2},Ux_val_ref{2},'b>','markersize',10);axis tight
        hold on
        plot(r{1},Ux_val_ref{1},'b*','markersize',10);
        hold on
        plot(r_pos{1},Ux_val{1},'r.','markersize',15);
        hold on
        plot(r_pos{2},Ux_val{2},'r>','markersize',10);
        hold on
        plot(r_pos{3},Ux_val{3},'r*','markersize',10);
        leg = legend('1D Par.','3D Par.','5D Par.','1D Glob.','3D Glob.','5D Glob.');
        set(leg,'location','southeast');
        Plot_options([],'Ux/U_{\infty}','TSR = 6');
        axis ([0 rmax 0.5 1.3])
%         savefig(gcf,strcat([folder,'Parab_vs_Global_',num2str(TSR)],'.fig'));%
%         saveas(gcf,strcat([folder,'Parab_vs_Global_',num2str(TSR)],'.png'));%    
    end
    
    if TSR == 10
        Nr = length(Res.Ux(:,1));
        Pre_processing
        openfig('Ux_TSR10_R2_BC.fig');
        axh = findobj(gcf,'Type','Axes');
        Axes = get(axh(1),'Children');
        r = get(Axes,'XData');
        Ux_val_ref = get(Axes,'YData');
        ob = gcf;
        Chebyshev_parabolic
        figure('units','normalized','outerposition',[0 0 1 0.8]);
        plot(r{3},Ux_val_ref{3},'b.','markersize',15);axis tight
        hold on
        plot(r{2},Ux_val_ref{2},'b>','markersize',10);axis tight
        hold on
        plot(r{1},Ux_val_ref{1},'b*','markersize',10);
        hold on
        plot(r_pos{1},Ux_val{1},'r.','markersize',15);
        hold on
        plot(r_pos{2},Ux_val{2},'r>','markersize',10);
        hold on
        plot(r_pos{3},Ux_val{3},'r*','markersize',10);
        leg = legend('1D Par.','3D Par.','5D Par.','1D Glob.','3D Glob.','5D Glob.');
        set(leg,'location','southeast');
        Plot_options([],'Ux/U_{\infty}','TSR = 10');
        axis ([0 rmax 0.2 1.3])
        savefig(gcf,strcat([folder,'Parab_vs_Global_',num2str(TSR)],'.fig'));%
        saveas(gcf,strcat([folder,'Parab_vs_Global_',num2str(TSR)],'.png'));%    
    end
clear Res
end