in = Nx; out = Nx:-1:1; %axial indeces of inlet and outlet boundaries
for i=1:Nx
    X=Matrices.XmGLC(1,i:in);
    Ux_inlet = RANS.Ux(:,in); Ux_outlet = RANS.Ux(:,i);
    Ur_up = RANS.Ur(1,i:in);Ur_outlet=RANS.Ur(:,i);Ur_inlet=RANS.Ur(:,in);
    
    Nu_in=1/Reynolds+NuT(:,in); Nu_up=1/Reynolds+NuT(1,i:in); Nu_out=1/Reynolds+NuT(:,i);
    S_in=S_S{1,3}(:,in); S_up=S_S{1,1}(1,i:in); S_out=S_S{1,3}(:,i);
    tau_in=sqrt(Nu_in.*S_in).'*IWr*sqrt(Nu_in.*S_in); 
    tau_up=max(R)*sqrt(Nu_up.*S_up)*IWx(i:in,i:in)*sqrt(Nu_up.*S_up).'; 
    tau_out=sqrt(Nu_out.*S_out).'*IWr*sqrt(Nu_out.*S_out);
    tau(i) = tau_up+tau_in+tau_out;
    
    p_up=RANS.p(1,i:in);
%     P(i) = max(R)*sqrt(p_up)*IWx(i:in,i:in)*sqrt(p_up).';
    P(i)=-max(R)*trapz(X,p_up,2);
    Qrin_loc(i) = sqrt(Ux_inlet.*Ur_inlet).'*IWr*sqrt(Ux_inlet.*Ur_inlet);
    Qr_outlet_loc(i) = sqrt(Ux_outlet.*Ur_outlet).'*IWr*sqrt(Ux_outlet.*Ur_outlet);
%     Qr_up_loc(i) = max(R)*sqrt(Ur_up.^2)*IWx(i:in,i:in)*sqrt(Ur_up.^2).';
    Qr_up_loc(i)=-max(R)*trapz(X,Ur_up.^2,2);
    Qrout_loc(i) = Qr_up_loc(i) + Qr_outlet_loc(i);
    Qrin_loc(i) = sqrt(Ux_inlet.*Ut_inlet).'*IWr*sqrt(Ux_inlet.*Ut_inlet);
    Bal_r(i) = Qrout_loc(i)+tau(i)+P(i);
end
%%
Balance_r = figure('units','normalized','outerposition',[0 0 0.5 1]);set(gcf,'Color','White');
plot(Matrices.XmGLC(1,:),Qrin_loc,'k*-');
hold on
plot(Matrices.XmGLC(1,:),Qrout_loc,'k+-')
hold on
plot(Matrices.XmGLC(1,:),tau,'k<-')
hold on
plot(Matrices.XmGLC(1,:),P,'ko-')
hold on
plot(Matrices.XmGLC(1,:),Bal_r,'k^-')
set(gco,'markersize',20);
leg = legend('Q_{in}','Q_{out}','Viscosity','Pressure','Total');
set(leg,'location','best','fontsize',14);
Plot_options('x/D','Q','Q_{r}');
% savefig(Balance_r,strcat([folder,'Bal_r']));
% saveas(Balance_r,strcat([folder,'Bal_r','.bmp']));