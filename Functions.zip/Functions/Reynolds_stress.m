function SS = Reynolds_stress(qc);
Global
Dx = Matrices.D1_X;
Dr = Matrices.D1_r;
invrGLC=1./Matrices.RmGLC;invrGLC(end,:)=invR_max;
invrGLCc = diag(reshape(invrGLC.',Nx*Nr,1));

Ur=qc(1:Nx*Nr); Ut=qc(Nx*Nr+1:2*Nx*Nr); Ux=qc(2*Nx*Nr+1:3*Nx*Nr);

SS=cell(3,3);
SS_11=Dr*Ur;      SS{1,1}=reshape(SS_11,Nx,Nr).';
SS_22=invrGLCc*Ut; SS{2,2}=reshape(SS_22,Nx,Nr).';
SS_33=Dx*Ux; SS{3,3}=reshape(SS_33,Nx,Nr).';

SS_12=Dr*Ut-invrGLCc*Ut;        SS{1,2}=reshape(SS_12,Nx,Nr).';SS{2,1}=SS{1,2};
SS_13=Dr*Ux + Dx*Ur;        SS{1,3}=reshape(SS_13,Nx,Nr).';SS{3,1}=SS{1,3};
SS_23=Dx*Ut; SS{2,3}=reshape(SS_23,Nx,Nr).';SS{3,2}=SS{2,3};
end