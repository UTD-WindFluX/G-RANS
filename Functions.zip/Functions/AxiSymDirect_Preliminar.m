function qc0=AxiSymDirect_Preliminar(NuT,qc)
    Global
   
    SquartoL2=errmin*10;%norm initialization
    nIte=0;

    while (SquartoL2>errmin)
        [JA,F] = JacobianSponge_AD(qc,NuT);%jacobain and residuals calculator

        deltaq=-JA\F;%unknowns variation
        qc=qc+deltaq;%new guess
%         Ur=qc(1:Nx*Nr); Ur=reshape(Ur,Nx,Nr)';
%         Ut=qc(Nx*Nr+1:Nx*Nr*2); Ut=reshape(Ut,Nx,Nr)';
%         Ux=qc(2*Nx*Nr+1:Nx*Nr*3); Ux=reshape(Ux,Nx,Nr)';
%         XmGLC = Matrices.XmGLC; RmGLC = Matrices.RmGLC;
%         
%         fig_Ur=figure;surf(XmGLC,RmGLC,Ur);title(['U_r - Iteration ',num2str(nIte)]);xlabel('x/D');ylabel('r/D');drawnow
% 
%         fig_Ut=figure;surf(XmGLC,RmGLC,Ut);title(['U_t - Iteration ',num2str(nIte)]);xlabel('x/D');ylabel('r/D');drawnow
% 
%         fig_Ux=figure;surf(XmGLC,RmGLC,Ux);title(['U_x - Iteration ',num2str(nIte)]);xlabel('x/D');ylabel('r/D');drawnow
        [SquartoL2]=normaL2(F);%norm of the unknown vector variation
        display(['SqL2=',num2str(SquartoL2)]);    

        nIte=nIte+1;
        if SquartoL2>10 || nIte>maxIter
            error('No convergence');
        end   
    end
    qc0=qc;
end
    
       
    