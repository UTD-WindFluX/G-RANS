%smoothing matrix
function M=Mat_smooth_Gauss(sigma)
    Global
    XmGLC = Matrices.XmGLC; RmGLC = Matrices.RmGLC;
    if sigma>0
        %integration weights
        dX=-Int_weight(XmGLC(1,:));
        dR=-Int_weight(RmGLC(:,1));
        dV=repmat(dX,Nr,1).*repmat(dR,1,Nx).*RmGLC;
        dVc=reshape(dV',Nx*Nr,1);
        M=zeros(Nx*Nr);
        for j=1:Nx
            for i=1:Nr
                index=j+(i-1)*Nx;
                x=XmGLC(i,j);r=RmGLC(i,j);%current point position
                G=exp(-(((x-XmGLC).^2+(r-RmGLC).^2)/sigma^2));%gauss function

                Integral=trapz(RmGLC(:,1),trapz(XmGLC(1,:),G.*RmGLC,2));

                w=G/Integral;%gaussian weight

                M(index,:)=reshape(w',Nx*Nr,1).*dVc;

            end
        end
    else
        M=eye(Nx*Nr);
    end
end
  
