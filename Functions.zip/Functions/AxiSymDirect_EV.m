%Newton solver of the RANS field
function [RANS]=AxiSymDirect_EV(NuT_coeff)
    Global
    NuT=NuT_fun(NuT_coeff);
    NuTc=reshape(NuT.',Nx*Nr,1);
    qc0=Initial_field;


    SquartoL2=1e5*errmin;%norm initialization
    nIte=0;

    while (SquartoL2>errmin)
        if nIte==0;
            qc=qc0;
            F_old = zeros(3*Nx*Nr + NxGC*NrGC,1);
            J_old22 = zeros(Nx*Nr);
            J_old23 = zeros(Nx*Nr);
            J_old32 = zeros(Nx*Nr);
            J_old33 = zeros(Nx*Nr);
            J_old.Ft_Ut = J_old22; J_old.Ft_Ux = J_old23; 
            J_old.Fx_Ut = J_old32; J_old.Fx_Ux = J_old33;
        end

        [JA,F] = JacobianSponge_AD(qc,NuT,J_old,F_old);%jacobain and residuals calculator

        deltaq=-JA\F;%unknowns variation
        qc=qc+deltaq;%new guess (reduced step length)
        
        Ur = reshape(qc(1:Nx*Nr),Nx,Nr).';
        Ut = reshape(qc(Nx*Nr+1:2*Nx*Nr),Nx,Nr).';
        Ux = reshape(qc(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
        VEL = figure('units','normalized','outerposition',[0 0 0.5 1]);set(gcf,'Color','White');
        subplot(3,1,1)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,Ur);
        axis equal; axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp ; colorbar; drawnow
        hold on
        plot_turbine
        Plot_options('x/D','r/D','U_r');title(strcat(['TSR=',num2str(TSR)]));
        subplot(3,1,2)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,Ut);axis equal; axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp;colorbar 
        hold on
        plot_turbine; drawnow
        Plot_options('x/D','r/D','U_{\theta}')
        subplot(3,1,3)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,Ux); axis equal;axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp ;colorbar
        hold on
        plot_turbine; drawnow
        Plot_options('x/D','r/D','U_x')
        

        [SquartoL2]=normaL2(F);%norm of the unknown vector variation
        display(['SqL2=',num2str(SquartoL2)]);    

        nIte=nIte+1;
        Error(nIte) = SquartoL2;
        if SquartoL2>10 || nIte>maxIter
            error('No convergence');
        end   
    end
    %% Calculating converged field
    [JA,F] = JacobianSponge_AD(qc,NuTc,J_old,F_old);%jacobian and residuals calculator

    %% Rearrangment of the results
    Ur=reshape(qc(1:Nx*Nr),Nx,Nr).'; Ut=reshape(qc(Nx*Nr+1:2*Nx*Nr),Nx,Nr).';
    Ux=reshape(qc(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).'; p=reshape(Matrices.MtoL*qc(3*Nx*Nr+1:3*Nx*Nr+NxGC*NrGC),Nx,Nr)';
    
    %% output
    RANS.Ur=Ur;RANS.Ut=Ut;RANS.Ux=Ux;RANS.p=p; RANS.qc=qc;RANS.F=F;
    RANS.L2Err=Error; RANS.Jacobian=JA;RANS.NuT=NuT;           
    