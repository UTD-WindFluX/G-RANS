addpath ./LES_Data
load TRS-7_5-Lam.mat
[XL,RL]=meshgrid(xLES,rLES);
Ux_interp = interp2(XL,RL,Ux_LES,Matrices.XmGLC,Matrices.RmGLC,'cubic');
Ut_interp = interp2(XL,RL,Ut_LES,Matrices.XmGLC,Matrices.RmGLC,'spline');
Ur_interp = interp2(XL,RL,Ur_LES,Matrices.XmGLC,Matrices.RmGLC,'spline');
%% Ux
VEL_LES_x = figure('units','normalized','outerposition',[0 0 0.5 0.7]);set(gcf,'Color','White');
subplot(3,1,1)
pcolor(xLES,rLES,Ux_LES)
axis equal; axis ([0 max(xLES) 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
hold on
plot_turbine
Plot_options([],'r/D','U_x LES');

subplot(3,1,2)
pcolor(Matrices.XmGLC,Matrices.RmGLC,RANS.Ux)
axis equal; axis ([0 max(xLES) 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
hold on
plot_turbine
Plot_options([],'r/D','U_x RANS');

subplot(3,1,3)
pcolor(Matrices.XmGLC,Matrices.RmGLC,RANS.Ux-Ux_interp)
axis equal; axis ([0 max(xLES) 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
hold on
plot_turbine
Plot_options('x/D','r/D','U_x diff.');
savefig(VEL_LES_x,strcat([folder,'/Vel_LES_x.fig']));
saveas(VEL_LES_x,strcat([folder,'/Vel_LES_x','.png']));
%% Ut
% VEL_LES_t = figure('units','normalized','outerposition',[0 0 0.5 0.7]);set(gcf,'Color','White');
% subplot(3,1,1)
% pcolor(xLES,rLES,Ut_LES)
% axis equal; axis ([xmin xmax 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
% hold on
% plot_turbine
% Plot_options([],'r/D','U_t LES');
% 
% subplot(3,1,2)
% pcolor(xLES,rLES,-Ut_interp)
% axis equal; axis ([xmin xmax 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
% hold on
% plot_turbine
% Plot_options([],'r/D','U_t RANS');
% 
% subplot(3,1,3)
% pcolor(xLES,rLES,Ut_LES+Ut_interp)
% axis equal; axis ([xmin xmax 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
% hold on
% plot_turbine
% Plot_options('x/D','r/D','U_{\theta} diff.');
% savefig(VEL_LES_t,strcat([folder,'/Vel_LES_t.fig']));
% saveas(VEL_LES_t,strcat([folder,'/Vel_LES_t','.png']));
% %% Ur
% VEL_LES_r = figure('units','normalized','outerposition',[0 0 0.5 0.7]);set(gcf,'Color','White');
% subplot(3,1,1)
% pcolor(xLES,rLES,Ur_LES)
% axis equal; axis ([xmin xmax 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
% hold on
% plot_turbine
% Plot_options([],'r/D','U_r LES');
% 
% subplot(3,1,2)
% pcolor(xLES,rLES,Ur_interp)
% axis equal; axis ([xmin xmax 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
% hold on
% plot_turbine
% Plot_options([],'r/D','U_r RANS');
% 
% subplot(3,1,3)
% pcolor(xLES,rLES,Ur_LES-Ur_interp)
% axis equal; axis ([xmin xmax 0 max(rLES)]); colormap coolwarm; shading interp ; colorbar
% hold on
% plot_turbine
% Plot_options('x/D','r/D','U_r diff.');
% savefig(VEL_LES_r,strcat([folder,'/Vel_LES_r.fig']));
% saveas(VEL_LES_r,strcat([folder,'/Vel_LES_r','.png']));