    Optimization.options=optimoptions(@fmincon,'Algorithm','sqp','GradObj','on','Diagnostics','on','Display','iter-detailed','TolCon',1E-20,'TolFun',1E-06,'TolX',1E-10);
    qc_initial=[];
    Optimization.Obj_Fun=[];
    Optimization.Grad=[];        
   
    switch Turbulence_model
        case 'ML'
            Optimization.ML=[];
            Optimization.NuT0=[];
            
            BL_approx=1;
            Mat_clean=eye(Nx*Nr);
        %   Mat_clean(Nx*Nr-Nx*2:end,:)=0;
            
            Matrices.M_smooth=Mat_smooth_Gauss(NuT_smooth_par);%smoothing matrix
            
            NuT0_max=0.1;
            ML_max=0.5;
            
            %apply only for the 4PL
            ML0_max=0.3;
            ML_inf_max=0.3;
            k_max=10;
            
            NuT0_guess=[];%initial guess on eddy viscosity due to incoming turbulence
            
            switch DoFs
                case 1
                    M_LB=-eye(DoFs+1);
                    M_UB=eye(2);
                    NuT0_guess=0.001;
                    ML_guess=0.01;
                    Optimization.b_constr=[zeros(DoFs+1,1);NuT0_max;ML_max];%contraints vector
                    Optimization.M_scaling=diag([1000;100]);
                case 2
                    M_LB=-eye(DoFs+1);
                    M_UB=[1 0 0; 0 1 xmax]; 
                    NuT0_guess=0.001;
                    ML_guess=[0.01 0];
                    Optimization.b_constr=[zeros(DoFs+1,1);NuT0_max;ML_max];%contraints vector
                    Optimization.M_scaling=diag([1000;100;1000]);
                case 3
                    M_LB=-eye(DoFs);
                    M_UB=eye(DoFs); 
                    NuT0_guess=0;
                    ML_guess=[3e-02 0.5 3];
                    Optimization.b_constr=[zeros(DoFs,1);ML_max;k_max;xmax];%contraints vector
                    Optimization.M_scaling=diag([100;1;1]);
                case 4
                    M_LB=-eye(DoFs);
                    M_UB=eye(4); 
                    ML_guess=[0.001 0.01 1 xmax/2];
                    Optimization.b_constr=[zeros(DoFs,1);ML0_max;ML_inf_max;k_max;xmax];%contraints vector
                    Optimization.M_scaling=diag([100;100;1;1]);
                otherwise
                    error('Select a valid number of degrees of freedom!');
            end
            Optimization.M_constr=[M_LB;M_UB]*inv(Optimization.M_scaling);%constraints matrix
            Optimization.x0=Optimization.M_scaling*[ML_guess'];
            
            
        case 'EV'
            
            %Initialization
            Optimization.NuT=[];
            
            %Optimization setup
            NuT_max=0.1;
            
            Optimization.M_scaling=eye(DoFs)*1000;

            M_LB=-eye(DoFs);
            switch DoFs
                case 1
                    M_UB=1;
                    NuT_guess=0.001;
                case 2
                    M_UB=[1 xmax]; 
                    NuT_guess=[0.001 0];
                otherwise
                    error('Select a valid number of degrees of freedom!');
            end
            Optimization.M_constr=[M_LB;M_UB]*inv(Optimization.M_scaling);%constraints matrix
            Optimization.b_constr=[zeros(DoFs,1);NuT_max];%constraints vector
            Optimization.x0=Optimization.M_scaling*NuT_guess';
         
    end