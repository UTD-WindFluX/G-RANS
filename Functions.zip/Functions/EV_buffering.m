function ni = EV_buffering(nu_old,k);
Global
XmGLC = Matrices.XmGLC;
D1_X = Matrices.D1_X;
ni = zeros(Nr,Nx);
Ind_buffer=min(find(Matrices.XmGLC(1,:)-(xmax-1)<=0)); %index of beginning of the buffer zone
der_nut = reshape(D1_X*nu_old,Nx,Nr).'; alpha = der_nut(:,Ind_buffer);

for i=1:Nr
    fun = @(x) (k(i)-alpha(i)).*x.^2 + alpha(i).*x;
    ni(i,1:Ind_buffer) = fun(XmGLC(1,1:Ind_buffer) - (xmax-1));
end
end