function [JA, F,Transport,Pressure,Viscous,FF] = JacobianSponge_new(nut,  m, qc, Matrices,outBC)
Global

D1_X=Matrices.D1_X;
D2_X=Matrices.D2_X;
D1_r=Matrices.D1_r;
D2_r=Matrices.D2_r;
D1GC_X=Matrices.D1GC_X;
D1GC_r=Matrices.D1GC_r;
MfrL=Matrices.MfrL;
MtoL=Matrices.MtoL;
XmGLC=Matrices.XmGLC;
RmGLC=Matrices.RmGLC;
XmGC=Matrices.XmGC;
RmGC=Matrices.RmGC;
%%
I = eye(size(D1_X));
IGC= eye(NxGC*NrGC);

rGLCc=reshape(RmGLC.',Nx*Nr,1);
rGCc=reshape(RmGC.',NxGC*NrGC,1);


Urc=qc(1:Nx*Nr);
Ur  = diag(Urc);
DUrDX=diag(D1_X*Urc);
DUrDr=diag(D1_r*Urc);

Utc=qc(Nx*Nr+1:2*Nx*Nr);
Ut  = diag(Utc);
DUtDX=diag(D1_X*Utc);
DUtDr=diag(D1_r*Utc);

Uxc=qc(2*Nx*Nr+1:3*Nx*Nr);
Ux  = diag(Uxc);
DUxDX=diag(D1_X*Uxc);
DUxDr=diag(D1_r*Uxc);

pc = qc(3*Nx*Nr+1:end);
Om=(reshape(Utc,Nx,Nr).')./RmGLC; Om(end,:)=0;
Om=diag(reshape(Om.',Nx*Nr,1));

%
invrGLCc=1./rGLCc; invrGLCc(end-Nx+1:end)=1e20; %the result doesn't depend on this value

nuRe=1/Reynolds+nut; nuReD=kron(eye(Nr),diag(nuRe));
DnutDx=Matrices.D1_X(1:Nx,1:Nx)*nut; DnutDxD=kron(eye(Nr),diag(DnutDx));
% operatori trasporto e diff
Gamma=Ur*D1_r+Om*1i*m*I+Ux*D1_X;
Delta=diag(invrGLCc)*D1_r+D2_r-m^2*diag(invrGLCc.^2)+D2_X;
Delta2=Delta-diag(invrGLCc.^2);

% JA
JA11=Gamma+DUrDr - nuReD*Delta2  -DnutDxD*D1_X;
JA12=-2*Om+nuReD*(2*1i*m*diag(invrGLCc.^2));
JA13=DUrDX  -DnutDxD*D1_r;
JA14=MtoL*D1GC_r; 

JA21=DUtDr+Om-nuReD*(2*1i*m*diag(invrGLCc.^2));
JA22=Gamma+diag(diag(Ur*diag(invrGLCc)))-nuReD*Delta2  -DnutDxD*D1_X;
JA23=DUtDX;
JA24=1i*m*diag(invrGLCc)*MtoL;

JA31=DUxDr;
JA32=0*I;
JA33=(Gamma+DUxDX-nuReD*Delta)  -2*DnutDxD*D1_X;
JA34=MtoL*D1GC_X;

JA41=diag(1./rGCc)*MfrL+MfrL*D1_r;
JA42=1i*m*diag(1./rGCc)*MfrL;
JA43=MfrL*D1_X;
JA44=0*IGC;

% FA
FA11=Gamma - nuReD*Delta2  -DnutDxD*D1_X;
FA12=-Om+nuReD*(2*1i*m*diag(invrGLCc.^2));
FA13= -DnutDxD*D1_r;
FA14=MtoL*D1GC_r;

FA21=Om-nuReD*(2*1i*m*diag(invrGLCc.^2));
FA22=Gamma-nuReD*Delta2  -DnutDxD*D1_X;
FA23=0*I;
FA24=1i*m*diag(invrGLCc)*MtoL;

FA31=0*I;
FA32=0*I;
FA33=(Gamma-nuReD*Delta) -2*DnutDxD*D1_X;
FA34=MtoL*D1GC_X;

FA41=diag(1./rGCc)*MfrL+MfrL*D1_r;
FA42=1i*m*diag(1./rGCc)*MfrL;
FA43=MfrL*D1_X;
FA44=0*IGC;


A =  [JA11, JA12, JA13, JA14; JA21, JA22, JA23, JA24; JA31, JA32, JA33, JA34; JA41, JA42, JA43, JA44];
FA = [FA11, FA12, FA13, FA14; FA21, FA22, FA23, FA24; FA31, FA32, FA33, FA34; FA41, FA42, FA43, FA44];
F=FA*qc;
FF=F;
Transport=Gamma*qc(Nx*Ny*2+1:Nx*Ny*3);
Pressure=MtoL*D1GC_X*qc(3*Nx*Ny+1:3*Nx*Ny+NxGC*NyGC);
Viscous=-nuReD*Delta*qc(Nx*Ny*2+1:Nx*Ny*3);


%boundary conditions
%% sopra
%dirichlet
% A(1:Nx,:)=0; F(1:Nx,:)=0; A(1:Nx,1:Nx)=eye(Nx);
% A(Nx*Ny+1:Nx*Ny+Nx,:)=0; F(Nx*Ny+1:Nx*Ny+Nx,:)=0; A(Nx*Ny+1:Nx*Ny+Nx,Nx*Ny+1:Nx*Ny+Nx)=eye(Nx);
% A(2*Nx*Ny+1:2*Nx*Ny+Nx,:)=0; F(2*Nx*Ny+1:2*Nx*Ny+Nx,:)=0; A(2*Nx*Ny+1:2*Nx*Ny+Nx,2*Nx*Ny+1:2*Nx*Ny+Nx)=eye(Nx);
%neumann
% A(1:Nx,:)=0; F(1:Nx,:)=0; 
% A(1:Nx,1:Nx*Ny)=D1_r(1:Nx,:);
% 
% A(Nx*Ny+1:Nx*Ny+Nx,:)=0; F(Nx*Ny+1:Nx*Ny+Nx,:)=0; 
% A(Nx*Ny+1:Nx*Ny+Nx,Nx*Ny+1:2*Nx*Ny)=D1_r(1:Nx,:);
% 
% A(2*Nx*Ny+1:2*Nx*Ny+Nx,:)=0; F(2*Nx*Ny+1:2*Nx*Ny+Nx,:)=0; 
% A(2*Nx*Ny+1:2*Nx*Ny+Nx,2*Nx*Ny+1:3*Nx*Ny)=D1_r(1:Nx,:);
%stress free
A(1:Nx,:)=0; pGLC = -MtoL*pc;
F(1:Nx,:) = 2*diag(nuRe)*D1_r(1:Nx,:)*Urc+pGLC(1:Nx); %2muuu durdr-p=0 ---> (2/Re) durdr-p=0
A(1:Nx,1:Nx*Ny)=2*diag(nuRe)*D1_r(1:Nx,:); 
A(1:Nx,3*Nx*Ny+1:3*Nx*Ny+NxGC*NyGC)=-MtoL(1:Nx,:);
% 
A(Nx*Ny+1:Nx*Ny+Nx,:)=0; 
F(Nx*Ny+1:Nx*Ny+Nx,:)=D1_r(1:Nx,:)*Utc-eye(Nx)/max(RmGLC(:,1))*Utc(1:Nx); % 1/r(durdth-uth)+duthdr=0
A(Nx*Ny+1:Nx*Ny+Nx,1:Nx)=1i*m/max(RmGLC(:,1))*eye(Nx);
A(Nx*Ny+1:Nx*Ny+Nx,Nx*Ny+1:Nx*Ny+Nx)=-eye(Nx)/max(RmGLC(:,1));
A(Nx*Ny+1:Nx*Ny+Nx,Nx*Ny+1:2*Nx*Ny)=A(Nx*Ny+1:Nx*Ny+Nx,Nx*Ny+1:2*Nx*Ny)+D1_r(1:Nx,:);
% 
A(2*Nx*Ny+1:2*Nx*Ny+Nx,:)=0; F(2*Nx*Ny+1:2*Nx*Ny+Nx,:)=D1_X(1:Nx,:)*Urc+D1_r(1:Nx,:)*Uxc; % durdx+duxdr=0
A(2*Nx*Ny+1:2*Nx*Ny+Nx,1:Nx*Ny)=D1_X(1:Nx,:);
A(2*Nx*Ny+1:2*Nx*Ny+Nx,2*Nx*Ny+1:3*Nx*Ny)=D1_r(1:Nx,:);
%% outlet
switch outBC
    case 0
%outlet neumann
A(1:Nx:Nx*Ny,:)=0; F(1:Nx:Nx*Ny,:)=0; 
A(1:Nx:Nx*Ny,1:Nx*Ny)=D1_X(1:Nx:Nx*Ny,:);
A(Nx*Ny+1:Nx:2*Nx*Ny,:)=0; F(Nx*Ny+1:Nx:2*Nx*Ny,:)=0; 
A(Nx*Ny+1:Nx:2*Nx*Ny,Nx*Ny+1:2*Nx*Ny)=D1_X(1:Nx:Nx*Ny,:);
A(2*Nx*Ny+1:Nx:3*Nx*Ny,:)=0; F(2*Nx*Ny+1:Nx:3*Nx*Ny,:)=0; 
A(2*Nx*Ny+1:Nx:3*Nx*Ny,2*Nx*Ny+1:3*Nx*Ny)=D1_X(1:Nx:Nx*Ny,:);
    case 1
%outlet convection bc dirichlet Nhom
A(1:Nx:Nx*Ny,:)=0; F(1:Nx:Nx*Ny,:)=0; A(1:Nx:Nx*Ny,1:Nx:Nx*Ny)=eye(Ny);
A(Nx*Ny+1:Nx:2*Nx*Ny,:)=0; F(Nx*Ny+1:Nx:2*Nx*Ny,:)=0; A(Nx*Ny+1:Nx:2*Nx*Ny,Nx*Ny+1:Nx:2*Nx*Ny)=eye(Ny);
A(2*Nx*Ny+1:Nx:3*Nx*Ny,:)=0; F(2*Nx*Ny+1:Nx:3*Nx*Ny,:)=0; A(2*Nx*Ny+1:Nx:3*Nx*Ny,2*Nx*Ny+1:Nx:3*Nx*Ny)=eye(Ny);
detUc=1;
F(1:Nx:Nx*Ny)=-detUc*D1_X(1:Nx:Nx*Ny,:)*Urc;
F(Nx*Ny+1:Nx:2*Nx*Ny)=-detUc*D1_X(1:Nx:Nx*Ny,:)*Utc;
F(2*Nx*Ny+1:Nx:3*Nx*Ny)=-detUc*D1_X(1:Nx:Nx*Ny,:)*Uxc;
    case 2
A(1:Nx:Nx*Ny,:)=0; F(1:Nx:Nx*Ny,:)=0; % durdx+duxdr
A(1:Nx:Nx*Ny,1:Nx*Ny)=D1_X(1:Nx:Nx*Ny,:);
A(1:Nx:Nx*Ny,2*Nx*Ny+1:3*Nx*Ny)=D1_r(1:Nx:Nx*Ny,:);

A(Nx*Ny+1:Nx:2*Nx*Ny,:)=0; F(Nx*Ny+1:Nx:2*Nx*Ny,:)=0; % duthdx + 1/r duxdth
A(Nx*Ny+1:Nx:2*Nx*Ny,Nx*Ny+1:2*Nx*Ny)=D1_X(1:Nx:Nx*Ny,:);
A(Nx*Ny+1:Nx:2*Nx*Ny,2*Nx*Ny+1:Nx:3*Nx*Ny)=1i*m*diag(1./RmGLC(:,1));

A(2*Nx*Ny+1:Nx:3*Nx*Ny,:)=0; F(2*Nx*Ny+1:Nx:3*Nx*Ny,:)=0; % 2muuu duxdx -p=0 --> (2/Re) duxdx -p=0
A(2*Nx*Ny+1:Nx:3*Nx*Ny,2*Nx*Ny+1:3*Nx*Ny)=(2/nuRe(1))*D1_X(1:Nx:Nx*Ny,:);
A(2*Nx*Ny+1:Nx:3*Nx*Ny,3*Nx*Ny+1:3*Nx*Ny+NxGC*NyGC)=-MtoL(1:Nx:Nx*Ny,:);
end
%% asse  %% secondo Batchelor&Gill 1962  (e come Meyer&Powell 1992 e Olendraru&Sellier 2002)
if m==0
A(Nx*Ny-Nx+1:Nx*Ny,:)=0; F(Nx*Ny-Nx+1:Nx*Ny,:)=0; A(Nx*Ny-Nx+1:Nx*Ny,Nx*Ny-Nx+1:Nx*Ny)=eye(Nx);
A(2*Nx*Ny-Nx+1:2*Nx*Ny,:)=0; F(2*Nx*Ny-Nx+1:2*Nx*Ny,:)=0; A(2*Nx*Ny-Nx+1:2*Nx*Ny,2*Nx*Ny-Nx+1:2*Nx*Ny)=eye(Nx);
% 
A(3*Nx*Ny-Nx+1:3*Nx*Ny,:)=0; F(3*Nx*Ny-Nx+1:3*Nx*Ny,:)=0; 
A(3*Nx*Ny-Nx+1:3*Nx*Ny,2*Nx*Ny+1:3*Nx*Ny)=D1_r(Nx*Ny-Nx+1:Nx*Ny,:);
% A(3*Nx*Ny-Nx+1:3*Nx*Ny,3*Nx*Ny-Nx+1:3*Nx*Ny)=eye(Nx);

elseif abs(m)==1
%derivata a entrambi (in r) 
A(Nx*Ny-Nx+1:Nx*Ny,:)=0; F(Nx*Ny-Nx+1:Nx*Ny,:)=0; 
A(Nx*Ny-Nx+1:Nx*Ny,1:Nx*Ny)=D1_r(Nx*Ny-Nx+1:Nx*Ny,:);

A(2*Nx*Ny-Nx+1:2*Nx*Ny,:)=0; F(2*Nx*Ny-Nx+1:2*Nx*Ny,:)=0; 
A(2*Nx*Ny-Nx+1:2*Nx*Ny,Nx*Ny+1:2*Nx*Ny)=D1_r(Nx*Ny-Nx+1:Nx*Ny,:);
% 
%homo ux
A(3*Nx*Ny-Nx+1:3*Nx*Ny,:)=0; F(3*Nx*Ny-Nx+1:3*Nx*Ny,:)=0; A(3*Nx*Ny-Nx+1:3*Nx*Ny,3*Nx*Ny-Nx+1:Nx*Ny)=eye(Nx);
else   
A(Nx*Ny-Nx+1:Nx*Ny,:)=0; F(Nx*Ny-Nx+1:Nx*Ny,:)=0; A(Nx*Ny-Nx+1:Nx*Ny,Nx*Ny-Nx+1:Nx*Ny)=eye(Nx);
A(2*Nx*Ny-Nx+1:2*Nx*Ny,:)=0; F(2*Nx*Ny-Nx+1:2*Nx*Ny,:)=0; A(2*Nx*Ny-Nx+1:2*Nx*Ny,2*Nx*Ny-Nx+1:2*Nx*Ny)=eye(Nx);
A(3*Nx*Ny-Nx+1:3*Nx*Ny,:)=0; F(3*Nx*Ny-Nx+1:3*Nx*Ny,:)=0; A(3*Nx*Ny-Nx+1:3*Nx*Ny,3*Nx*Ny-Nx+1:3*Nx*Ny)=eye(Nx);
end


%% inlet
%inlet dirichlet
A(Nx:Nx:Nx*Ny,:)=0; F(Nx:Nx:Nx*Ny,:)=0; A(Nx:Nx:Nx*Ny,Nx:Nx:Nx*Ny)=eye(Ny);
A(Nx*Ny+Nx:Nx:2*Nx*Ny,:)=0; F(Nx*Ny+Nx:Nx:2*Nx*Ny,:)=0; A(Nx*Ny+Nx:Nx:2*Nx*Ny,Nx*Ny+Nx:Nx:2*Nx*Ny)=eye(Ny);
A(2*Nx*Ny+Nx:Nx:3*Nx*Ny,:)=0; F(2*Nx*Ny+Nx:Nx:3*Nx*Ny,:)=0; A(2*Nx*Ny+Nx:Nx:3*Nx*Ny,2*Nx*Ny+Nx:Nx:3*Nx*Ny)=eye(Ny);

% %pressione
% % dove=Nx*round(Ny/10)+round(Nx/2);
% % dove=round(Nx*Ny/2+Nx/2);
% % dove=Nx*round(Ny/4)+Nx;
% % A(3*Nx*Ny+dove,:)=0;  F(3*Nx*Ny+dove,:)=0; A(3*Nx*Ny+dove,3*Nx*Ny+dove)=1;
% 
% %pressione outlet
A(3*Nx*Ny+1:NxGC:end,:)=0;  F(3*Nx*Ny+1:NxGC:end,:)=0; A(3*Nx*Ny+1:NxGC:end,3*Nx*Ny+1:NxGC:end)=eye(NyGC); 

JA=A;