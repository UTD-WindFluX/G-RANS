function [NuT,DNuT_dUr,DNuT_dUt,DNuT_dUx,S] = EV_closure_All_mod(NuT0,ML,qc,smooth_par)
    Global
    RmGLC = Matrices.RmGLC;
    MLc = reshape(ML',Nx*Nr,1); 
    
    Urc = qc(1:Nx*Nr);%radial velocity
    Utc = qc(Nx*Nr+1:2*Nx*Nr);%azimuthal velocity
    Uxc = qc(2*Nx*Nr+1:3*Nx*Nr); %axial velocity component
    row_AXIS=Nr*Nx-Nx+1:Nr*Nx;
    D1_r=Matrices.D1_r;
    D1_X=Matrices.D1_X;
    
    rGLC=reshape(RmGLC.',Nx*Nr,1); 
    invrGLC=1./rGLC; %inverse of the radial positions
    invrGLC(end-Nx+1:end)=invR_max; %the result doesn't depend on this value
    
    Dr_invR=D1_r-diag(invrGLC);
    
    %components of stress tensor
%     S_rr=D1_r*Urc*(1-BL_approx);
    
%     S_tt=diag(invrGLC)*Urc*(1-BL_approx);
    
%     S_xx=D1_X*Uxc*(1-BL_approx);
    
%     S_rt=Dr_invR*Utc;S_rt(row_AXIS)=0;
    
    S_rx = (D1_r*Uxc).^2;
    
%     S_tx=(D1_X*Utc)*(1-BL_approx);
    
%     S=(2*S_rr.^2+2*S_tt.^2+2*S_xx.^2+S_rt.^2+S_rx.^2+S_tx.^2);%2(S:S)
%   NuT_raw=Mat_clean*(MLc.^2.*S.^0.5)+NuT0;%EV;
    
%     if smooth_par==NuT_smooth_par
%         Mat_smooth=Matrices.M_smooth;
%     else
        Mat_smooth=Mat_smooth_Gauss(smooth_par);
%     end
    
    NuT=Mat_smooth*(MLc.^2.*S_rx.^0.5)+NuT0;%EV
    
    %% Derivatives
    DNuT_dUx = Mat_smooth*diag(MLc.^2)*diag((abs(S_rx)+eps).^(0.5))*D1_r;
    DNuT_dUr = 0*DNuT_dUx;
    DNuT_dUt = 0*DNuT_dUx;
end