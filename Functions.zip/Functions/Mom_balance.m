Ux_inlet = RANS.Ux(:,end); Ux_outlet = RANS.Ux(:,1); Ur_outlet = RANS.Ur(:,1); 
Ur_up = RANS.Ur(1,:); Ux_up = RANS.Ux(1,:);

% Ux_inlet = ones(Nr,1); Ux_outlet = ones(Nr,1); Ur_up = zeros(1,Nx); Ux_up = ones(1,Nx);
r = Matrices.RmGLC(:,1); R = max(r); Rt =0.5;
Qx_up = R*sqrt(Ur_up.*Ux_up)*IWx*sqrt(Ur_up.*Ux_up).';
Qx_out = sqrt(r.*Ux_outlet.^2).'*IWr*sqrt(r.*Ux_outlet.^2);
Qin = R^2/2;
Qout = Qx_up + Qx_out;