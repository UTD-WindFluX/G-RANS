% Create a psuedo grid mapping with a fine mesh
Nt = length(TSR);
Omega = 2*TSR;
r=flip(0:0.01:.55)';rGLC = Matrices.RmGLC(:,1);
% Psuedo blade characteristics
Aerodyn_P=BlindTest1(r); % r chord twist Airfoil_class
chord_P=Aerodyn_P(:,2);
twist_P=Aerodyn_P(:,3);
airfoil_P=Aerodyn_P(:,4);
% Finding indices for R
[~,R_ind_P]=min(abs(r-.5));
[~,temp]=min(abs(r-nac));
nac_ind_P=temp;
[Vrel,alfa] = Angle_of_Attack(RANS.Ux(Ind_R:end,Ind),RANS.Ut(Ind_R:end,Ind));
Vrel = [zeros(Nr-Nrd,1); Vrel]; alfa = [zeros(Nr-Nrd,1); alfa];
% Find relative incoming velocity and thus angle attack for Pseudo grid based on actual domain velocities
for k=1:Nt
    Index_C = min(find(Matrices.XmGLC(1,:)-(x_T(k)-1)<=0));
    Index = min(find(Matrices.XmGLC(1,:)-(x_T(k))<=0));
    Vrel_P(:,k)=interp1(rGLC,Vrel(:,k),r,'spline');
    Ux_int(:,k) = interp1(rGLC,RANS.Ux(:,Index_C),r,'spline');
    Ut_int(:,k) = interp1(rGLC,RANS.Ut(:,Index_C),r,'spline');
    alfa_P(:,k)=interp1(rGLC,alfa(:,k),r,'spline');
 % Calculate thrust and tangential forces for pseudo grid 
    AerodynForce_P=LiftDragBT1(r,alfa_P(:,k),airfoil_P);
    CL_P(:,k)=AerodynForce_P(:,3);
    CD_P(:,k)=AerodynForce_P(:,4);
    CThrust_P(:,k)=CD_P(:,k).*sind(alfa_P(:,k)+twist_P)+CL_P(:,k).*cosd(alfa_P(:,k)+twist_P);
    CTang_P(:,k)=-CD_P(:,k).*cosd(alfa_P(:,k)+twist_P)+CL_P(:,k).*sind(alfa_P(:,k)+twist_P);
    CTang_P(:,k)=((r>r(nac_ind_P)).*(CTang_P(:,k)));
    CTang_P(:,k)=(CTang_P(:,k)>0).*CTang_P(:,k);
    CThrust_P(:,k)=((r>r(nac_ind_P)).*CThrust_P(:,k));
%     if TSR(k)>= 5
%         g(k)=169.9*exp(-1*TSR(k))+.1285;
%     else 
%         g(k)=1.288;
%     end
    g(k)=exp(-.125*(3*TSR(k)-12));
        % tip and hub corrections
%     fxh=-0.0267*TSR(k)+0.21;
%     fth=fxh;
%     fxt=-0.01*TSR(k)+0.59;
%     ftt = -0.0086*TSR(k)+0.5425;
    fxh = nac;
%     fth=fxh;
%     ftt = -0.04*TSR(k)+0.76+nac-0.05;
    ftt = 0.5; fxt = 0.5;
    fth = fxh;
    f_tip_x_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(fxt-r)./(2*r.*sind(alfa_P(:,k)+twist_P)))));
    f_hub_x_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(r-fxh)./(2*r.*sind(alfa_P(:,k)+twist_P)))));%.001
    f_x_P(:,k)=f_tip_x_P(:,k).*f_hub_x_P(:,k); %correct_x(k)*
    f_tip_t_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(ftt-r)./(2*r.*sind(alfa_P(:,k)+twist_P)))));
    f_hub_t_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(r-fth)./(2*r.*sind(alfa_P(:,k)+twist_P)))));
    f_t_P(:,k)=f_tip_t_P(:,k).*f_hub_t_P(:,k);%correct_t(k)*
    F_Thrust_P(:,k)=((2*pi*r).^-1).*.5.*Vrel_P(:,k).^2.*chord_P.*f_x_P(:,k).*3.*CThrust_P(:,k);F_Thrust_P(end,k)=F_Thrust_P(end-1,k);
    F_Tang_P(:,k)=((2*pi*r).^-1).*.5.*Vrel_P(:,k).^2.*chord_P.*f_t_P(:,k).*3.*(CTang_P(:,k));F_Tang_P(end,k)=0;
    F_nacelle_g_P(:,k)=.6*(.5.*Vrel_P(:,k).^2).*exp(-((r-0.0)/(0.14)).^2);% (-1.7*nac+0.2105)
    F_nacelle_g_P(:,k)=(r<(.18)).*F_nacelle_g_P(:,k); 
end
%% Calculate Power and coefficients for this Pseudo grid
    Nr_P=length(r);
    Power_P=zeros(Nr_P,Nt);C_P = zeros(Nt,1);C_TH = zeros(Nt,1);C_TG = zeros(Nt,1);
    Power_total_P=zeros(Nt,1);
    Ux_avg = zeros(Nt,1); Ut_avg = zeros(Nt,1); 
    a = zeros(Nt,1); a1 = zeros(Nt,1);
    F_Thrust_total_P=zeros(Nt,1);F_tangent_total_P = zeros(Nt,1);
for j=1:Nx
        Utinterp = interp1(rGLC,RANS.Ut(:,j),r);
        Uxinterp = interp1(rGLC,RANS.Ux(:,j),r);
        Ux_averaged(j) = 2*pi*trapz(flipud(r(R_ind_P:nac_ind_P)),...
        flipud(r(R_ind_P:nac_ind_P).*Uxinterp(R_ind_P:nac_ind_P)))/(pi*(0.5^2-nac^2));
        
end
for k=1:Nt
    Power_P(:,k)=Omega(k)*r.*abs(F_Tang_P(:,k));
    Power_total_P(k)=2*pi*trapz(flipud(r(R_ind_P:nac_ind_P)),...
        flipud(r(R_ind_P:nac_ind_P).*Power_P(R_ind_P:nac_ind_P,k)));
    C_P(k) = Power_total_P(k)/(0.5*pi*(D/2)^2*D);    
    F_Thrust_total_P(k)=2*pi*trapz(flipud(r(R_ind_P:nac_ind_P)),...
        flipud(r(R_ind_P:nac_ind_P).*(F_Thrust_P(R_ind_P:nac_ind_P,k))));
    F_tangent_total_P(k) = 2*pi*trapz(flipud(r(R_ind_P:end)),...
        flipud(r(R_ind_P:end).*F_Tang_P(R_ind_P:end,k)));
    Torque(k) = 2*pi*trapz(flipud(r(R_ind_P:end)),...
        flipud(r(R_ind_P:end).^2.*F_Tang_P(R_ind_P:end,k)));
    C_TH(k) = F_Thrust_total_P(k)/(0.5*pi*(D/2)^2);

    Ux = Ux_averaged(:,Index); %Ux at turb. loc.
    
%     Ux_avg(k) = 2*pi*trapz(flipud(r(R_ind_P:end)),...
%         flipud(r(R_ind_P:end).*Ux(R_ind_P:end)));
    a(k) = 1-Ux_averaged(Index);%/(pi*0.25);
%     C_P = 4*a*(1-a)^2; 
%     C_TH = 4*a*(1-a);
%     Ut_avg(k) = 2*pi*trapz(flipud(r(R_ind_P:end)),...
%         flipud(r(R_ind_P:end).*Ut(R_ind_P:end)))/(pi*0.25);
%     a1(k) = abs(Ut_averaged(Index));%/(Omega(k)*0.5);
end