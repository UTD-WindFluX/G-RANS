% Ux = Res.Ux;
% Ux_coeff = fcgltran2d(Ux,1);
X = x_T + [1 3 5];% X_int = interp1(Matrices.XmGLC(1,:),Matrices.xGLC,X,'linear');
% PHI_x = ChebyshevInterpolants(Nx,2,X_int);
% Ux_val = cell(4,1);
r_pos = cell(4,1);
% %%
for i=1:length(X)
    r_pos{i} = r{i}(r{i}>=0);
%     for k=1:length(r_pos{i})
%         y = interp1(Matrices.RmGLC(:,1),Matrices.yGLC,r_pos{i}(k));
%         PHI_r = ChebyshevInterpolants(Nr,2,y);
%         Ux_val{i}(k) = PHI_r*Ux_coeff*PHI_x(i,:).';
%     end
end

[Xint,Rint] = meshgrid(X,Matrices.RmGLC(:,1));

Ux_val = interp2(Matrices.XmGLC,Matrices.RmGLC,Res.Ux,Xint,Rint,'linear');