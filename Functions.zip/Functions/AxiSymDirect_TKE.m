function [RANS]=AxiSymDirect_TKE(NuT0,ML_coeff);
    Global
    NuT0=abs(NuT0);
    ML=ML_fun(abs(ML_coeff));                                               %Mixing Length function starting from its coefficients
    
    add_smoothing=0;                                                        %Initialization of EV smoothing
    qc0=Initial_field;                                                      %Initial field (from Global)
    %% Initial field from TSR-1 
    if Pre_ml_closure==1                                                    %If Pre_ml_closure = 1, initial field is equal to the converged field at TSR-1
    load(strcat(['./BT1_Dataset_new/RANS',num2str(TSR_theor-1),'.mat']));
    RANS=Res;
    Ur = interp2(RANS.X,RANS.R,RANS.Ur,Matrices.XmGLC,Matrices.RmGLC);
    Ut = interp2(RANS.X,RANS.R,RANS.Ut,Matrices.XmGLC,Matrices.RmGLC);
    Ux = interp2(RANS.X,RANS.R,RANS.Ux,Matrices.XmGLC,Matrices.RmGLC);
    p = interp2(RANS.X,RANS.R,RANS.p,Matrices.XmGLC,Matrices.RmGLC);p = Matrices.MfrL*reshape(p.',Nx*Nr,1);
    tke = interp2(RANS.X,RANS.R,RANS.tke,Matrices.XmGLC,Matrices.RmGLC);
    qc1 = [reshape(Ur.',Nx*Nr,1); reshape(Ut.',Nx*Nr,1);reshape(Ux.',Nx*Nr,1);reshape(p.',NxGC*NrGC,1);reshape(tke.',Nx*Nr,1)];
    end
    %% Newton loop tke
    disp ('Newton loop, tke model.');
    nIte = 0;                                                               %Initialization number of iterations
    SquartoL2=1e5*errmin;                                                   %Initialization L2-error
    while SquartoL2>errmin
        if nIte==0
            if Pre_ml_closure==1
                qc=qc1;
            else
                qc = qc0;
            end
            F_old = zeros(4*Nx*Nr + NxGC*NrGC,1);                           %Initialization old terms used with under-relaxation
            P_tke_old = zeros(Nx*Nr,1);
            J_old22 = zeros(Nx*Nr);
            J_old23 = zeros(Nx*Nr);
            J_old32 = zeros(Nx*Nr);
            J_old33 = zeros(Nx*Nr);
            %
            J_old.Ft_Ut = J_old22; J_old.Ft_Ux = J_old23; 
            J_old.Fx_Ut = J_old32; J_old.Fx_Ux = J_old33;
            J_old.DP_DUr = zeros(Nx*Nr); J_old.DP_DUt = zeros(Nx*Nr);
            J_old.DP_DUx = zeros(Nx*Nr); J_old.DP_Dtke = zeros(Nx*Nr);
        end
        
        [JA,F,F_ADM,P_old] = JacobianSponge_AD_TKE2(qc,reshape(ML.',Nx*Nr,1),J_old,F_old,P_tke_old,NuT0);%jacobian and residuals calculator (under relaxation both for forcing and tke production)
        [SquartoL2]=normaL2_tke(F);                                                                      %norm of the residuals
        
        if SquartoL2 <=1e-05                                                                             %treshold about Under Relaxation Factor
            urf = 1.0;
            urf_tke = 1.0;
        end
        M = inv(JA);                                                                                     %Inverse of Jacobian matrix
        deltaq=-M*F;                                                                                     %updating step of the linearized problem
        display(['SqL2=',num2str(SquartoL2)]);                                                           %Display L2-error
        qc=qc+deltaq;                                                                                    %solution updating
        qc(3*Nx*Nr+NxGC*NrGC+1:end) = abs(qc(3*Nx*Nr+NxGC*NrGC+1:end));                                  %Impose positive tke
        %
        F_old = F_ADM;                                                                                   %Jacobian and forcing updating (for the next under-relaxing)
        J_old22 = JA(Nx*Nr+1:2*Nx*Nr,Nx*Nr+1:2*Nx*Nr);
        J_old23 = JA(Nx*Nr+1:2*Nx*Nr,2*Nx*Nr+1:3*Nx*Nr);
        J_old32 = JA(2*Nx*Nr+1:3*Nx*Nr,Nx*Nr+1:2*Nx*Nr);
        J_old33 = JA(2*Nx*Nr+1:3*Nx*Nr,2*Nx*Nr+1:3*Nx*Nr);
        J_old.Ft_Ut = J_old22; J_old.Ft_Ux = J_old23; 
        J_old.Fx_Ut = J_old32; J_old.Fx_Ux = J_old33;
        %
        J_old.DP_DUr = P_old.DP_DUr; J_old.DP_DUt = P_old.DP_DUt;
        J_old.DP_DUx = P_old.DP_DUx; J_old.DP_Dtke = P_old.DP_Dtke;
        P_tke_old = P_old.P;
        %
        nIte=nIte+1;
        Error(nIte) = SquartoL2;                                                                        %Update vector of L2-errors
        
        if SquartoL2>10 || nIte>maxIter && SquartoL2>errmin
                    
            if add_smoothing>Max_NuT_smooth
                error('Smoothing parameter exceedes the limit. Execution aborted.');
            end
            
            add_smoothing=add_smoothing+0.05;%additional smoothing
            nIte=0;
            disp(['No convergence. Trying with a smoothing parameter of ',num2str(NuT_smooth_par+add_smoothing)]);
        end
        
       if Diagnostic==1  

        Ux=qc(2*Nx*Nr+1:Nx*Nr*3); Ux=reshape(Ux,Nx,Nr)';                                    %Reshape Ux and tke for plotting
        tke = qc(3*Nx*Nr+NxGC*NrGC+1:end); tke = reshape(tke,Nx,Nr).';
        
        figure('units','normalized','outerposition',[0 0 1 0.5]);set(gcf,'Color','White');  %Figure on Ux and tke
        subplot(2,1,1)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,Ux); axis equal;axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp ;colorbar; drawnow
        hold on 
        plot_turbine
        Plot_options('x/D','r/D','U_x'); %caxis ([0 1.1]);
        subplot(2,1,2)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,tke); axis equal;axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp ;colorbar; drawnow
        hold on
        plot_turbine
        Plot_options('x/D','r/D','TKE');
        
%         tke_updated = F(3*Nx*Nr+NxGC*NrGC+1:end);tke2d = reshape(tke_updated,Nx,Nr).';
%         fig_tke = figure('units','normalized','outerposition',[0 0 1 1]);set(gcf,'Color','White'); %Figure on tke residual
%         surf(Matrices.XmGLC,Matrices.RmGLC,tke2d);caxis ([-1e-05 1e-05]); colormap coolwarm;colorbar; drawnow
%         Plot_options('x/D','r/D',strcat(['Tke res. @ ',num2str(nIte),' res = ',num2str(SquartoL2)]));
%         savefig(fig_tke,strcat([folder,'/tke_residual/tke_',num2str(nIte)]));
%         saveas(fig_tke,strcat([folder,'/tke_residual/tke_',num2str(nIte),'.png']));
%         close all
      end 
        
    end
    %% Calculating converged field
    NuT = 0.55*tke.^(0.5).*ML;                                                               %Calculate final Eddy Viscosity
    [JA,F,~,~] = JacobianSponge_AD_TKE2(qc,reshape(ML.',Nx*Nr,1),J_old,F_old,P_tke_old,NuT0);%jacobian and residuals calculator
    %% Rearrangment of the results
    Ur=reshape(qc(1:Nx*Nr),Nx,Nr).'; Ut=reshape(qc(Nx*Nr+1:2*Nx*Nr),Nx,Nr).';                %Reshape velocity, pressure and EV for 
    Ux=reshape(qc(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).'; p=reshape(Matrices.MtoL*qc(3*Nx*Nr+1:3*Nx*Nr+NxGC*NrGC),Nx,Nr).';
    tke = reshape(qc(3*Nx*Nr+NxGC*NrGC+1:end),Nx,Nr).';
    %% output
    RANS.Ur=Ur;RANS.Ut=Ut;RANS.Ux=Ux;RANS.p=p; RANS.qc=qc; RANS.ML = ML; RANS.tke = tke;    %Write final data structure
    RANS.L2Err=Error; RANS.Jacobian=JA;RANS.NuT=NuT; RANS.F = F;