Ux = Res.Ux;
Ux_coeff = fcgltran2d(Ux,1);
X = x_T + [1 3 5];
X_int = interp1(Matrices.XmGLC(1,:),Matrices.xGLC,X,'linear');
PHI_x = ChebyshevInterpolants(Nx,2,X_int);
Ux_val = cell(3,1);
r_pos = cell(3,1);
%%
for i=length(X):-1:1
    r_pos{i} = r{i}(r{i}>=0);
    r_pos{i} = r_pos{i}(r_pos{i}<=max(max(Matrices.RmGLC)));
    for k=1:length(r_pos{i})
        y = interp1(Matrices.RmGLC(:,1),Matrices.yGLC,r_pos{i}(k));
        PHI_r = ChebyshevInterpolants(Nr,2,y);
        Ux_val{i}(k) = PHI_r*Ux_coeff*PHI_x(i,:).';
    end
end