function [PE,ID,IWrM,IWxMLxW]=normaL2matrix
Global
% Nx=Matrices.Nx;
% Nr=Matrices.Nr;
% NxGC=Matrices.NxGC;
% NrGC=Matrices.NrGC;

x1GLC=Matrices.x1GLC;
rGLC=Matrices.RmGLC(:,1);
y1GLC=Matrices.y1GLC;

% Lx = Matrices.XmGLC(1,1) - Matrices.XmGLC(1,end); %lunghezza dominio lungo x
IWxLxW=diag(INTweights(Nx,2)); 

IWxMLxW=diag(IWxLxW./x1GLC); 

IWr=diag(INTweights(Nr,2)); 
IWrM=diag(IWr.*rGLC./y1GLC);
IWx_bi = kron(eye(Nr),IWxMLxW);
IWMLxW=kron(IWrM,IWxMLxW);

Z=0*IWMLxW;
ZGC=zeros(Nx*Nr,NxGC*NrGC);
ZGC1=zeros(NxGC*NrGC,NxGC*NrGC);

PE=[IWMLxW,Z,Z,ZGC;Z,IWMLxW,Z,ZGC;Z,Z,IWMLxW,ZGC;ZGC',ZGC',ZGC',ZGC1];
% Squarto=sqrt(deltaU(1:3*Nx*Ny)'*PE*deltaU(1:3*Nx*Ny));

ID=[eye(size(IWMLxW)),Z,Z,ZGC;Z,eye(size(IWMLxW)),Z,ZGC;Z,Z,eye(size(IWMLxW)),ZGC;ZGC',ZGC',ZGC',ZGC1];