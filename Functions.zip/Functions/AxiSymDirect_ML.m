%Newton solver of the RANS field for ML
function [RANS]=AxiSymDirect_ML(NuT0,ML_coeff);
    Global
    NuT0=abs(NuT0);
    ML=ML_fun(abs(ML_coeff));%Mixing Length function starting from its coefficients
    
    add_smoothing=0;
    SquartoL2=1e5*errmin;%norm initialization
    nIte=0;
    qc0=Initial_field;

    %% Newton loop
disp ('Newton loop.');
nIte = 0;
SquartoL2=1e5*errmin;
    while SquartoL2>errmin
        
        if nIte==0;
            qc=qc0;
            F_old = zeros(3*Nx*Nr + NxGC*NrGC,1);
            J_old22 = zeros(Nx*Nr);
            J_old23 = zeros(Nx*Nr);
            J_old32 = zeros(Nx*Nr);
            J_old33 = zeros(Nx*Nr);
            J_old.Ft_Ut = J_old22; J_old.Ft_Ux = J_old23; 
            J_old.Fx_Ut = J_old32; J_old.Fx_Ux = J_old33;
        end
        
%         [NuT,DnutdUr,DnutdUt,DnutdUx]=EV_closure_All(NuT0,ML,qc,NuT_smooth_par+add_smoothing); %calculation of the new EV 
        [NuT,DnutdUr,DnutdUt,DnutdUx]=EV_closure_All_mod(NuT0,ML,qc,NuT_smooth_par+add_smoothing); %calculation of the new EV with BL assumption

        [JA,F,F_ADM] = JacobianSponge_AD_ML(qc,NuT,DnutdUr,DnutdUt,DnutdUx,J_old,F_old);%jacobian and residuals calculator
 
        [SquartoL2]=normaL2(F);%norm of the residuals
        
        if SquartoL2 <=1e-05 %treshold on the Under Relaxation Factor
            urf = 1.0;
        end
        deltaq=-JA\F;%solution of the linearized problem
        display(['SqL2=',num2str(SquartoL2)]); 
        qc=qc+deltaq;%solution updating
        
        F_old = F_ADM; %Jacobian and forcing updating
        J_old22 = JA(Nx*Nr+1:2*Nx*Nr,Nx*Nr+1:2*Nx*Nr);
        J_old23 = JA(Nx*Nr+1:2*Nx*Nr,2*Nx*Nr+1:3*Nx*Nr);
        J_old32 = JA(2*Nx*Nr+1:3*Nx*Nr,Nx*Nr+1:2*Nx*Nr);
        J_old33 = JA(2*Nx*Nr+1:3*Nx*Nr,2*Nx*Nr+1:3*Nx*Nr);
        J_old.Ft_Ut = J_old22; J_old.Ft_Ux = J_old23; 
        J_old.Fx_Ut = J_old32; J_old.Fx_Ux = J_old33;
        
        Ux = reshape(qc(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
        figure
        plot(Matrices.RmGLC(:,1),Ux(:,Ind),'*-');drawnow;grid on
        hold on
        plot(Matrices.RmGLC(:,1),Ux(:,36),'o-');drawnow
                
        nIte=nIte+1;
        Error(nIte) = SquartoL2;
        
        if SquartoL2>10 || nIte>maxIter && SquartoL2>errmin
                    
            if add_smoothing>Max_NuT_smooth
                error('Smoothing parameter exceedes the limit. Execution aborted.');
            end
            
            add_smoothing=add_smoothing+0.05;%additional smoothing
            nIte=0;
            disp(['No convergence. Trying with a smoothing parameter of ',num2str(NuT_smooth_par+add_smoothing)]);
        end
        
       if Diagnostic==1  
        [NuT,~,~]=EV_closure_All(NuT0,ML,qc,NuT_smooth_par); %calculation of the new EV 

        NuT=reshape(NuT,Nx,Nr)';
        XmGLC = Matrices.XmGLC; RmGLC = Matrices.RmGLC;
        Ur=qc(1:Nx*Nr); Ur=reshape(Ur,Nx,Nr)';
        Ut=qc(Nx*Nr+1:Nx*Nr*2); Ut=reshape(Ut,Nx,Nr)';
        Ux=qc(2*Nx*Nr+1:Nx*Nr*3); Ux=reshape(Ux,Nx,Nr)';
        p=Matrices.MtoL*qc(3*Nx*Nr+1:end);p=reshape(p,Nx,Nr)';

        VEL = figure('units','normalized','outerposition',[0 0 0.5 1]);set(gcf,'Color','White');
        subplot(3,1,1)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,Ur);
        axis equal; axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp ; colorbar; drawnow
        hold on
        plot_turbine
        Plot_options('x/D','r/D','U_r');title(strcat(['TSR=',num2str(TSR)]));
        subplot(3,1,2)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,Ut);axis equal; axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp;colorbar ; drawnow
        hold on
        plot_turbine
        Plot_options('x/D','r/D','U_{\theta}')
        subplot(3,1,3)
        pcolor(Matrices.XmGLC,Matrices.RmGLC,Ux); axis equal;axis ([xmin xmax 0 rmax]); colormap coolwarm; shading interp ;colorbar; drawnow
        hold on
        plot_turbine
        Plot_options('x/D','r/D','U_x')
        close all
%         fig_Mem=figure;Members_Ux(qc,reshape(NuT',Nx*Nr,1));title(['Members of new U_x equation - Iteration ',num2str(nIte)]);axis tight
      end 
        
    end
    %% Calculating converged field
    [NuT,DnutdUr,DnutdUt,DnutdUx]=EV_closure_All(NuT0,ML,qc,NuT_smooth_par);
    [JA,F,~] = JacobianSponge_AD_ML(qc,NuT,DnutdUr,DnutdUt,DnutdUx,J_old,F_old);%jacobian and residuals calculator
    %% Rearrangment of the results
%     qc=qc0;
    Ur=reshape(qc(1:Nx*Nr),Nx,Nr).'; Ut=reshape(qc(Nx*Nr+1:2*Nx*Nr),Nx,Nr).';
    Ux=reshape(qc(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).'; p=reshape(Matrices.MtoL*qc(3*Nx*Nr+1:3*Nx*Nr+NxGC*NrGC),Nx,Nr).';
    NuT_mat=reshape(NuT,Nx,Nr).';
    %% output
    RANS.Ur=Ur;RANS.Ut=Ut;RANS.Ux=Ux;RANS.p=p; RANS.qc=qc; RANS.ML = ML;
    RANS.L2Err=Error; RANS.Jacobian=JA;RANS.NuT=NuT_mat; RANS.F = F;