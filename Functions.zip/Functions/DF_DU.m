function [DFx,DFt] = DF_DU(Ux,Ut);
Global
Nt = length(TSR); %number of turbines
rGLC = Matrices.RmGLC(:,1);
CH = [zeros(Nr-Nrd,1); ch];
[Urel,~] = Angle_of_Attack(Ux,Ut); Urel = [zeros(Nr-Nrd,Nt);Urel];%relative velocity
[C_TH,C_TG,~,~] = Nondim_coeff(Ux,Ut); C_TH = [zeros(Nr-Nrd,Nt);C_TH];C_TG = [zeros(Nr-Nrd,Nt);C_TG];%nondimensional coefficients
[fx,ft] = Correction(Ux,Ut); fx.all = [zeros(Nr-Nrd,Nt);fx.all];ft.all = [zeros(Nr-Nrd,Nt);ft.all];%Prandtl's corrective coefficients

[DUrel_DUx,DUrel_DUt] = Durel_DU(Ux,Ut); %Der. of relative velocity with respect components
DUrel_DUx = [zeros(Nr-Nrd,Nt);DUrel_DUx]; DUrel_DUt = [zeros(Nr-Nrd,Nt); DUrel_DUt];

[Df_x,Df_t] = Df_Dalpha(Ux,Ut); %Der. of corrective coefficients with r. to alpha
Df_x = [zeros(Nr-Nrd,Nt);Df_x]; Df_t = [zeros(Nr-Nrd,Nt);Df_t];

Dalpha = Dalpha_DU(Ux,Ut); %Der. of alpha with respect to components
Dalpha.Ux = [zeros(Nr-Nrd,Nt); Dalpha.Ux]; Dalpha.Ut = [zeros(Nr-Nrd,Nt);Dalpha.Ut];

[DCth,DCtg] = DC_DU(Ux,Ut); %Der. of nondimensional coeff's with respect to components
DCth.Ux = [zeros(Nr-Nrd,Nt); DCth.Ux]; DCth.Ut = [zeros(Nr-Nrd,Nt); DCth.Ut];
DCtg.Ux = [zeros(Nr-Nrd,Nt); DCtg.Ux]; DCtg.Ut = [zeros(Nr-Nrd,Nt); DCtg.Ut];

DFx.Ux = zeros(Nr,Nt); DFx.Ut = DFx.Ux;
DFt.Ux = zeros(Nr,Nt); DFt.Ut = DFt.Ux;

for k=1:Nt
    DFx.Ux(Ind_R(k):nac_ind(k)-1,k) = 3.*CH(Ind_R(k):nac_ind(k)-1)./(4*pi*rGLC(Ind_R(k):nac_ind(k)-1)).*(2*Urel(Ind_R(k):nac_ind(k)-1,k).*DUrel_DUx(Ind_R(k):nac_ind(k)-1,k).*C_TH(Ind_R(k):nac_ind(k)-1,k).*fx.all(Ind_R(k):nac_ind(k)-1,k)+...
                                    Urel(Ind_R(k):nac_ind(k)-1,k).^2.*DCth.Ux(Ind_R(k):nac_ind(k)-1,k).*fx.all(Ind_R(k):nac_ind(k)-1,k) + Urel(Ind_R(k):nac_ind(k)-1,k).^2.*C_TH(Ind_R(k):nac_ind(k)-1,k).*Df_x(Ind_R(k):nac_ind(k)-1,k).*Dalpha.Ux(Ind_R(k):nac_ind(k)-1,k));
    DFx.Ux(end,k) = 0.5*esp*Urel(end,k)^(esp-1)*DUrel_DUx(end).*exp(-0.5*(rGLC(end)/(sigma_r(k))).^2)*CDhub;
    
    DFx.Ut(Ind_R(k):nac_ind(k)-1,k) = 3.*CH(Ind_R(k):nac_ind(k)-1)./(4*pi*rGLC(Ind_R(k):nac_ind(k)-1)).*(2*Urel(Ind_R(k):nac_ind(k)-1,k).*DUrel_DUt(Ind_R(k):nac_ind(k)-1,k).*C_TH(Ind_R(k):nac_ind(k)-1,k).*fx.all(Ind_R(k):nac_ind(k)-1,k)+...
                                    Urel(Ind_R(k):nac_ind(k)-1,k).^2.*DCth.Ut(Ind_R(k):nac_ind(k)-1,k).*fx.all(Ind_R(k):nac_ind(k)-1,k) + Urel(Ind_R(k):nac_ind(k)-1,k).^2.*C_TH(Ind_R(k):nac_ind(k)-1,k).*Df_x(Ind_R(k):nac_ind(k)-1,k).*Dalpha.Ut(Ind_R(k):nac_ind(k)-1,k));
    
    DFx.Ut(end,k) = 0.5*esp*Urel(end,k)^(esp-1)*DUrel_DUt(end).*exp(-(rGLC(end)/(sigma_r(k))).^2)*CDhub;
    
    DFt.Ux(:,k) = 3.*CH./(4*pi*rGLC).*(2*Urel(:,k).*DUrel_DUx(:,k).*C_TG(:,k).*ft.all(:,k)+...
                                    Urel(:,k).^2.*DCtg.Ux(:,k).*ft.all(:,k) + Urel(:,k).^2.*C_TG(:,k).*Df_t(:,k).*Dalpha.Ux(:,k));
    DFt.Ux(end,k) = 0;
    
    DFt.Ut(:,k) = 3.*CH./(4*pi*rGLC).*(2*Urel(:,k).*DUrel_DUt(:,k).*C_TG(:,k).*ft.all(:,k)+...
                                    Urel(:,k).^2.*DCtg.Ut(:,k).*ft.all(:,k) + Urel(:,k).^2.*C_TG(:,k).*Df_t(:,k).*Dalpha.Ut(:,k));
    DFt.Ut(end,k) = 0;
end
end