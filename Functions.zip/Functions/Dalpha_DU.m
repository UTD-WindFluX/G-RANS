function D=Dalpha_DU(Ux,Ut);
Global
Nt = length(TSR); %number of turbines
D.Ux = zeros(Nrd,Nt); D.Ut = zeros(Nrd,Nt);
rGLC = Matrices.RmGLC(Ind_R:end,1);
Utrel = zeros(Nrd,Nt);
omega = 2*TSR;
for k=1:Nt
    Utrel(:,k) = (omega(k)*rGLC-Ut(:,k));
    D.Ux(:,k) = Utrel(:,k)./(Utrel(:,k).^2+Ux(:,k).^2);
    D.Ut(:,k) = Ux(:,k)./(Utrel(:,k).^2+Ux(:,k).^2);
end
end