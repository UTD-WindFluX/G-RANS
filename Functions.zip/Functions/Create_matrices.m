function [Matrices] = Create_matrices(Nx,Nr,NxGC,NrGC,xmin,xmax,rmax,r_Map,x_Map,Lx,Lr);    
%creates the derivation and grid-change matrices
    [xGLC,D1x]=nodiD1chebGLC(Nx-1);
    [yGLC,D1y]=nodiD1chebGLC(Nr-1);  

    [xGC,D1xGC]=nodichebGC(NxGC);
    [yGC,D1yGC]=nodichebGC(NrGC);
    
    switch r_Map
        case 0 %linear
            r_GLC=rmax/2*(1+yGLC);
            r_GC=rmax/2*(1+yGC);
            MD1r=2/rmax*D1y;
            MD1rGC=2/rmax*D1yGC;
            D2y=D1y*D1y;
            y1GLC=(2/rmax)*ones(size(r_GLC));
%             y1GC=(2/rmax)*ones(size(rGC));
            MD2r=(2/rmax)^2*D2y;

        case 1 %algebraic
            alfa=(2*Lr+rmax)/rmax;
            r_GLC=Lr*(1+yGLC)./(alfa-yGLC);
            r_GC=Lr*(1+yGC)./(alfa-yGC);
            
            y1GLC=Lr*(alfa+1)./(r_GLC+Lr).^2;
            y2GLC=-2*Lr*(alfa+1)./(r_GLC+Lr).^3;
            y1GC=Lr*(alfa+1)./(r_GC+Lr).^2;

            MD1r=diag(y1GLC)*D1y;
            MD1rGC=diag(y1GC)*D1yGC;
            D2y=D1y*D1y;
            MD2r=(diag(y1GLC)).^2*D2y+diag(y2GLC)*D1y;
        case 2 %nonlinear
            a = Lr;
            r0 = 0.5*(0+rmax);
            b = 2*a/(rmax-0);
            r_GLC = r0 + a*yGLC./(1 + b^2 - yGLC.^2).^0.5;
            r_GC = r0 + a*yGC./(1 + b^2 - yGC.^2).^0.5;
            % 1st derivative
            alpha = ((1+b^2)./(a^2 + (r_GLC-r0).^2)); alpha_GC = ((1+b^2)./(a^2 + (r_GC-r0).^2));
            y1GLC = a^2*sqrt(alpha)./(a^2 + (r_GLC-r0).^2); 
            r1GC = a^2*sqrt(alpha_GC)./(a^2 + (r_GC-r0).^2);
            MD1r=diag(y1GLC)*D1y;
            MD1rGC=diag(r1GC)*D1yGC;
            % 2nd derivative
            r2GLC = -3*sqrt(alpha).*a^2.*(r_GLC-r0)./(a^2 + (r_GLC-r0).^2).^2;
            D2r=D1y*D1y;
            MD2r=(diag(y1GLC)).^2*D2r+diag(r2GLC)*D1y;
        case 3 %Uniform mapping
            Uniform_nodes
            y1GLC = der;
            MD1r=diag(y1GLC)*D1y;
            MD1rGC=diag(r1GC)*D1yGC;
            % 2nd derivative
            r2GLC = der2;
    end

    switch x_Map
        case 0 %linear
            x_GLC=(xmax-xmin)/2*(1+xGLC)+xmin;
            x_GC=(xmax-xmin)/2*(1+xGC)+xmin;

            MD1X=2/(xmax-xmin)*D1x;
            MD1XGC=2/(xmax-xmin)*D1xGC;
            D2x=D1x*D1x;
            x1GLC=(2/(xmax-xmin))*ones(size(x_GLC));
            x1GC=(2/xmax)*ones(size(xGC));
            MD2X=(2/(xmax-xmin))^2*D2x;
            x2GLC = 0*x1GLC;

        case 1 %algebraic
            alfa=(2*Lx+(xmax-xmin))/(xmax-xmin);
            x_GLC=Lx*(1+xGLC)./(alfa-xGLC)+xmin;
            x_GC=Lx*(1+xGC)./(alfa-xGC)+xmin;

            x1GLC=Lx*(alfa+1)./(x_GLC+Lx).^2;
            x2GLC=-2*Lx*(alfa+1)./(x_GLC+Lx).^3;
            x1GC=Lx*(alfa+1)./(x_GC+Lx).^2;

            MD1X=diag(x1GLC)*D1x;
            MD1XGC=diag(x1GC)*D1xGC;
            D2x=D1x*D1x;
            MD2X=(diag(x1GLC)).^2*D2x+diag(x2GLC)*D1x;
        case 2 %nonlinear
            a = Lx;
            x0 = 0.5*(xmin+xmax);
            b = 2*a/(xmax-xmin);
            x_GLC = x0 + a*xGLC./(1 + b^2 - xGLC.^2).^0.5;
            x_GC = x0 + a*xGC./(1 + b^2 - xGC.^2).^0.5;
            % 1st derivative
            alpha = ((1+b^2)./(a^2 + (x_GLC-x0).^2)); alpha_GC = ((1+b^2)./(a^2 + (x_GC-x0).^2));
            x1GLC = a^2*sqrt(alpha)./(a^2 + (x_GLC-x0).^2); x1GC = a^2*sqrt(alpha_GC)./(a^2 + (x_GC-x0).^2);
            MD1X=diag(x1GLC)*D1x;
            MD1XGC=diag(x1GC)*D1xGC;
            % 2nd derivative
            x2GLC = -3*sqrt(alpha).*a^2.*(x_GLC-x0)./(a^2 + (x_GLC-x0).^2).^2;
            D2x=D1x*D1x;
            MD2X=(diag(x1GLC)).^2*D2x+diag(x2GLC)*D1x;
        case 3 %nonlinear with approximated derivatives
            Matrix_approx
            MD1X=diag(x1GLC)*D1x;
            MD1XGC=diag(x1GC)*D1xGC;
            D2x=D1x*D1x;
            MD2X=(diag(x1GLC)).^2*D2x+diag(x2GLC)*D1x;
        case 4 %multiple turbines
            New_mapping
            x_GLC = X;
            x_GC = XGC;
            x1GLC = d_eta(X); x1GC = d_eta(XGC);
            x2GLC = d2_eta(X);
            MD1X=diag(x1GLC)*D1x;
            MD1XGC=diag(x1GC)*D1xGC;
            D2x=D1x*D1x;
            MD2X=(diag(x1GLC)).^2*D2x+diag(x2GLC)*D1x;
    end

    %interpol
    % from Gauss lobatto (velocity) to Gauss (pressure)
    [MfrLx]=Interpolate_nodes(Nx,xGLC,xGC,0);
    [MfrLy]=Interpolate_nodes(Nr,yGLC,yGC,0);
    % from Gauss (pressure) to Gauss lobatto (velocity)
    [MtoLx]=Interpolate_nodes(Nx,xGLC,xGC,1);
    [MtoLy]=Interpolate_nodes(Nr,yGLC,yGC,1);

    %% 2D

    %GLC
    IxGLC=eye(Nx);
    IyGLC=eye(Nr);

    D1bi_X=kron(IyGLC,MD1X);
    D2bi_X=kron(IyGLC,MD2X);
    D1bi_r=kron(MD1r,IxGLC);
    D2bi_r=kron(MD2r,IxGLC);    
    [XmGLC,RmGLC]=meshgrid(x_GLC,r_GLC);

    %GC
     IxGC=eye(NxGC);
     IyGC=eye(NrGC);

     D1biGC_X=kron(IyGC,MD1XGC);
     D1biGC_r=kron(MD1rGC,IxGC);
     [XmGC,RmGC]=meshgrid(x_GC,r_GC); 

    %grid-change matrices
    MfrL=kron(MfrLy,MfrLx);
    MtoL=kron(MtoLy,MtoLx);
    
   
    %% output
    Matrices.D1_X=D1bi_X;
    Matrices.D2_X=D2bi_X;
    Matrices.D1_r=D1bi_r;
    Matrices.D2_r=D2bi_r;
    Matrices.D1GC_X=D1biGC_X;
    Matrices.D1GC_r=D1biGC_r;
    Matrices.MfrL=MfrL;
    Matrices.MtoL=MtoL;
    Matrices.XmGLC=XmGLC;
    Matrices.RmGLC=RmGLC;
    Matrices.XmGC=XmGC;
    Matrices.RmGC=RmGC;
    Matrices.x1GLC=x1GLC;
    Matrices.y1GLC=y1GLC;
    Matrices.x2GLC=x2GLC;
    Matrices.xGLC = xGLC;
    Matrices.yGLC = yGLC;
    Matrices.MD2X = MD2X;
    Matrices.x1GC = x1GC;
end