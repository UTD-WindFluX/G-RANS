clear
% close all
addpath ./Functions
Global
Nr = 30;
Pre_processing %Here the input parameters are settled
CL_CD
Turbulence_model = 'ML';ML_coeff = [0 0.03 0.3142 x_T];DoFs = length(ML_coeff);BL_approx=1;
lm = ML_fun(ML_coeff);
out_BC = 'non-homogeneous_Neumann';
up_BC = 'Slip';
v_r = nac_ind-3; v_x = Ind; j_glob = (v_r-1)*Nx + v_x; %Global velocity index
delta = 1e-06;
load('./BT_Results/TSR_3Slip/Res.mat');
Initial_field = [reshape(Res.Ur.',Nx*Nr,1); reshape(Res.Ut.',Nx*Nr,1); reshape(Res.Ux.',Nx*Nr,1); zeros(NxGC*NrGC,1)];

Ux = reshape(Initial_field(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).'; Ux2 = Ux; Ux1 = Ux;
Ut = reshape(Initial_field(Nx*Nr+1:2*Nx*Nr),Nx,Nr).'; Ut2 = Ut; Ut1 = Ut;
Ux2(v_r,v_x) = Ux(v_r,v_x)+delta; Ux1(v_r,v_x) = Ux(v_r,v_x)-delta;

qx2 = [Initial_field(1:Nx*Nr); reshape(Ut.',Nx*Nr,1); reshape(Ux2.',Nx*Nr,1); zeros(NxGC*NrGC,1)];
qx1 = [Initial_field(1:Nx*Nr); reshape(Ut.',Nx*Nr,1); reshape(Ux1.',Nx*Nr,1); zeros(NxGC*NrGC,1)];

Ut2(v_r,v_x) = Ut(v_r,v_x)+delta; Ut1(v_r,v_x) = Ut(v_r,v_x)-delta;
qt2 = [Initial_field(1:Nx*Nr); reshape(Ut2.',Nx*Nr,1); reshape(Ux.',Nx*Nr,1); zeros(NxGC*NrGC,1)];
qt1 = [Initial_field(1:Nx*Nr); reshape(Ut1.',Nx*Nr,1); reshape(Ux.',Nx*Nr,1); zeros(NxGC*NrGC,1)];
%%
[J22,J23,J32,J33,~] = Jacobian_Forcing(Initial_field);
% [~,~,~,~,Fx2] = Jacobian_Forcing(qx2); [~,~,~,~,Fx1] = Jacobian_Forcing(qx1);
[~,~,~,~,F2] = Jacobian_Forcing(qx2); 
[~,~,~,~,F1] = Jacobian_Forcing(qx1); 
% [NuT,DNuTdUr,DNuTdUt,DNuT_dUx,S] = EV_closure_All(0,lm,Initial_field,NuT_smooth_par);
% [JA,F] = JacobianSponge_AD_ML(Initial_field,NuT,DNuTdUr,DNuTdUt,DNuT_dUx);
% 
% [NuT,DNuTdUr,DNuTdUt,DNuT_dUx,S] = EV_closure_All(0,lm,qt2,NuT_smooth_par);
% [~,F2] = JacobianSponge_AD_ML(qt2,NuT,DNuTdUr,DNuTdUt,DNuT_dUx); 
% 
% [NuT,DNuTdUr,DNuTdUt,DNuT_dUx,S] = EV_closure_All(0,lm,qt1,NuT_smooth_par);
% [~,F1] = JacobianSponge_AD_ML(qt1,NuT,DNuTdUr,DNuTdUt,DNuT_dUx);
Derx = (F2(Nx*Nr+1:2*Nx*Nr)-F1(Nx*Nr+1:2*Nx*Nr))/(2*delta);
%%
% DFx_DUx_app = (Fx2(2*Nx*Nr+1:3*Nx*Nr)-Fx1(2*Nx*Nr+1:3*Nx*Nr))/(2*delta);
% Appr_x = (Fx2(i_glob) - Fx1(i_glob))/(2*delta);
% J33(i_glob,j_glob);

% DFx_DUx = reshape(J33((Ind+(i_r-1)*Nx),:),Nx,Nr).';
% Jx = reshape(JA(2*Nx*Nr+1:3*Nx*Nr,j_glob),Nx,Nr).';
% Dert_x = reshape(Dert(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
% DFt_DUt_app = reshape((Ft2(Nx*Nr+1:2*Nx*Nr)-Ft1(Nx*Nr+1:2*Nx*Nr))/(2*delta),Nx,Nr).';
% DFt_DUt = reshape(J22((Ind+(i_r-1)*Nx),:),Nx,Nr).';

% diffx = DFx_DUx_app-DFx_DUx; difft = DFt_DUt_app-DFt_DUt;
figure
plot(J23(:,j_glob),'*-')
hold on
plot(Derx,'o-');grid on
diffx=J23(:,j_glob)-Derx;
%
% figure
% plot(diffx,'*-');
% 
% find(diffx==max(diffx))
diff2d = reshape(diffx,Nx,Nr).';
JA2d = reshape(J22(:,j_glob),Nx,Nr).';
figure
surf(Matrices.XmGLC,Matrices.RmGLC,diff2d);