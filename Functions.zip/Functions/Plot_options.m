function [] = Plot_options(xlab,ylab,tit);
xlabel(xlab,'fontsize',20,'FontName','Times','FontWeight','normal');
ylabel(ylab,'fontsize',20,'FontName','Times','FontWeight','normal');
title (tit,'fontsize',20,'fontweight','bold');
grid on;box on;
set(gca,'FontSize',16,'FontName','Times','FontWeight','normal');
fig = gcf;
fig.PaperPositionMode = 'auto';
end