% clear all
% close all
addpath ./Functions
Global
Pre_processing %Here the input parameters are settled
CL_CD
Turbulence_model = 'EV';
out_BC = 'non-homogeneous_Neumann';
v_r = 16; v_x = Ind(end); j_glob = (v_r-1)*Nx + v_x; %Velocity global index
delta = .0001;
Initial_field = rand(3*Nx*Nr+NxGC*NrGC,1);

Ux = reshape(Initial_field(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).'; Ux2 = Ux; Ux1 = Ux;
Ut = reshape(Initial_field(Nx*Nr+1:2*Nx*Nr),Nx,Nr).'; Ut2 = Ut; Ut1 = Ut;
Ux2(v_r,v_x) = Ux(v_r,v_x)+delta; Ux1(v_r,v_x) = Ux(v_r,v_x)-delta;

qx2 = [Initial_field(1:Nx*Nr); reshape(Ut.',Nx*Nr,1); reshape(Ux2.',Nx*Nr,1); zeros(NxGC*NrGC,1)];
qx1 = [Initial_field(1:Nx*Nr); reshape(Ut.',Nx*Nr,1); reshape(Ux1.',Nx*Nr,1); zeros(NxGC*NrGC,1)];

Ut2(v_r,v_x) = Ut(v_r,v_x)+delta; Ut1(v_r,v_x) = Ut(v_r,v_x)-delta;
qt2 = [Initial_field(1:Nx*Nr); reshape(Ut2.',Nx*Nr,1); reshape(Ux.',Nx*Nr,1); zeros(NxGC*NrGC,1)];
qt1 = [Initial_field(1:Nx*Nr); reshape(Ut1.',Nx*Nr,1); reshape(Ux.',Nx*Nr,1); zeros(NxGC*NrGC,1)];
%%
% [J22,J23,J32,J33,~] = Jacobian_Forcing(Initial_field);
% [~,~,~,~,Fx2] = Jacobian_Forcing(qx2); [~,~,~,~,Fx1] = Jacobian_Forcing(qx1);
% [~,~,~,~,Ft2] = Jacobian_Forcing(qt2); [~,~,~,~,Ft1] = Jacobian_Forcing(qt1); 
[JA,F] = JacobianSponge_AD(Initial_field,zeros(Nx*Nr,1));
[~,F2] = JacobianSponge_AD(qt2,zeros(Nx*Nr,1)); [~,F1] = JacobianSponge_AD(qt1,zeros(Nx*Nr,1));
Dert = (F2-F1)/(2*delta);
%%
% DFx_DUx_app = (Fx2(2*Nx*Nr+1:3*Nx*Nr)-Fx1(2*Nx*Nr+1:3*Nx*Nr))/(2*delta);
% Appr_x = (Fx2(i_glob) - Fx1(i_glob))/(2*delta);
% J33(i_glob,j_glob);

% DFx_DUx = reshape(J33((Ind+(i_r-1)*Nx),:),Nx,Nr).';
% Jx = reshape(JA(2*Nx*Nr+1:3*Nx*Nr,j_glob),Nx,Nr).';
% Dert_x = reshape(Dert(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
% DFt_DUt_app = reshape((Ft2(Nx*Nr+1:2*Nx*Nr)-Ft1(Nx*Nr+1:2*Nx*Nr))/(2*delta),Nx,Nr).';
% DFt_DUt = reshape(J22((Ind+(i_r-1)*Nx),:),Nx,Nr).';

% diffx = DFx_DUx_app-DFx_DUx; difft = DFt_DUt_app-DFt_DUt;
figure
plot(JA(:,Nx*Nr + j_glob),'*-')
hold on
plot(Dert,'o-');grid on
%
% figure
% pcolor(Matrices.XmGLC,Matrices.RmGLC,Jt); title ('Exact')
% figure
% pcolor(Matrices.XmGLC,Matrices.RmGLC,Dert_x); title ('Approx.')
%%
% I = 5;
% Uxc = Ux(Ind_R:end,Ind); Utc = Ut(Ind_R:end,Ind);
% Uxc2 = Uxc; Uxc2(I) = Uxc(I)+delta; Uxc1 = Uxc; Uxc1(I) = Uxc(I)-delta;
% [Fx2,~] = Forcing(Uxc2,Utc); [Fx1,~] = Forcing(Uxc1,Utc);
% Der_x = (Fx2-Fx1)/(2*delta);
% rGLC = Matrices.RmGLC(Ind_R:end,1);
%%
% figure
% plot(rGLC,Der_x,'*-');