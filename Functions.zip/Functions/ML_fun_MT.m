%This function calculates the ML as a function of x for given coefficent(s)
function ML=ML_fun(ML_coeff)
    Global
    XmGLC = Matrices.XmGLC;
    if Nt ==1 || min(TSR) == 0
        switch DoFs
            case 1 %constant
                ML=ones(Nr,Nx)*ML_coeff(1);
            case 2 %linear
                ML=(XmGLC+xmin)*ML_coeff(2)+ML_coeff(1);
            case 3 %3P logistic+incoming turbunlence
                ML_inf=ML_coeff(1);
                k=ML_coeff(2);
                X_trans=ML_coeff(3);
                ML=ML_inf./(1+exp(-k*(XmGLC+xmin-X_trans)));
            case 4 %4P logisitc - LES assestment
                a=ML_coeff(1);
                b=ML_coeff(2);
                c=ML_coeff(3);
                x_inf=ML_coeff(4);
                ML=(2*a-b)+2*(b-a)./(1+exp(-c*(XmGLC-x_inf)));
                ML(ML<0)=0;
        end
    end
    
    if Nt==2 && min(TSR) > 0
        a=ML_coeff(1);
        b=ML_coeff(2);
        c=ML_coeff(3);
        lm_isolated = @(x,x_inf) (2*a-b)+2*(b-a)./(1+exp(-c*(x-x_inf)));
        lm_inc = lm_isolated(x_T(2),x_T(1));
        c_ML = [1 max(59.28*lm_inc,0.9)];
        
        ML = c_ML(1)*lm_isolated(XmGLC,x_T(1)).*(XmGLC>x_T(1)).*(XmGLC<=x_T(2)) + (c_ML(2)*lm_isolated(XmGLC,x_T(2))+lm_inc).*(XmGLC>=x_T(2));
    end
end