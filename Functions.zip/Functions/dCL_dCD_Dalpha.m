function [DCL,DCD] = dCL_dCD_Dalpha(alpha);
Global
Nt = length(TSR);
DCL = interp1(angle_int,CL_alpha,alpha,'spline','extrap');
DCD = interp1(angle_int,CD_alpha,alpha,'spline','extrap');
% for k=1:Nt
%     for i=1:Nrd
%         DCL(i,k) = interp1(angle_int,CL_alpha,alpha(k),'linear','extrap');
%         DCD(i,k) = interp1(angle_int,CD_alpha,alpha(k),'linear','extrap');
%     end
% end
end