function [J22,J23,J32,J33,F] = Jacobian_Forcing(qc);
Global
Utc = reshape(qc(Nx*Nr+1:2*Nx*Nr),Nx,Nr).'; 
Uxc = reshape(qc(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
[Fx1d,Ft1d] = Forcing([Uxc(Ind_R:end-1,Ind);Uxc(end,Ind_hub)],Utc(Ind_R:end,Ind));%calculus of forcing term starting from Ux, Utheta on induction location

F = zeros(3*Nx*Nr+NxGC*NrGC,1);
for k=1:length(TSR)
    
    FxV = zeros(Nr,Nx); 
    FxV(1:Ind_fx-1,Ind(k)) = Fx1d(1:Ind_fx-1,k); 
    FxV(Ind_fx:end,Ind_hub(k)) = Fx1d(Ind_fx:end,k);
    
    Spread_x = spreading(sigma_x); %spreading matrix of x-forcing
    Spread_t = spreading(sigma_t); %spreading matrix of theta-forcing

    FtV = zeros(Nr,Nx); FtV(:,Ind(k)) = Ft1d(:,k);

    Fx = Spread_x*reshape(FxV.',Nx*Nr,1); Fx = reshape(Fx,Nx,Nr).';
    Ft = Spread_t*reshape(FtV.',Nx*Nr,1); Ft = reshape(Ft,Nx,Nr).';
    F = F + [zeros(Nx*Nr,1); reshape(Ft.',Nx*Nr,1); reshape(Fx.',Nx*Nr,1); zeros(NxGC*NrGC,1)];

    [DFx,DFt] = DF_DU(Uxc(Ind_R:end,Ind),Utc(Ind_R:end,Ind));
    DFx_DUxV = zeros(Nr,Nx); 
    DFx_DUxV(1:Ind_fx-1,Ind(k)) = DFx.Ux(1:Ind_fx-1,k); 
    DFx_DUxV(Ind_fx:end,Ind_hub(k)) = DFx.Ux(Ind_fx:end,k); %DFx_DUxV = diag(reshape(DFx_DUxV.',Nx*Nr,1));
    
    DFx_DUtV = zeros(Nr,Nx); DFx_DUtV(:,Ind(k)) = DFx.Ut(:,k); %DFx_DUtV=diag(reshape(DFx_DUtV.',Nx*Nr,1));
    DFt_DUxV = zeros(Nr,Nx); DFt_DUxV(:,Ind(k)) = DFt.Ux(:,k); %DFt_DUxV=diag(reshape(DFt_DUxV.',Nx*Nr,1));
    DFt_DUtV = zeros(Nr,Nx); DFt_DUtV(:,Ind(k)) = DFt.Ut(:,k); %DFt_DUtV=diag(reshape(DFt_DUtV.',Nx*Nr,1));
end
    DFx_DUxV = reshape(DFx_DUxV.',Nx*Nr,1); DFx_DUtV = reshape(DFx_DUtV.',Nx*Nr,1);
    DFt_DUxV = reshape(DFt_DUxV.',Nx*Nr,1); DFt_DUtV = reshape(DFt_DUtV.',Nx*Nr,1);
    J22 = zeros(Nx*Nr,Nx*Nr); J23 = J22; J32 = J22; J33 = J22;
%     
%     J22 = Spread_t.*DFt_DUtV;
%     J23 = Spread_t.*DFt_DUxV;
%     J32 = Spread_x.*DFx_DUtV;
%     J33 = Spread_x.*DFx_DUxV;
    for i=1:Nx*Nr
        for j=1:Nx*Nr
            J22(i,j) = Spread_t(i,j)*DFt_DUtV(j);
            J23(i,j) = Spread_t(i,j)*DFt_DUxV(j);
            J32(i,j) = Spread_x(i,j)*DFx_DUtV(j);
            J33(i,j) = Spread_x(i,j)*DFx_DUxV(j);
        end
    end
% figure
% surf(Matrices.XmGLC,Matrices.RmGLC,Fx);colorbar;drawnow
end

