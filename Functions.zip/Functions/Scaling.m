function F = Scaling(S,S1d);
Global
F = zeros(size(S));

for i=Ind_R:length(S(:,1))
    Int = sqrt(S(i,:))*IWx*sqrt(S(i,:)).';
    if Int==0
        F(i,:) = S(i,:);
    else
        F(i,:) = S(i,:)/S1d(i);
    end
    
end
end