Ux_avg = zeros(Nx,1); Ux_err = zeros(Nx,1);
r = Matrices.RmGLC(:,1);

for i=1:length(Matrices.XmGLC(1,:))
    Ux_avg(i) = -2*trapz(r,r.*Ux_interp(:,i))/max(r)^2;
    Ux_err(i) = -2*trapz(r,r.*(RANS.Ux(:,i)-Ux_interp(:,i))/max(r)^2);
end