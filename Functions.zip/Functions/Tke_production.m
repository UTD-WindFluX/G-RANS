function [P,DP_DUr,DP_DUt,DP_DUx,DP_Dtke] = Tke_production(lm,qc); %production of turbulent kinetic energy and its derivative with respect to all variables
Global

D1_X=Matrices.D1_X;
D1_r=Matrices.D1_r;
Mat_smooth = Matrices.Mat_smooth_Gauss;
c=0.55;

Ur = qc(1:Nx*Nr);
Ut = qc(Nx*Nr+1:2*Nx*Nr);
Ux = qc(2*Nx*Nr+1:3*Nx*Nr);
tke = qc(3*Nx*Nr+NxGC*NrGC+1:end);
Index = find(tke==0);
%% Residual contribution
grad_U_S = (2*(D1_r*Ur).^2 + (D1_X*Ur).*(D1_X*Ur+D1_r*Ux) + (D1_r*Ut).^2 + (D1_X*Ut).^2 + (D1_r*Ux).*(D1_r*Ux+D1_X*Ur) + 2*(D1_X*Ux).^2);
P = Mat_smooth*c*abs(tke).^0.5.*lm.*grad_U_S; %production of tke
%% Jacobian contribution
M = diag(Mat_smooth*0.5*c*abs(tke).^(-0.5).*lm);
M(Index,Index) = 1e+5;%set to high-valued derivative where tke=0 in order to avoid infinite quantity
DP_DUr = diag(Mat_smooth*c*abs(tke).^0.5.*lm)*(4*diag(D1_r*Ur)*D1_r + diag(D1_X*Ur+D1_r*Ux)*D1_X + diag(D1_X*Ur)*D1_X + diag(D1_r*Ux)*D1_X);%derivative of P with respect to Ur
DP_DUt = diag(Mat_smooth*c*abs(tke).^0.5.*lm)*(2*diag(D1_r*Ut)*D1_r + 2*diag(D1_X*Ut)*D1_X); %derivative of tke with respect to Ut
DP_DUx = diag(Mat_smooth*c*abs(tke).^0.5.*lm)*(diag(D1_X*Ur)*D1_r + diag(D1_r*Ux+D1_X*Ur)*D1_r + diag(D1_r*Ux)*D1_r + 4*diag(D1_X*Ux)*D1_X); %derivative of tke with respect to Ux
DP_Dtke = M.*diag(grad_U_S); %derivative of tke production with respect to tke
end