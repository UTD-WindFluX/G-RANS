function S = spreading(stdev);
Global
Nt = length(TSR); %number of turbines
XmGLC = Matrices.XmGLC(1,:);
S=zeros(Nx*Nr);
for l=1:Nt
    %Normalized Gauss spreading function
    Gauss = makedist('Normal','mu',x_T(l),'sigma',stdev(l));
    t_t = truncate(Gauss,x_T(l)-1,x_T(l)+1);
    G = pdf(t_t,XmGLC);
    Area = sqrt(G)*IWx*sqrt(G');
    G = G/Area;
    for j=1:Ind_fx(l)-1 %blade force spreading
        k = (j-1)*Nx + Ind(l);
        S((j-1)*Nx+1:j*Nx,k) = [G'];
    end
    
    for j=Ind_fx(l):Nr %dhub force spreading
        k = (j-1)*Nx + Ind_hub(l);
        S((j-1)*Nx+1:j*Nx,k) = [G'];
    end
end
end