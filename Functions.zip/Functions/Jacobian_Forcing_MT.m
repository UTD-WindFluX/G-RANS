function [J22,J23,J32,J33,F] = Jacobian_Forcing_MT(qc);
Global
Utc = reshape(qc(Nx*Nr+1:2*Nx*Nr),Nx,Nr).'; 
Uxc = reshape(qc(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
[Fx1d,Ft1d] = Forcing([Uxc(Ind_R:end-1,Ind);Uxc(end,Ind_hub)],Utc(Ind_R:end,Ind));%calculus of forcing term starting from Ux, Utheta on induction location

F = zeros(3*Nx*Nr+NxGC*NrGC,1);
FxV= zeros(Nr,Nx,Nt); 
FtV = zeros(Nr,Nx,Nt);

DFx_DUxV = zeros(Nr,Nx);
DFx_DUtV = zeros(Nr,Nx);
DFt_DUxV = zeros(Nr,Nx);
DFt_DUtV = zeros(Nr,Nx);

Spread_x = spreading(sigma_x); %spreading matrix of x-forcing
Spread_t = spreading(sigma_t); %spreading matrix of theta-forcing
for k=1:Nt
    
    FxV(1:Ind_fx(k)-1,Ind(k),k) = Fx1d(1:Ind_fx(k)-1,k); 
    FxV(Ind_fx(k):end,Ind_hub(k),k) = Fx1d(Ind_fx(k):end,k);
    
    FtV(:,Ind(k),k) = Ft1d(:,k);

    Fx(:,k) = Spread_x*reshape(FxV(:,:,k).',Nx*Nr,1); %Fx(:,:,k) = reshape(Fx,Nx,Nr).';
    Ft(:,k) = Spread_t*reshape(FtV(:,:,k).',Nx*Nr,1); %Ft(:,k) = reshape(Ft,Nx,Nr).';

    [DFx,DFt] = DF_DU([Uxc(Ind_R:end-1,Ind);Uxc(end,Ind_hub)],Utc(Ind_R:end,Ind));
    
    if isequaln(TSR(k),0) == 0
        DFx_DUxV(1:Ind_fx(k)-1,Ind(k)) = DFx.Ux(1:Ind_fx(k)-1,k); 
        DFx_DUxV(Ind_fx(k):end,Ind_hub(k)) = DFx.Ux(Ind_fx(k):end,k); %DFx_DUxV = diag(reshape(DFx_DUxV.',Nx*Nr,1));

        DFx_DUtV(:,Ind(k)) = DFx.Ut(:,k); %DFx_DUtV=diag(reshape(DFx_DUtV.',Nx*Nr,1));
        DFt_DUxV(:,Ind(k)) = DFt.Ux(:,k); %DFt_DUxV=diag(reshape(DFt_DUxV.',Nx*Nr,1));
        DFt_DUtV(:,Ind(k)) = DFt.Ut(:,k); %DFt_DUtV=diag(reshape(DFt_DUtV.',Nx*Nr,1));
    end
end
    F = [zeros(Nx*Nr,1); reshape(sum(Ft,2).',Nx*Nr,1); reshape(sum(Fx,2).',Nx*Nr,1); zeros(NxGC*NrGC,1)];

    DFx_DUxV = reshape(DFx_DUxV.',Nx*Nr,1); DFx_DUtV = reshape(DFx_DUtV.',Nx*Nr,1);
    DFt_DUxV = reshape(DFt_DUxV.',Nx*Nr,1); DFt_DUtV = reshape(DFt_DUtV.',Nx*Nr,1);
    J22 = zeros(Nr*Nx,Nx*Nr); J23 = J22; J32 = J22; J33 = J22;

    for i=1:Nx*Nr
        J22(i,:) = Spread_t(i,:).*DFt_DUtV';
        J23(i,:) = Spread_t(i,:).*DFt_DUxV';
        J32(i,:) = Spread_x(i,:).*DFx_DUtV';
        J33(i,:) = Spread_x(i,:).*DFx_DUxV';
%         for j=1:Nx*Nr
%             J22(i,j) = Spread_t(i,j)*DFt_DUtV(j);
%             J23(i,j) = Spread_t(i,j)*DFt_DUxV(j);
%             J32(i,j) = Spread_x(i,j)*DFx_DUtV(j);
%             J33(i,j) = Spread_x(i,j)*DFx_DUxV(j);
%         end
    end
% figure 
% surf(Matrices.XmGLC,Matrices.RmGLC,Fx);colorbar;drawnow
end

