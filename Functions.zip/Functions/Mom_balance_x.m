Ux_inlet = RANS.Ux(:,end); Ux_outlet = RANS.Ux(:,1); Ur_outlet = RANS.Ur(:,1); 
Ur_up = RANS.Ur(1,:); Ux_up = RANS.Ux(1,:);
p_in = RANS.p(:,end); p_out = RANS.p(:,1);

[Fx,~] = Forcing(RANS.Ux(Ind_R:end,Ind),RANS.Ut(Ind_R:end,Ind)); %Axial Forcing

% Ux_inlet = ones(Nr,1); Ux_outlet = ones(Nr,1); Ur_up = zeros(1,Nx); Ux_up = ones(1,Nx);
r = Matrices.RmGLC(:,1); R = max(r);
Qx_up = R*sqrt(Ur_up.*Ux_up)*IWx*sqrt(Ur_up.*Ux_up).';
Qx_outlet = sqrt(r.*Ux_outlet.^2).'*IWr*sqrt(r.*Ux_outlet.^2);
Qxin = sqrt(r.*Ux_inlet.^2).'*IWr*sqrt(r.*Ux_inlet.^2);
P = sqrt(r.*(p_in-p_out)).'*IWr*sqrt(r.*(p_in-p_out));
Qxout = Qx_up + Qx_outlet+P;
Fx_AD = sqrt(r.*Fx).'*IWr*sqrt(r.*Fx);