Eta = zeros(Nr,Nr);
dEta = zeros(Nr,Nr);
dEta2 = zeros(Nr,Nr);
r = linspace(rmax,0,Nr);
for i=1:Nr
    for j=0:Nr-1
        Eta(i,j+1) = r(i)^j;
    end
end
C = Eta\yGLC;
%%
for i=1:Nr
    for j=1:Nr
        dEta(i,j) = (j-1)*r(i)^(j-2);
    end
end
dEta(end,1) = 0;
der = dEta*C;
%%
for i=1:Nr
    for j=1:Nr
        dEta2(i,j) = (j-1)*(j-2)*r(i)^(j-3);
    end
end
der2 = dEta2*C;