function [C_TH,C_TG,CL,CD] = Nondim_coeff(Ux,Ut);
Global
Nt = length(TSR); %number of turbines
rGLC = Matrices.RmGLC(Ind_R:end,1); %GLC nodes on r within the Actuator Disk
C_TH = zeros(Nrd,Nt); C_TG=C_TH;CL = C_TH; CD=C_TH;
[~,alpha] = Angle_of_Attack(Ux,Ut);
for k=1:Nt
    [out] = LiftDragBT1(rGLC,alpha(:,k));
    CL(:,k) = out(:,3); CD(:,k) = out(:,4);
    
    C_TH(:,k) = CD(:,k).*sind(alpha(:,k)+tw) + CL(:,k).*cosd(alpha(:,k)+tw);
    C_TH(:,k) = (rGLC>rGLC(nac_ind(k)-Ind_R(k))).*C_TH(:,k); 
    C_TH(:,k) = (C_TH(:,k)>0).*C_TH(:,k);
    
    C_TG(:,k) = CL(:,k).*sind(alpha(:,k)+tw) - CD(:,k).*cosd(alpha(:,k)+tw);
    C_TG(:,k) = (rGLC>rGLC(nac_ind(k)-Ind_R(k))).*C_TG(:,k); 
    C_TG(:,k) = (C_TG(:,k)>0).*C_TG(:,k);
end
end