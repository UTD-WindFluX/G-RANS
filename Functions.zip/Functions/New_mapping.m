x_p = linspace(xmin, xmax, 50);
a1 = Lx(1);   a2 = Lx(2);
x1 = 0.5*(xmin+bound); x2 = 0.5*(bound+xmax);
b1 = 2*a1/(bound-xmin); b2 = 2*a2/(xmax-bound);

eta1 = @(x) (x-x1).*((1+b1^2)./(a1^2+(x-x1).^2)).^0.5;
eta2 = @(x) (x-x2).*((1+b2^2)./(a2^2+(x-x2).^2)).^0.5;

alpha1 = @(x) (1+b1^2)./(a1^2 + (x-x1).^2);   
alpha2 = @(x) (1+b2^2)./(a2^2 + (x-x2).^2);
d_eta1 = @(x) a1^2*sqrt(alpha1(x))./(a1^2 + (x-x1).^2);
d_eta2 = @(x) a2^2*sqrt(alpha2(x))./(a2^2 + (x-x2).^2);

d2_eta1 = @(x) -3*sqrt(alpha1(x)).*a1^2.*(x-x1)./(a1^2 + (x-x1).^2).^2;
d2_eta2 = @(x) -3*sqrt(alpha2(x)).*a2^2.*(x-x2)./(a2^2 + (x-x2).^2).^2;
%%
M = [xmin^3  xmin^2  xmin  1; 
    xmax^3    xmax^2  xmax  1;
    3*xmin^2 2*xmin 1 0;
    3*xmax^2 2*xmax 1 0];

T = [-1-eta1(xmin)-eta2(xmin);
    1-eta1(xmax)-eta2(xmax);
    -d_eta1(xmin)-d_eta2(xmin)+0.05;
    -d_eta1(xmax)-d_eta2(xmax)+0.05]; %added 0.05 because Matrices.x1GLC has effect on the axial integration matrix! ("normaL2 matrix.m", line 15).

%%
coeff = M\T;
C3 = coeff(1); C2=coeff(2); C1 = coeff(3); C0 = coeff(4);

eta = @(x) eta1(x) + eta2(x) +  C1*x + C0 + C3*x.^3 + C2*x.^2;
d_eta = @(x) d_eta1(x) + d_eta2(x) + C1 +3*C3*x.^2 + 2*C2*x;
d2_eta = @(x) d2_eta1(x) + d2_eta2(x) + 6*C3*x + 2*C2;
der = (eta(x_p+.001)-eta(x_p-.001))/.002;
map = eta(x_p);
X = interp1(map,x_p,xGLC,'linear');
XGC = interp1(map,x_p,xGC,'linear');