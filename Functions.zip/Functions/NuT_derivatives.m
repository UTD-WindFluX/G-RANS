%derivatives of F with respect to NuT and ML^2
function [dF_dNuT]=NuT_derivatives(qc)
    Globals
    
    Dr=Matrices.D1_r;
    D2r=Matrices.D2_r;
    Dx=Matrices.D1_X;
    D2x=Matrices.D2_X;
    rGLC=reshape(RmGLC.',Nx*Nr,1);

    invR=1./rGLC; invR(end-Nx+1:end)=invR_max; %the result doesn't depend on this value

    Delta=diag(invR)*Dr+D2r+D2x;
    Delta2=Delta-diag(invR.^2);

    Ur=qc(1:Nx*Nr);

    Ut=qc(Nx*Nr+1:2*Nx*Nr);

    Ux=qc(2*Nx*Nr+1:3*Nx*Nr);

    dFr_dNuT=-diag(Delta2*Ur)-2*diag(Dr*Ur)*Dr-diag(Dx*Ur+Dr*Ux)*Dx;
     
    dFt_dNuT=-diag(Delta2*Ut)-diag((Dr-diag(invR))*Ut)*Dr-diag(Dx*Ut)*Dx;
    
    dFx_dNuT=-diag(Delta*Ux)-diag(Dx*Ur+Dr*Ux)*Dr-2*diag(Dx*Ux)*Dx;
    
    %% BC
    
    row_TOP=1:Nx;row_OUTLET=1:Nx:Nx*Nr;row_AXIS=Nx*Nr-Nx+1:Nr*Nx;row_INLET=Nx:Nx:Nx*Nr;%boundaries position
    
    DrUr=diag(Dr*Ur);
    dFr_dNuT(row_TOP,:)=DrUr(row_TOP,:);
     
    dFr_dNuT(row_OUTLET,:)=0;dFr_dNuT(row_AXIS,:)=0;dFr_dNuT(row_INLET,:)=0;
    dFt_dNuT(row_OUTLET,:)=0;dFt_dNuT(row_AXIS,:)=0;dFt_dNuT(row_INLET,:)=0;dFt_dNuT(row_TOP,:)=0;
    dFx_dNuT(row_OUTLET,:)=0;dFx_dNuT(row_AXIS,:)=0;dFx_dNuT(row_INLET,:)=0;dFx_dNuT(row_TOP,:)=0;
    
    %%
    
    ZGC=zeros(NxGC*NrGC,Nx*Nr);
    
    dF_dNuT=[dFr_dNuT;dFt_dNuT;dFx_dNuT;ZGC];
    
end