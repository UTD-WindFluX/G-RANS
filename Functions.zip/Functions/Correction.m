function [f_x,f_t,g] = Correction(Ux,Ut);
Global
Nt = length(TSR); %number of turbines
rGLC = Matrices.RmGLC(Ind_R:end,1); %GLC nodes on r within the Actuator Disk
g = zeros(Nt,1);
[~,alpha] = Angle_of_Attack(Ux,Ut);

for k=1:Nt
    g(k)=exp(-.2431*(3*TSR_theor(k)-16.18))+.03778;
    ghub = 1;
    
    % tip and hub corrections
    fxh = nac(k); fth = nac(k); 
    fxt=.02*TSR_theor(k)+.38;
    ftt=0.49;
    f_x.tip(:,k)=real(2/pi*acos(exp(-g(k)*3*(fxt-rGLC)./(2*rGLC.*sind(alpha(:,k)+tw)))));
    f_x.hub(:,k)=real(2/pi*acos(exp(-ghub*3*(rGLC-fxh)./(2*rGLC.*sind(alpha(:,k)+tw)))));
    f_x.all(:,k)=f_x.tip(:,k).*f_x.hub(:,k);
    
    f_t.tip(:,k)=real(2/pi*acos(exp(-g(k)*3*(ftt-rGLC)./(2*rGLC.*sind(alpha(:,k)+tw)))));
    f_t.hub(:,k)=real(2/pi*acos(exp(-ghub*3*(rGLC-fth)./(2*rGLC.*sind(alpha(:,k)+tw)))));
    f_t.all(:,k)=f_t.tip(:,k).*f_t.hub(:,k);
end
end