Ind_1_1=min(find(Matrices.XmGLC(1,:)-(x_T(1)+1)<=0)); Ind_1_2=min(find(Matrices.XmGLC(1,:)-(x_T(2)+1)<=0));
Ind_3_1=min(find(Matrices.XmGLC(1,:)-(x_T(1)+3)<=0)); Ind_3_2=min(find(Matrices.XmGLC(1,:)-(x_T(2)+3)<=0));
Ind_5_1=min(find(Matrices.XmGLC(1,:)-(x_T(1)+5)<=0)); Ind_5_2=min(find(Matrices.XmGLC(1,:)-(x_T(2)+5)<=0));
r = [Matrices.RmGLC(:,1);-flip(Matrices.RmGLC(:,1))];
%%
figure('units','normalized','outerposition',[0 0 1 1]);
plot(r,[Res.Ut(:,Ind);flip(Res.Ut(:,Ind))],'o-','color',[0 .45 .74],'markersize',8,'markerfacecolor',[0 .45 .74],'linewidth',2);
hold on
plot(r,[Res.Ut(:,Ind_1);flip(Res.Ut(:,Ind_1))],'o-','color',[.85 .3 .1],'markersize',8,'markerfacecolor',[.85 .3 .1],'linewidth',2);
hold on
plot(r,[Res.Ut(:,Ind_3);flip(Res.Ut(:,Ind_3))],'o-','color',[.93 .69 .13],'markersize',8,'markerfacecolor',[.93 .69 .13],'linewidth',2);
hold on
plot(r,[Res.Ut(:,Ind_5);flip(Res.Ut(:,Ind_5))],'o-','color',[.49 .18 .56],'markersize',8,'markerfacecolor',[.49 .18 .56],'linewidth',2);
leg = legend('0D GRANS','1D GRANS','3D GRANS','5D GRANS');
set(leg,'location','southeast');
Plot_options('\it r/D','\it U_{\theta}/U_{\infty}',strcat(['TSR = ',num2str(TSR_theor)]));
axis tight
savefig(gcf,strcat([folder,'BT_vs_RANS_theta_',num2str(TSR_theor)],'.fig'));% 
saveas(gcf,strcat([folder,'BT_vs_RANS_theta_',num2str(TSR_theor)],'.png'));%   