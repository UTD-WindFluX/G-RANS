function [Fxtot,Ft] = Forcing(Ux,Ut);
Global
Nt          = length(TSR); %number of turbines
rGLC        = Matrices.RmGLC(:,1); %GLC nodes on r within the Actuator Disk
Fx          = zeros(Nr,Nt);Ft = Fx; 
F_nacelle_g = Fx; 
F_nacelle   = F_nacelle_g;
Fxtot       = Fx;
CH          = [zeros(Nr-Nrd,1); ch];

[Urel,AoA]  = Angle_of_Attack(Ux,Ut); 
Urel        = [zeros(Nr-Nrd,Nt);Urel];
AoA         = [zeros(Nr-Nrd,Nt);AoA];

[C_TH,C_TG,CL,CD] = Nondim_coeff(Ux,Ut);

C_TH        = [zeros(Nr-Nrd,Nt);C_TH]; 
CL          = [zeros(Nr-Nrd,Nt);CL]; 
CD          = [zeros(Nr-Nrd,Nt);CD];
C_TG        = [zeros(Nr-Nrd,Nt);C_TG];%nondimensional coefficients

[fx,ft]     = Correction(Ux,Ut); 
fx.all      = [zeros(Nr-Nrd,Nt);fx.all];
ft.all      = [zeros(Nr-Nrd,Nt);ft.all];%Prandtl's corrective coefficients
Ux          = [zeros(Nr-Nrd,Nt);Ux];
for k=1:Nt
    F_nacelle(end,k)=0.5*Urel(end,k).^2;
    F_nacelle_g(:,k)=CDhub*(F_nacelle(end,k)).*exp(-0.5*(rGLC./(sigma_r)).^2)*pi*nac^2;
    F_nacelle_g=(rGLC<0.40).*F_nacelle_g; %CHANGED TRASHOLD FROM 0.5 TO 0.45

    Fx(Ind_R:end-1,k) = 3./(4*pi*rGLC(Ind_R:end-1)).*Urel(Ind_R:end-1,k).^2.*CH(Ind_R:end-1).*fx.all(Ind_R:end-1,k).*C_TH(Ind_R:end-1,k);
    if CDhub>0
        Ind_fx = min(find(F_nacelle_g > Fx));
    else
        Ind_fx = Nr;
    end
    Area = (sigma_r)^2;
    F_nacelle_g(:,k) = F_nacelle_g/Area; %normalization with the integral
    Fxtot = (F_nacelle_g > Fx).*F_nacelle_g + (Fx > F_nacelle_g).*Fx;
    Ft(:,k) = 3./(4*pi*rGLC).*Urel(:,k).^2.*CH.*ft.all(:,k).*C_TG(:,k);
    Ft(end,k) = 0;
end
% figure
% plot(rGLC,F_nacelle_g,'*-');
% hold on
% plot(rGLC,Fx,'*-');
% hold on
% plot(rGLC,Fxtot,'o-');
% axis tight;grid on
% title(strcat(['Iteration ',num2str(nIte)]));drawnow
end