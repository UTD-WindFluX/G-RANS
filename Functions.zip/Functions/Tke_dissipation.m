function [tke_eps,Dtke_eps] = Tke_dissipation(tke); %dissipation of turbulent kinetic energy and its derivative with respect to itself
Global
c=0.55;
%% Residual contribution
tke_eps = (c^3)*abs(tke).^(3/2)./L_diss;
%% Jacobian contribution
Dtke_eps = 1.5*(c^3)*abs(tke).^(1/2)./L_diss; 
Dtke_eps = diag(reshape(Dtke_eps.',Nx*Nr,1));
end