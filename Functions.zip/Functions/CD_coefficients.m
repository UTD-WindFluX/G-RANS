function coeff=CD_coefficients(x,y);
M = [x(1)^2 x(1)    1;
     x(2)^2 x(2)    1;
     x(3)^2 x(3)    1];
 coeff=M\y; 
end