%addpath /Users/matteopuccioni/codice_eddyvisc_axisymmetric
%Carica i dati sull'immagine della wind turbine
load turbine
for k=1:length(x_T)
    patch('XData',turbine.hub{1,1}+x_T(k),'YData',turbine.hub{1,2},'FaceColor', [.7 .7 .7]);
    hold on
    patch('XData',turbine.hub{2,1}+x_T(k),'YData',turbine.hub{2,2},'FaceColor', [.7 .7 .7]);
    hold on
    patch('XData',turbine.down{1,1}+x_T(k),'YData',turbine.down{1,2},'FaceColor', [.7 .7 .7]);
    hold on
    patch('XData',turbine.up{1,1}+x_T(k),'YData',turbine.up{1,2},'FaceColor', [.7 .7 .7]);
end
