if TSR_theor==10
    load('./BT1_DATA/TSR10_Data.mat');
end
if TSR_theor==6
    load('./BT1_DATA/TSR6_Data.mat'); 
end
if TSR_theor==3
   load('./BT1_DATA/TSR3_Data.mat'); 
end
%%
[Xpar,Rpar] = meshgrid(x_farm,rGLC);

tke_parabolic = interp2(Xpar,Rpar,tke_farm,Matrices.XmGLC,Matrices.RmGLC);
Nut_parabolic = interp2(Xpar,Rpar,nu_t_farm,Matrices.XmGLC,Matrices.RmGLC);