in = Nx; out = 1:Nx; %axial indeces of inlet and outlet boundaries
R = Matrices.RmGLC(:,1);

Ux_inlet = RANS.Ux(:,in); 
for i=1:length(out)
X=Matrices.XmGLC(1,out(i):in);
Ux_outlet = RANS.Ux(:,out(i)); Ur_up = RANS.Ur(1,out(i):in);
r = Matrices.RmGLC(:,1); R = max(r);
m_in(i) = sqrt(Ux_inlet).'*IWr*sqrt(Ux_inlet);
m_out(i) = sqrt(Ux_outlet).'*IWr*sqrt(Ux_outlet);
m_up(i) =max(R)*sqrt(Ur_up)*IWx(out(i):in,out(i):in)*sqrt(Ur_up).';
end
%%
Balance_m = figure('units','normalized','outerposition',[0 0 0.5 1]);set(gcf,'Color','White');
plot(Matrices.XmGLC(1,:),m_in,'k*-');
hold on
plot(Matrices.XmGLC(1,:),m_out,'k+-')
hold on
plot(Matrices.XmGLC(1,:),m_up,'kv-')
hold on
plot(Matrices.XmGLC(1,:),m_up+m_out,'ko-')
Plot_options('x/D','m',[]);
leg = legend('m_{in}','m_{out}','m_{up}','Total');
set(leg,'location','south','fontsize',14);
savefig(Balance_m,strcat([folder,'/Bal_m']));
saveas(Balance_m,strcat([folder,'/Bal_m','.png']));