in      = Nx; 
out     = 1:Nx; %axial indeces of inlet and outlet boundaries
R       = Matrices.RmGLC(:,1);
m_in    = zeros(Nx-1,1);
m_out   = zeros(Nx-1,1);
m_up    = zeros(Nx-1,1);
Total   = zeros(Nx-1,1);
Ux_inlet = RANS.Ux(:,in); 
for i=1:length(out)-1
    X           = Matrices.XmGLC(1,out(i):in);
    Ux_outlet   = RANS.Ux(:,out(i)); 
    Ur_up       = RANS.Ur(1,out(i):in);
    r           = Matrices.RmGLC(:,1); 
    R           = max(r);
    m_in(i)     = -sqrt(Ux_inlet).'*IWr*sqrt(Ux_inlet);
    m_out(i)    = sqrt(Ux_outlet).'*IWr*sqrt(Ux_outlet);
    m_up(i)     = -max(R)*trapz(X,Ur_up);
    Total(i)    = m_up(i) + m_out(i) + m_in(i);
end
%%
close all
Balance_m = figure('units','centimeters','PaperPositionMode','auto','position',[0 0 20 10],'Color','White');
subplot(1,2,1)
plot(Matrices.XmGLC(1,1:end-1),m_in,'k*-');
hold on
plot(Matrices.XmGLC(1,1:end-1),m_out,'k+-')
hold on
plot(Matrices.XmGLC(1,1:end-1),m_up,'kv-')
Plot_options('$x/D$','$m$',[]);axis square;ylim([-2 2]);
leg             = legend('$m_{in}$','$m_{out}$','$m_{up}$');
leg.Interpreter = 'latex';
leg.NumColumns  = 3;
leg.Position    = [0.1294    0.8961    0.3539    0.0889];

subplot(1,2,2)
plot(Matrices.XmGLC(1,1:end-1),Total,'ko-')
Plot_options('$x/D$','$F_{mass}$',[]);axis square;ylim([-2 2]*1e-03);
% savefig(Balance_m,strcat([folder,'/MassBalance']));
% save2pdf(strcat([folder,'/MassBalance','.pdf']),Balance_m,150);