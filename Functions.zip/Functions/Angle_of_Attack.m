function [Urel,alpha] = Angle_of_Attack(Ux,Ut) %Computes the angle of attack on each airfoil section
Global
Nt = length(TSR); %number of turbines
rGLC = Matrices.RmGLC(Ind_R:end,1);
% Urel = zeros(Nr-Nrd,Nt); %initialization of relative velocity vector
Urel = zeros(Nrd,Nt); %initialization of relative velocity vector
Utrel = Urel; alpha = Urel;
omega = 2*TSR_theor;
for k=1:Nt
    Utrel(:,k) = (omega(k)*rGLC-Ut(:,k));
    Urel (:,k) = sqrt(Utrel(:,k).^2+Ux(:,k).^2);
    alpha(:,k) = atand(Ux(:,k)./Utrel(:,k)) - tw; %deg
end
end