XmGLC = Matrices. XmGLC; RmGLC = Matrices.RmGLC;
dx=xLES(2) - xLES(1); dr = rLES(2)-rLES(1);

X_start = xLES(min(find(xLES-xmin>=0))); %1st xLES node inside the RANS domain
X_end = xLES(max(find(xLES-xmax<=0))); %last xLES node inside the RANS domain
R_start = rLES(min(find(rLES-rmin>=0))); %1st rLES node inside the RANS domain
R_end = rLES(max(find(rLES-rmax<0))); %last rLES node inside the RANS domain

NxL = find(xLES==X_end) - find(xLES==X_start) +1; %number of xLES nodes inside the RANS domain
NrL = find(rLES==R_end) - find(rLES==R_start) +1; %number of rLES nodes inside the RANS domain

MtoLES_comp = zeros(NxL*NrL,Nx*Nr); %initialization of interpolation matrix
%%
for i = 1:NrL
    for j=1:NxL
        xloc = X_end - (j-1)*dx; %moving toward
        rloc = R_end - (i-1)*dr; %from upp. bound to axis
        
        %X locations of the rectangle's vertices around the LES node
%         if j==NxL
%             xB = Matrices.XmGLC(1,end)+xmin; xA=xB;
%             xD = Matrices.XmGLC(1,end-1)+xmin; xC = xD;
%             xx=(xloc-xA)/(deltax); %non-dimensional x in the cell
%         else
            jD = max(find(XmGLC(1,:)+xmin - xloc>0)); xD = XmGLC(1,jD)+xmin;
            jA = jD+1; xA = XmGLC(1,jA)+xmin;
            jC = jD; xC = xD;
            jB = jA; xB = xA;
            deltax = xD - xA;
            xx=(xloc-xA)/(deltax); %non-dimensional x in the cell
%         end
        
        %R locations of the rectangle's vertices around the LES node
%         if i==NrL
%             yy = 0;
%         else
            iC = max(find(RmGLC(:,1) - rloc>0)); rC = RmGLC(iC,1);
            iB = iC; rB = rC;
            iD = iC+1; rD = RmGLC(iD,1);
            iA = iD; rA = rD;
            deltar = rC - rD;
            yy=(rloc-rA)/(deltar);%non-dimensional y in the cell
%         end
        
            index_A=jA+(iA-1)*Nx;%index of the A point in the GLC vector
            index_B=jB+(iB-1)*Nx;%index of the B point in the GLC vector
            index_C=jC+(iC-1)*Nx;%index of the C point in the GLC vector
            index_D=jD+(iD-1)*Nx;%index of the D point in the GLC vector

            %writes the row-th row of the matrix MtoLES
            row = j + (i-1)*NxL;
            MtoLES_comp(row,index_A)=(1-xx)*(1-yy);
            MtoLES_comp(row,index_B)=(1-xx)*yy;
            MtoLES_comp(row,index_C)=xx*yy;
            MtoLES_comp(row,index_D)=xx*(1-yy);
        
    end
end
% MtoLES_comp = flipud(MtoLES_comp);
MtoLES=[MtoLES_comp 0*MtoLES_comp 0*MtoLES_comp; 0*MtoLES_comp MtoLES_comp 0*MtoLES_comp; 0*MtoLES_comp 0*MtoLES_comp MtoLES_comp];
Matrices.MtoExp = MtoLES;
Matrices.NxL = NxL;
Matrices.NrL = NrL;