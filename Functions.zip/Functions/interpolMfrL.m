function [MfrL]=interpolMfrL(N,xGLC,xGC)


T = -toeplitz((-1).^(0:N)); 
T=T(1:N,:);

 A=repmat(sqrt(1-xGC.^2) , [1,N+1] );
 B=repmat( xGC , [1,N+1] );
 C=repmat( xGLC' , [N,1] );
 
 MfrL=T.*A./(B-C)/N;
 
 MfrL(:,1)=MfrL(:,1)/2;
 MfrL(:,N+1)=MfrL(:,N+1)/2;
 
%  MfrL=[MfrL;zeros(1,N+1)];