in = Nx; out = 1:Nx; %axial indeces of inlet and outlet boundaries
R = Matrices.RmGLC(:,1);
[~,~,~,~,F] = Jacobian_Forcing(RANS.qc); %Axial Forcing
S_S=Reynolds_stress(RANS.qc);
Fx = reshape(F(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
%%
for i=1:length(out)
    X=Matrices.XmGLC(1,out(i):in);
    Ux_inlet = RANS.Ux(:,in); Ux_outlet = RANS.Ux(:,out(i));
    Ux_up = RANS.Ux(1,out(i):in); Ur_up = RANS.Ur(1,out(i):in);
    p_in = RANS.p(:,in); p_out = RANS.p(:,out(i));
    
%     Nu_in=1/Reynolds+NuT(:,in); Nu_up=1/Reynolds+NuT(1,out(i):in); Nu_out=1/Reynolds+NuT(:,out(i));
%     S_in=S_S{3,3}(:,in); S_up=S_S{3,1}(1,out(i):in); S_out=S_S{3,3}(:,out(i));
%     tau_in=sqrt(Nu_in.*S_in).'*IWr*sqrt(Nu_in.*S_in); 
%     tau_up=max(R)*sqrt(Nu_up.*S_up)*IWx(out(i):in,out(i):in)*sqrt(Nu_up.*S_up).'; 
%     tau_out=sqrt(Nu_out.*S_out).'*IWr*sqrt(Nu_out.*S_out);
%     tau(i) = tau_up+tau_in+tau_out;
    IW2=kron(IWr,IWx(out(i):in,out(i):in));
    Force = Fx(:,out(i):in);
%     R2=Matrices.RmGLC(:,out(i):in);
    arg = reshape((Force).',Nr*(Nx-i+1),1);
    Fx_AD_loc(i) = sqrt(arg).'*IW2*sqrt(arg);
    Qx_outlet_loc(i) = sqrt(Ux_outlet.^2).'*IWr*sqrt(Ux_outlet.^2);
    Qx_up_loc(i) = max(R)*sqrt(Ur_up.*Ux_up)*IWx(out(i):in,out(i):in)*sqrt(Ur_up.*Ux_up).';
%     Qx_up_loc(i) = -max(R)*trapz(X,Ur_up.*Ux_up,2);
    Qxout_loc(i) = Qx_up_loc(i) + Qx_outlet_loc(i);

    Qxin_loc(i) = sqrt(Ux_inlet.^2).'*IWr*sqrt(Ux_inlet.^2);
    P(i) = diag(IWr)'*(p_out-p_in);
    Bal(i) = Qxout_loc(i)+P(i)+Fx_AD_loc(i);%-tau(i);
end
%%
Balance = figure('units','normalized','outerposition',[0 0 0.5 1]);set(gcf,'Color','White');
plot(Matrices.XmGLC(1,:),Qxin_loc,'k*-');
hold on
plot(Matrices.XmGLC(1,:),Qxout_loc,'k+-')
hold on
plot(Matrices.XmGLC(1,:),P,'kv-')
hold on
plot(Matrices.XmGLC(1,:),Fx_AD_loc,'ko-')
% hold on
% plot(Matrices.XmGLC(1,:),tau,'k<-')
hold on
plot(Matrices.XmGLC(1,:),Bal,'k^-')
set(gco,'markersize',20);
leg = legend('Q_{in}','Q_{out}','Pressure','Forcing','Total');
set(leg,'location','best','fontsize',14);
Plot_options('x/D','Q',[]);
%
savefig(Balance,strcat([folder,'Bal_x']));
saveas(Balance,strcat([folder,'Bal_x','.png']));