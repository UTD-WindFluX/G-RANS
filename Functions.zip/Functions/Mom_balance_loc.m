in      = Nx; 
out     = 1:Nx; %axial indeces of inlet and outlet boundaries
R       = Matrices.RmGLC(:,1);
[~,~,~,~,F] = Jacobian_Forcing(RANS.qc); %Axial Forcing
S_S         = Reynolds_stress(RANS.qc);
Fx          = reshape(F(2*Nx*Nr+1:3*Nx*Nr),Nx,Nr).';
%% Evaluation of momentum balance terms at each x-location
for i=1:length(out)
    X           = Matrices.XmGLC(1,out(i):in);
    Ux_inlet    = RANS.Ux(:,in); 
    Ux_outlet   = RANS.Ux(:,out(i));
    Ux_up       = RANS.Ux(1,out(i):in); 
    Ur_up       = RANS.Ur(1,out(i):in);
    p_in        = RANS.p(:,in); 
    p_out       = RANS.p(:,out(i));
    
    %Evaluate integration matrices
    x1GLC       = Matrices.x1GLC;
    rGLC        = Matrices.RmGLC(:,1);
    y1GLC       = Matrices.y1GLC;

    IWxLxW      = diag(INTweights(Nx,max(X)-xmin)); 
    IWxMLxW     = diag(IWxLxW./x1GLC); 

    IWy         = diag(INTweights(Nr,rmax-rmin));
    IWyM        = diag(IWy.*rGLC./y1GLC);

    IWMLxW      = kron(IWyM,IWxMLxW);

%     IW2         = kron(IWr,IWx(out(i):in,out(i):in));
    
    %Evaluate integral contributions
    Force               = Fx(:,out(i):in);
    arg                 = reshape((Force).',Nr*(Nx-i+1),1);
    Fx_AD_loc(i)        = sqrt(arg).'*IWMLxW*sqrt(arg);
    Qx_outlet_loc(i)    = sqrt(Ux_outlet.^2).'*IWr*sqrt(Ux_outlet.^2);
    Qx_up_loc(i)        = max(R)*sqrt(Ur_up.*Ux_up)*IWx(out(i):in,out(i):in)*sqrt(Ur_up.*Ux_up).';
    Qxout_loc(i)        = Qx_up_loc(i) + Qx_outlet_loc(i);

    Qxin_loc(i)         = sqrt(Ux_inlet.^2).'*IWr*sqrt(Ux_inlet.^2);

    P(i)                = diag(IWr)'*(p_out-p_in);
    Bal(i)              = Qxout_loc(i)+P(i)+Fx_AD_loc(i)-Qxin_loc(i);%-tau(i);
end
%% Figure on streamwise momentum balance
close all
Balance             = figure('units','centimeters','PaperPositionMode','auto','position',[0 0 30 10],'Color','White');

subplot(1,3,1)
plot(Matrices.XmGLC(1,:),Qxin_loc,'k*-');
hold on
plot(Matrices.XmGLC(1,:),Qxout_loc,'k+-')
Plot_options('$x/D$','$Q$',[]);ylim([1.8 2.1]);axis square
leg                 = legend('$Q_{in}$','$Q_{out}$');
leg.Interpreter     = 'latex';
leg.Position        = [0.25    0.24    0.08    0.14];

subplot(1,3,2)
plot(Matrices.XmGLC(1,:),P,'kv-')
hold on
plot(Matrices.XmGLC(1,:),Fx_AD_loc,'ko-')
set(gco,'markersize',20);
Plot_options('$x/D$','$F_{TH},~p$',[]);ylim([-0.05 0.05]);axis square
leg                 = legend('Pressure','Forcing');
leg.Position        = [0.52    0.23    0.1    0.14];

subplot(1,3,3)
plot(Matrices.XmGLC(1,:),Qxout_loc-Qxin_loc+Fx_AD_loc+P,'k^-')
Plot_options('$x/D$','$Res_x$',[]);ylim([0 0.01]);axis square
% savefig(Balance,strcat([folder,'/MomentumBalance']));
% save2pdf(strcat([folder,'/MomentumBalance','.pdf']),Balance,150);