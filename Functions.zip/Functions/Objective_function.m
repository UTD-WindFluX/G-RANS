function [output,g]=Objective_function(x)
    Global
    display(['Modal coefficients: ', num2str(x')]);
    
    %RANS solution
    switch Turbulence_model
        case 'ML'
            NuT0=0;
            ML_coeff=x;
            [RANS]=AxiSymDirect_ML(NuT0,ML_coeff);%RANS solver
            Optimization.ML=[Optimization.ML;ML_coeff'];
            Optimization.NuT0=[Optimization.NuT0;NuT0];
            
        case 'EV'
            NuT_coeff=x;
            RANS=AxiSymDirect_EV(NuT_coeff);
            Optimization.NuT=[Optimization.NuT;NuT_coeff'];
    end
    
    qc_initial=RANS.qc;%set the initial geuss for the next iteration
    JA=RANS.Jacobian;%System jacobian matrix
    q_RANS_GLC=RANS.qc(1:Nx*Nr*3);%RANS solution [Ur;Ut;Ux;p]
    q_RANS_exp=Matrices.MtoExp*q_RANS_GLC;% RANS solution intepolated on the experimental grid

    deltaqExp=(q_RANS_exp-qExp);% difference velocity field to be minimized
            
    output=0.5*sum(deltaqExp.*deltaqExp); %objective function
    display(['Objective_function = ',num2str(output)]);
    
    %% gradient computation
    V=Matrices.MtoExp'*deltaqExp;
    
    V=[V;zeros(NxGC*NrGC,1)];
    lambda=-JA'\ V;   %adjoint problem solution
       
    dF_dNuT=NuT_derivatives(RANS.qc);%calculate the matrix dF/dNuT
    Xc=reshape(XmGLC'+xmin,Nx*Nr,1);
    switch Turbulence_model
        
        case 'ML'
            
            dNuT_dNuT0=Matrices.M_smooth*ones(Nx*Nr,1);
            dF_dNuT0=dF_dNuT*dNuT_dNuT0;
            g(1,1)=sum(lambda.*dF_dNuT0);
            
            [~,~,~,~,S]=EV_closure_All(0,zeros(Nr,Nx),RANS.qc,NuT_smooth_par);
            MLc=reshape(RANS.ML',Nx*Nr,1);
            dNuT_dML=Matrices.M_smooth*diag(S.^0.5)*diag(MLc)*2;
            
            switch DoFs
                case 1
                    dML_dA=ones(Nx*Nr,1);
                    dF_dA=dF_dNuT*dNuT_dML*dML_dA;
                    g(1,2)=sum(lambda.*dF_dA);
                    
                case 2
                    dML_dA=ones(Nx*Nr,1);
                    dF_dA=dF_dNuT*dNuT_dML*dML_dA;
                    g(1,2)=sum(lambda.*dF_dA);
                    
                    dML_dB=Xc;
                    dF_dB=dF_dNuT*dNuT_dML*dML_dB;
                    g(1,3)=sum(lambda.*dF_dB);
                    
                case 3
                    ML_inf=ML_coeff(1);                    
                    k=ML_coeff(2);
                    X_trans=ML_coeff(3);
                    
                    E=exp(-k*(Xc-X_trans));
                    
                    dML_dML_inf=1./(1+E);
                    dF_dML_inf=dF_dNuT*dNuT_dML*dML_dML_inf;
                    g(1,2)=sum(lambda.*dF_dML_inf);
                    
                    dML_dk=ML_inf*(1+E).^(-2).*(Xc-X_trans).*E;
                    dF_dk=dF_dNuT*dNuT_dML*dML_dk;
                    g(1,3)=sum(lambda.*dF_dk);
                    
                    dML_dX_trans=-ML_inf*(1+E).^(-2)*k.*E;
                    dF_dX_trans=dF_dNuT*dNuT_dML*dML_dX_trans;
                    g(1,4)=sum(lambda.*dF_dX_trans);
          
                case 4
                    ML_0=ML_coeff(1);
                    ML_inf=ML_coeff(2);                    
                    k=ML_coeff(3);
                    X_trans=ML_coeff(4);
                    
                    E=exp(-k*(Xc-X_trans));
                    
                    dML_dML_0=ones(Nx*Nr,1);
                    dF_dML_0=dF_dNuT*dNuT_dML*dML_dML_0;
                    g(1,1)=sum(lambda.*dF_dML_0);
                    
                    dML_dML_inf=1./(1+E);
                    dF_dML_inf=dF_dNuT*dNuT_dML*dML_dML_inf;
                    g(1,2)=sum(lambda.*dF_dML_inf);
                    
                    dML_dk=ML_inf*(1+E).^(-2).*(Xc-X_trans).*E;
                    dF_dk=dF_dNuT*dNuT_dML*dML_dk;
                    g(1,3)=sum(lambda.*dF_dk);
                    
                    dML_dX_trans=-ML_inf*(1+E).^(-2)*k.*E;
                    dF_dX_trans=dF_dNuT*dNuT_dML*dML_dX_trans;
                    g(1,4)=sum(lambda.*dF_dX_trans);
            end
            
        case 'EV'
            switch DoFs
                case 1
                    dNuT_dA=ones(Nx*Nr,1);
                    dF_dA=dF_dNuT*dNuT_dA;
                    g(1,1)=sum(lambda.*dF_dA);
                    
                case 2
                    dNuT_dA=ones(Nx*Nr,1);
                    dF_dA=dF_dNuT*dNuT_dA;
                    g(1,1)=sum(lambda.*dF_dA);
                    
                    dNuT_dB=Xc;
                    dF_dB=dF_dNuT*dNuT_dB;
                    g(1,2)=sum(lambda.*dF_dB);
            end
%                Check_NuT_derivatives
            
    end
   
    disp(['Gradient = ', num2str(g)]);
    
    %% save evolution

    Optimization.Grad=[Optimization.Grad;g];
    Optimization.Obj_Fun=[Optimization.Obj_Fun;output];
%     figure;plot(LiDar.Vec_GLC);hold on;plot(Matrices.MtoExp*RANS.qc(1:3*Nx*Nr));legend('Experimental','RANS');title('Unknowns vector compared to objective');
end
