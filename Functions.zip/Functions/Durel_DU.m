function [DU_DUx,DU_DUt] = Durel_DU(Ux,Ut);
Global
Nt = length(TSR); %number of turbines
rGLC = Matrices.RmGLC(Ind_R:end,1); %GLC nodes on r within the Actuator Disk
Urel = zeros(Nrd,Nt); %initialization of relative velocity vector
Utrel = Urel;
DU_DUx = zeros(Nrd,Nt); DU_DUt = zeros(Nrd,Nt);
omega = 2*TSR;
for k=1:Nt
    Utrel(:,k) = (omega(k)*rGLC-Ut(:,k));
    Urel (:,k) = sqrt(Utrel(:,k).^2+Ux(:,k).^2);
    
    DU_DUx(:,k) = Ux(:,k)./Urel(:,k);
    DU_DUt(:,k) = -Utrel(:,k)./Urel(:,k);
end
end