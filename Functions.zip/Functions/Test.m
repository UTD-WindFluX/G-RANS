clear all
close all
addpath ./Functions
Global
TSR = 6;
Pre_processing %Here the input parameters are settled
CL_CD
Turbulence_model = 'ML';ML_coeff = [0 0.03 0.314 x_T]; %ML modal coefficients
out_BC = 'non-homogeneous_Neumann';
% load ('RANS','RANS_opt');
Ux_ex = rand(Nr); %example of velocity profile on r
Ut_ex = rand(Nr);
% clear RANS_opt
Ux = repmat(Ux_ex(Ind_R:end),1,length(TSR));
Ut = repmat(Ut_ex(Ind_R:end),1,length(TSR));
delta=1e-06;
%%
% [Urel,alpha] = Angle_of_Attack(Ux,Ut);
% [Urel2,~] = Angle_of_Attack(Ux,Ut+.001);[Urel1,~] = Angle_of_Attack(Ux,Ut-.001);
% [DUrel_DUx,DUrel_DUt] = Durel_DU(Ux,Ut);
% DU_appr = (Urel2-Urel1)./.002;
% figure
% plot(R_AD,DUrel_DUt,'*-');
% hold on
% plot(R_AD,DU_appr,'o-');

%%
Dalpha = Dalpha_DU(Ux,Ut);
[~,alpha2] = Angle_of_Attack(Ux+delta,Ut);
[~,alpha1] = Angle_of_Attack(Ux-delta,Ut);
D_appr = (alpha2-alpha1)*pi/180/(2*delta);
%% DF
% [f_x2,f_t2,~]=Correction(Ux,Ut+delta);[f_x1,f_t1,~]=Correction(Ux,Ut-delta);
% [C_TH,C_TG,CL,CD] = Nondim_coeff(Ux,Ut);
% for k=1:length(TSR)
%     C_TH(:,k) = (R_AD>Matrices.RmGLC(nac_ind,1)).*C_TH(:,k);
%     C_TG(:,k) = (R_AD>Matrices.RmGLC(nac_ind,1)).*C_TG(:,k); %set 0 coefficients on nacelle position
% end
% [Dfx,Dft] = Df_Dalpha(Ux,Ut);
% Df = Dft.*Dalpha.Ut;
% Df_appr = (f_t2.all-f_t1.all)/(2*delta);
% 
figure
plot(R_AD,Dalpha.Ux,'*-'); hold on
plot(R_AD,D_appr,'o-');legend('Ch.','FD');
%%
[DCL_dalpha,DCD_dalpha] = dCL_dCD_Dalpha(alpha);
DCL_DUx = DCL_dalpha.*Dalpha.Ux;
out2 = LiftDragBT1(R_AD,alpha2,Nfoil);
out1 = LiftDragBT1(R_AD,alpha1,Nfoil);
DCL_DUx_appr = (out2(:,3)-out1(:,3))/(2*delta);
[DCth,DCtg] = DC_DU(Ux,Ut);
figure
plot(R_AD,DCL_DUx,'*-');
hold on
plot(R_AD,DCL_DUx_appr,'o-');
%%
[C_TH2,C_TG2,~,~] = Nondim_coeff(Ux,Ut+delta);
[C_TH1,C_TG1,~,~] = Nondim_coeff(Ux,Ut-delta);
DC_appr = (C_TG2-C_TG1)/(2*delta);

figure
plot(R_AD,DCth.Ut,'*-');
hold on
plot(R_AD,DC_appr,'o-');
%%
[Fx2_t,Ft2_t] = Forcing(Ux,Ut+delta); [Fx1_t,Ft1_t] = Forcing(Ux,Ut-delta);
[Fx2_x,Ft2_x] = Forcing(Ux+delta,Ut); [Fx1_x,Ft1_x] = Forcing(Ux-delta,Ut);
DF_app = (Fx2_t-Fx1_t)/(2*delta);
DFx_Dx_app = (Fx2_x-Fx1_x)/(2*delta);
DFx_Dt_app = (Fx2_t-Fx1_t)/(2*delta);

DFt_Dx_app = (Ft2_x-Ft1_x)/(2*delta);
DFt_Dt_app = (Ft2_t-Ft1_t)/(2*delta);
%%
[DFx,DFt] = DF_DU(Ux,Ut);
%%
figure
plot(Matrices.RmGLC(:,1),DFt.Ux,'*-');
hold on
plot(Matrices.RmGLC(:,1),DFt_Dx_app,'o-');
%% 
% figure('units','normalized','outerposition',[0 0 1 1]);set(gcf,'Color','White');
% plot(R_AD,f_t,'*-');
% Plot_options('r/D','C','Thrust coefficient');axis tight