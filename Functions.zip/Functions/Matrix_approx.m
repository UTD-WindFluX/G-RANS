a = Lx;
x0 = 0.5*(xmin+xmax);
b = 2*a/(xmax-xmin);
x_GLC = x0 + a*xGLC./(1 + b^2 - xGLC.^2).^0.5;
% x_GLC = X;
x_GC = x0 + a*xGC./(1 + b^2 - xGC.^2).^0.5;
% x_GC = interp1(xGLC,X,xGC);

dx = x_GLC(2:end)-x_GLC(1:end-1);
%% Polynomial fitting GLC
alpha = dx(2)/dx(1);
Dy(1,1) = -(alpha+2)/(dx(1)*(alpha+1));
Dy(1,2) = (alpha+1)/(alpha*dx(1));
Dy(1,3) = -1/(dx(1)*alpha*(alpha+1));

alpha = dx(end-1)/dx(end);
Dy(Nx,Nx) = (alpha+2)/(dx(end)*(alpha+1));
Dy(Nx,Nx-1) = -(alpha+1)/(alpha*dx(end));
Dy(Nx,Nx-2) = 1/(alpha*dx(end)*(alpha+1));
Dy2 = zeros(Nx,Nx);
for i=2:Nx-1
    alpha=dx(i)/dx(i-1);
    Dy(i,i-1)=-alpha^2/dx(i-1)/(alpha^2+alpha);
    Dy(i,i+1)=1/dx(i-1)/(alpha^2+alpha);
    Dy(i,i)=(alpha^2-1)/dx(i-1)/(alpha^2+alpha);
    Dy2(i,i-1)=2*alpha/(dx(i-1)^2)/(alpha^2+alpha);
    Dy2(i,i+1)=2/(dx(i-1)^2)/(alpha^2+alpha);
    Dy2(i,i)=(-2*alpha-2)/(dx(i-1)^2)/(alpha^2+alpha);
end
i = 1; %upward scheme 
alpha=dx(2)/dx(1);
Dy2(i,i) = 2/(dx(i)^2*(alpha+1));
Dy2(i,i+1) = -2/(alpha*dx(i)^2);
Dy2(i,i+2) = 2/(dx(i)^2*(alpha+1)*alpha);
%
i = Nx; %backward scheme
alpha = dx(end-1)/dx(end);
Dy2(i,i) = 2/(dx(end)^2*(alpha+1));
Dy2(i,i-1) = -2/(alpha*dx(end)^2);
Dy2(i,i-2) = 2/(dx(end)^2*(alpha+1)*alpha);
eta1 = Dy*xGLC;
eta2 = Dy2*xGLC;

x1GLC = Dy*xGLC;
x2GLC = Dy2*xGLC;
%% Polynomial fitting GC
DyGC = zeros(Nx-2,Nx-2);
dxGC = x_GC(2:end)-x_GC(1:end-1);
alpha = dxGC(2)/dxGC(1);

DyGC(1,1) = -(alpha+2)/(dxGC(1)*(alpha+1));
DyGC(1,2) = (alpha+1)/(alpha*dxGC(1));
DyGC(1,3) = -1/(dxGC(1)*alpha*(alpha+1));

alpha = dxGC(end-1)/dxGC(end);
DyGC(NxGC,NxGC-2) = 1/(alpha*dxGC(end)*(alpha+1));
DyGC(NxGC,NxGC-1) = -(alpha+1)/(alpha*dxGC(end));
DyGC(NxGC,NxGC) = (alpha+2)/(dxGC(end)*(alpha+1));

for i=2:NxGC-1
    alpha=dxGC(i)/dxGC(i-1);
    DyGC(i,i-1)=-alpha^2/dxGC(i-1)/(alpha^2+alpha);
    DyGC(i,i+1)=1/dxGC(i-1)/(alpha^2+alpha);
    DyGC(i,i)=(alpha^2-1)/dxGC(i-1)/(alpha^2+alpha);
end
x1GC = DyGC*xGC;