function [S,S_tot] = Spread(F,sigma);
Global
Nt = length(TSR); %number of turbines
RmGLC = Matrices.RmGLC(:,1);
XmGLC = Matrices.XmGLC(1,:);
F = [zeros(Nr-Nrd,1);F];
S=cell(Nt,1);
S_tot = zeros(Nr,Nx);
for k=1:Nt
    Gauss = @(x) exp(-0.5*((x-x_T(k))./(sigma(k))).^2);
    G = normpdf(XmGLC,x_T(k),sigma);
%     G = Gauss(XmGLC); 
%     ind_up = min(find(XmGLC-(x_T-1)<=0)); ind_down = min(find(XmGLC-(x_T+1)<=0)); %truncation GLC points
%     G(1:ind_down) = 0; G(ind_up:end) = 0; %truncation out of +- 1D
    S{k} = kron(F(:,k),G);
    S_tot = S_tot+S{k};
end
end