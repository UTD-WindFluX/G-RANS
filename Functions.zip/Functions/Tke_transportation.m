function [T,DT_Dtke] = Tke_transportation(tke,lm); %viscous transportation of tke and its derivatives
Global

D1_X=Matrices.D1_X;
D2_X=Matrices.D2_X;
D1_r=Matrices.D1_r;
D2_r=Matrices.D1_r;
RmGLC=reshape(Matrices.RmGLC.',Nx*Nr,1);
rGLCc=reshape(RmGLC',Nx*Nr,1);
invrGLCc=1./rGLCc; invrGLCc(end-Nx+1:end)=invR_max; %the result doesn't depend on this value
invrGLC=diag(invrGLCc);
Delta=invrGLC*D1_r+D2_r+D2_X;
Mat_smooth = Matrices.Mat_smooth_Gauss;

c = 0.55;
nut = Mat_smooth*c*abs(tke).^0.5.*lm;
DnutDr = diag(Mat_smooth*D1_r*nut);
DnutDx = Mat_smooth*D1_X*nut;
DnutDtke = Mat_smooth*0.5*c*abs(tke).^(-0.5).*lm;

%% Residual contribution
T =  nut.*(Delta*tke) + DnutDr*D1_r*abs(tke) + DnutDx.*(D1_X*abs(tke));  %

%% Jacobian contribution
DT_Dtke = DnutDr*D1_r + diag(D1_r*abs(tke))*D1_r.*repmat(DnutDtke',Nx*Nr,1) + diag(D1_X*abs(tke))*D1_X.*repmat(DnutDtke',Nx*Nr,1) + diag(DnutDx)*D1_X...
            + diag(nut)*Delta + diag(DnutDtke)*diag(Delta*abs(tke));
end