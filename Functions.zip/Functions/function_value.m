function V = function_value(xp,rp,C);
Global
x = Matrices.xGLC; r = Matrices.yGLC;

xmap = 2/(xmax-xmin)*(xp-xmin)-1; %linear mapping
rmap = 2/rmax*rp -1;
Nx = length(x); Nr = length(r);
Coeff = fcgltran2d(C,1); %Discrete Chebyshev transform 2d

%Initialization of Chebyshev values
Tx = zeros(Nx,1); Tr = zeros(1,Nr);

for i=1:Nx
    Tx(i) = chebyshevT(i-1,xmap);%Chebyshev x-polynomials over the selected point
end

for j=1:Nr
   Tr(j) = chebyshevT(j-1,rmap); %Chebyshev r-polynomials over the selected point
end
V = Tr*Coeff*Tx; %Discrete function-evaluation
end