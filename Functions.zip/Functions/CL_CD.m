addpath ./clcdalpha/
Filenames = 'clcdalpha.txt';
da = 1e-04;
input = importdata(Filenames);
alpha = input.data(:,1); CL = input.data(:,2); CD = input.data(:,3);
CL2 = interp1(alpha,CL,alpha+da,'spline','extrap'); 
CL1 = interp1(alpha,CL,alpha-da,'spline','extrap');
CD2 = interp1(alpha,CD,alpha+da,'spline','extrap'); 
CD1 = interp1(alpha,CD,alpha-da,'spline','extrap'); 
CL_alpha = (CL2 - CL1)/(2*da)*180/pi;
CD_alpha = (CD2 - CD1)/(2*da)*180/pi;
CL_ref = CL; CD_ref = CD;
angle_int = alpha;
clear CL2 CL1 CD2 CD1;
