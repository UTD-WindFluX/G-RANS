addpath ./clcdalpha/
% Filenames={'clcdalpha_cyl1.inp', 'clcdalpha_cyl2.inp', 'clcdalpha_du40_A17.inp',...
%     'clcdalpha_du35_A17.inp', 'clcdalpha_du30_A17.inp','clcdalpha_du25_A17.inp',...
% 	       'clcdalpha_du21_A17.inp','clcdalpha_naca64_A17.inp' };
Filenames = 'clcdalpha.txt';
da = .0001;
    input = importdata(Filenames);
    alpha = input.data(:,1); CL = input.data(:,2); CD = input.data(:,3);
    CL2 = interp1(alpha,CL,alpha+da,'linear','extrap'); 
    CL1 = interp1(alpha,CL,alpha-da,'linear','extrap');
    CD2 = interp1(alpha,CD,alpha+da,'linear','extrap'); 
    CD1 = interp1(alpha,CD,alpha-da,'linear','extrap'); 
    CL_alpha = (CL2 - CL1)/(2*da)*180/pi;
    CL_ref = CL; CD_ref = CD;
    CD_alpha = (CD2 - CD1)/(2*da)*180/pi;
    angle_int = alpha;
clear CL2 CL1 CD2 CD1;
% figure('units','normalized','outerposition',[0 0 1 1]);set(gcf,'Color','White');
% subplot(2,1,1)
% plot(angle_int,CL_ref,'*-'); axis tight
% Plot_options('\alpha','C_{L}',[]);
% subplot(2,1,2)
% plot(angle_int,CD_ref,'*-')
% Plot_options('\alpha','C_{D}',[]); axis tight
%%
% coeff = CD_coefficients([alpha(5) alpha(10) alpha(15)],[CD_ref(5) CD_ref(10) CD_ref(15)]');
% beta1 = coeff(1); beta2=coeff(2); beta3=coeff(3);
% CD = coeff(1)*alpha.^2+coeff(2)*alpha+coeff(3);
% figure('units','normalized','outerposition',[0 0 1 1]);set(gcf,'Color','White');
% plot(alpha,CD_ref,'*-');axis tight
% Plot_options('\alpha','C_D','\alpha-C_D');
% l=legend ('C_D reference');
% set(l,'fontsize',16,'fontname','arial','fontweight','normal','location','best');