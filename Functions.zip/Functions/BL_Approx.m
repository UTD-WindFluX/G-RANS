RmGLC = Matrices.RmGLC;
BL_approx = 1;
Urc = RANS.qc(1:Nx*Nr);%radial velocity
Utc = RANS.qc(Nx*Nr+1:2*Nx*Nr);%azimuthal velocity
Uxc = RANS.qc(2*Nx*Nr+1:3*Nx*Nr); %axial velocity component
row_AXIS=Nr*Nx-Nx+1:Nr*Nx;
D1_r=Matrices.D1_r;
D1_X=Matrices.D1_X;

rGLC=reshape(RmGLC.',Nx*Nr,1); 
invrGLC=1./rGLC; %inverse of the radial positions
invrGLC(end-Nx+1:end)=0; %the result doesn't depend on this value

Dr_invR=D1_r-diag(invrGLC);

%components of stress tensor
S_rr=D1_r*Urc*(1-BL_approx);

S_tt=diag(invrGLC)*Urc*(1-BL_approx);

S_xx=D1_X*Uxc*(1-BL_approx);

S_rt=Dr_invR*Utc;S_rt(row_AXIS)=0;

S_rx=(D1_X*Urc*(1-BL_approx)+D1_r*Uxc);S_rx(row_AXIS) =0;

S_tx=(D1_X*Utc)*(1-BL_approx);S_tx(row_AXIS) = 0;

S=sqrt(2*S_rr.^2+2*S_tt.^2+2*S_xx.^2+S_rt.^2+S_rx.^2+S_tx.^2);%2(S:S)