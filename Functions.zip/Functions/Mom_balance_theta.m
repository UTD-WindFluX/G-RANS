in = Nx; out = 1:Nx; %axial indeces of inlet and outlet boundaries
R = Matrices.RmGLC(:,1);
[~,Ft] = Forcing(RANS.Ux(Ind_R:end,Ind),RANS.Ut(Ind_R:end,Ind)); %Axial Forcing
G = normpdf(Matrices.XmGLC(1,:),x_T,sigma_t);
F=kron(Ft,G);
Ft = reshape(F,Nx,Nr).';
%%
for i=1:length(out)
    Ux_inlet = RANS.Ux(:,in); Ux_outlet = RANS.Ux(:,out(i));
%     Nu_in=1/Reynolds+NuT(:,in); Nu_up=1/Reynolds+NuT(1,out(i):in); Nu_out=1/Reynolds+NuT(:,out(i));
%     S_in=S_S{2,3}(:,in); S_up=S_S{2,1}(1,out(i):in); S_out=S_S{2,3}(:,out(i));
%     tau_in=sqrt(R.*Nu_in.*S_in).'*IWr*sqrt(R.*Nu_in.*S_in); 
%     tau_up=max(R)*sqrt(Nu_up.*S_up)*IWx(out(i):in,out(i):in)*sqrt(Nu_up.*S_up).'; 
%     tau_out=sqrt(R.*Nu_out.*S_out).'*IWr*sqrt(R.*Nu_out.*S_out);
%     tau(i) = tau_up+tau_in+tau_out;
    
    Ut_up = RANS.Ut(1,out(i):in);Ut_inlet=RANS.Ut(:,in); Ut_outlet = RANS.Ut(:,out(i));
    Ur_up = RANS.Ur(1,out(i):in);
    IW2=kron(IWr,IWx(out(i):in,out(i):in));
    Force = Ft(:,out(i):in);
    R2=Matrices.RmGLC(:,out(i):in);
    arg = reshape((R2.*Force).',Nr*(Nx-i+1),1);
    Ft_AD_loc(i) = sqrt(arg).'*IW2*sqrt(arg);
    Qt_outlet_loc(i) = sqrt(R.*Ux_outlet.*Ut_outlet).'*IWr*sqrt(R.*Ux_outlet.*Ut_outlet);
    Qt_up_loc(i) = max(R)*sqrt(Ur_up.*Ut_up)*IWx(out(i):in,out(i):in)*sqrt(Ur_up.*Ut_up).';
    Qtout_loc(i) = Qt_up_loc(i) + Qt_outlet_loc(i);

    Qtin_loc(i) = sqrt(R.*Ux_inlet.*Ut_inlet).'*IWr*sqrt(R.*Ux_inlet.*Ut_inlet);
    Bal(i) = Qtout_loc(i)+Ft_AD_loc(i);%+tau(i);
end
%%
Balance_th = figure('units','normalized','outerposition',[0 0 0.5 1]);set(gcf,'Color','White');
plot(Matrices.XmGLC(1,:),Qtin_loc,'k*-');
hold on
plot(Matrices.XmGLC(1,:),Qt_outlet_loc,'k+-')
hold on
plot(Matrices.XmGLC(1,:),Ft_AD_loc,'ko-')
% hold on
% plot(Matrices.XmGLC(1,:),Bal,'k^-')
set(gco,'markersize',20);
leg = legend('Q_{in}','Q_{out}','Forcing');
set(leg,'location','best','fontsize',14);
Plot_options('x/D','Q','Q_{\theta}');
% savefig(Balance_th,strcat([folder,'Bal_theta']));
% saveas(Balance_th,strcat([folder,'Bal_theta','.bmp']));