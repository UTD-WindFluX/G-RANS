function [Dfx,Dft] = Df_Dalpha(Ux,Ut);
Global
Nt = length(TSR); %number of turbines
rGLC = Matrices.RmGLC(Ind_R:end,1); %GLC nodes on r within the Actuator Disk
[~,alpha] = Angle_of_Attack(Ux,Ut);% angle of attack
[f_x,f_t,g]=Correction(Ux,Ut); %correction factors
exp_hub = zeros(Nrd,Nt); exp_tip = exp_hub;
arg_hub = exp_hub; arg_tip = exp_tip;
for k=1:Nt
%     if TSR(k)>= 5
%     g(k)=169.9*exp(-1*TSR(k))+.1285;
%     else 
%     g(k)=1.288;
%     end
    g(k)=exp(-.2431*(3*TSR_theor(k)-16.18))+.03778;
    ghub = 1;
    % tip and hub corrections
%     if TSR(k)<5
%         fxh=-0.0267*5+0.21;
%     elseif TSR(k)<7.8
%         fxh=-0.0267*TSR(k)+0.21;
%     else 
%         fxh=-0.0267*7.8+0.21;
%     end
%     fth=fxh;
%     fxt=-0.01*TSR(k)+0.59;
% 
%     if TSR(k)<=6.5
%         ftt=-0.0256*TSR(k)+0.653;
%     elseif TSR(k)<=7.5
%         ftt=-0.0086*TSR(k)+0.5425;
%     elseif TSR(k)<=8.2
%         ftt=-0.01*TSR(k)+0.5530;
%     else
%         ftt=-0.02*TSR(k)+0.635;
%     end
    fxh = nac(k); fth = fxh;
    ftt = 0.5; fxt = ftt;
%% Der. fx
    arg_hub(:,k) = 3*ghub*(rGLC-fxh)./(2*rGLC);
    exp_hub(:,k) = exp(-arg_hub(:,k)./sind(alpha(:,k)+tw));
    Dfx_hub(:,k) = real(-2./(pi*sqrt(1-exp_hub(:,k).^2)).*exp_hub(:,k).*arg_hub(:,k).*cosd(alpha(:,k)+tw)./(sind(alpha(:,k)+tw).^2));
    Dfx_hub(end,k) = 0;
    arg_tip(:,k) =  3*g(k)*(fxt-rGLC)./(2*rGLC);
    exp_tip(:,k) = exp(-arg_tip(:,k)./sind(alpha(:,k)+tw));
    Dfx_tip(:,k) = real(-2./(pi*sqrt(1-exp_tip(:,k).^2)).*exp_tip(:,k).*arg_tip(:,k).*cosd(alpha(:,k)+tw)./(sind(alpha(:,k)+tw).^2));
    Dfx_tip(end,k) = 0;
    Dfx (:,k) = Dfx_hub(:,k).*f_x.tip(:,k) + f_x.hub(:,k).*Dfx_tip(:,k);
    
%% Der. ft
    arg_hub(:,k) = 3*ghub*(rGLC-fth)./(2*rGLC);
    exp_hub(:,k) = exp(-arg_hub(:,k)./sind(alpha(:,k)+tw));
    Dft_hub(:,k) = real(-2./(pi*sqrt(1-exp_hub(:,k).^2)).*exp_hub(:,k).*arg_hub(:,k).*cosd(alpha(:,k)+tw)./(sind(alpha(:,k)+tw).^2));
    Dft_hub(end,k) = 0;
    arg_tip(:,k) =  3*g(k)*(ftt-rGLC)./(2*rGLC);
    exp_tip(:,k) = exp(-arg_tip(:,k)./sind(alpha(:,k)+tw));
    Dft_tip(:,k) = real(-2./(pi*sqrt(1-exp_tip(:,k).^2)).*exp_tip(:,k).*arg_tip(:,k).*cosd(alpha(:,k)+tw)./(sind(alpha(:,k)+tw).^2));
    Dft_tip(end,k) = 0;
    Dft (:,k) = Dft_hub(:,k).*f_t.tip(:,k) + f_t.hub(:,k).*Dft_tip(:,k);
end
end