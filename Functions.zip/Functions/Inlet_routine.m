%% Creates the reference LES velocity vector
xL = xLES(find(xLES==X_start):find(xLES==X_end)); 
rL = rLES(find(rLES==R_start):find(rLES==R_end)); %includes only the locations within the RANS dom.
[XLES,RLES] = meshgrid(xLES,rLES);
%%
Ux_ref = rot90(Ux_LES(find(rLES==R_start):find(rLES==R_end),find(xLES==X_start):find(xLES==X_end)),2);
Ur_ref = rot90(Ur_LES(find(rLES==R_start):find(rLES==R_end),find(xLES==X_start):find(xLES==X_end)),2);
Ut_ref = rot90(Ut_LES(find(rLES==R_start):find(rLES==R_end),find(xLES==X_start):find(xLES==X_end)),2);
qExp = [reshape(Ur_ref.',NxL*NrL,1); reshape(Ut_ref.',NxL*NrL,1); reshape(Ux_ref.',NxL*NrL,1)];

Ux_in = interp2(XLES,RLES,Ux_LES,Matrices.XmGLC+xmin,Matrices.RmGLC,'linear');
Ut_in = interp2(XLES,RLES,Ut_LES,Matrices.XmGLC+xmin,Matrices.RmGLC,'linear');
Ur_in = 0*interp2(XLES,RLES,Ur_LES,Matrices.XmGLC+xmin,Matrices.RmGLC,'linear');

Ref.Ux = repmat(Ux_in(:,end),1,Nx);
Ref.Ut = repmat(Ut_in(:,end),1,Nx);
Ref.Ur = repmat(Ur_in(:,end),1,Nx);
Ref.ALL = [reshape(Ref.Ur.',Nx*Nr,1); reshape(Ref.Ut.',Nx*Nr,1); reshape(Ref.Ux.',Nx*Nr,1); zeros(NxGC*NrGC,1)];