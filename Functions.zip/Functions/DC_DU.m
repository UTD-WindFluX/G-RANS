function [DCth,DCtg] = DC_DU(Ux,Ut);
Global
Nt = length(TSR);
rGLC = Matrices.RmGLC(Ind_R:end,1); %GLC nodes on r within the Actuator Disk
[~,alpha] = Angle_of_Attack(Ux,Ut);
Dalpha = Dalpha_DU(Ux,Ut);
DCth.Ux = zeros(Nrd,Nt); DCth.Ut = zeros(Nrd,Nt);
DCtg.Ux = zeros(Nrd,Nt); DCtg.Ut = zeros(Nrd,Nt);
[DCL_dalpha,DCD_dalpha] = dCL_dCD_Dalpha(alpha);
for k=1:Nt
    out = LiftDragBT1(rGLC,alpha(:,k));
    CL = out(:,3); CD = out(:,4);
    gamma = alpha(:,k)+tw;
    DCth.Ux(:,k) = Dalpha.Ux(:,k).*(DCD_dalpha(:,k).*sind(gamma) + CD.*cosd(gamma)+...
                    DCL_dalpha(:,k).*cosd(gamma) - CL.*sind(gamma));
    DCth.Ux(:,k)=  (rGLC>rGLC(nac_ind(k)-Ind_R(k))).*DCth.Ux(:,k);
    
    DCth.Ut(:,k) = Dalpha.Ut(:,k).*(DCD_dalpha(:,k).*sind(gamma) + CD.*cosd(gamma)+...
                    DCL_dalpha(:,k).*cosd(gamma) - CL.*sind(gamma));
    DCth.Ut(:,k)=  (rGLC>rGLC(nac_ind(k)-Ind_R(k))).*DCth.Ux(:,k);     
    
    DCtg.Ux(:,k) = Dalpha.Ux(:,k).*(DCL_dalpha(:,k).*sind(gamma) + CL.*cosd(gamma)-...
                    DCD_dalpha(:,k).*cosd(gamma) + CD.*sind(gamma));
    DCtg.Ux(:,k)=  (rGLC>rGLC(nac_ind(k)-Ind_R(k))).*DCtg.Ux(:,k);     
    
    DCtg.Ut(:,k) = Dalpha.Ut(:,k).*(DCL_dalpha(:,k).*sind(gamma) + CL.*cosd(gamma)-...
                    DCD_dalpha(:,k).*cosd(gamma) + CD.*sind(gamma));
    DCtg.Ut(:,k)=  (rGLC>rGLC(nac_ind(k)-Ind_R(k))).*DCtg.Ut(:,k);
end
end