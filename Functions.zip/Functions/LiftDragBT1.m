function [output]= LiftDragBT1(r,AoA)
CL=zeros(length(r),1);
CD=zeros(length(r),1);
Filenames='clcdalpha.txt';

for i=1:length(r)
    if r(i)<=0.5
       AoA_CL_CD=importdata(Filenames); 
       AoA_CL_CD=AoA_CL_CD.data;
%        [~,b]=min(abs(AoA(i)-AoA_CL_CD(:,1)));
%        CL(i)=AoA_CL_CD(b,2);
%        CD(i)=AoA_CL_CD(b,3);
       CD(i) = interp1(AoA_CL_CD(:,1),AoA_CL_CD(:,3),AoA(i),'linear','extrap'); %CL obtained as interp. of initial dataset
       CL(i) = interp1(AoA_CL_CD(:,1),AoA_CL_CD(:,2),AoA(i),'linear','extrap'); %CL obtained as interp. of initial dataset
    end
end
output=[r, AoA, CL,CD];
