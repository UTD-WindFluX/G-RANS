% Check
Ux1=Ux_farm(:,i);
Ur0=Ur_farm(:,i-1);
Ur1=Ur_farm(:,i);
Ut1=Ut_farm(:,i);
r=rGLC;
lm=0;
P1=P_farm(:,i);
Fx_eff;
Ft_eff;
nu_amb=nu_t_farm(:,i);
nut1=nu_t_farm(:,i);