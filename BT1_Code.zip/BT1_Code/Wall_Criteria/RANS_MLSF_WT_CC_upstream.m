function [output]=RANS_MLSF_WT_CC_upstream(r,deltax,Re,lm,MD1r,MD2r,Ux1,Ur0,Ur1,Ut1,P1,nu_amb,tke,nut1)
Nr=length(Ux1);
CC1=eye(Nr); CC1(end,end)=0; CC1(1,1)=0; %used to impose: Ut_new(end)=0;Ut_new(1)=0;

%% To impose p_new(end)=p_new(end-1); and Ux_new(end)=Ux_new(end-1);
% We want to impose null derivative in p(end): (MD1r*p)|(in r_end=0)=0
% In components:
% MD1r(end,1)*p(1)+MD1r(end,2)*p(2)+...+MD1r(end,end-1)*p(end-1)+MD1r(end,end)*p(end)=0
% so:
% p(end)=-MD1r(end,1)/MD1r(end,end)*p(1)-MD1r(end,2)/MD1r(end,end)*p(2)+...-MD1r(end,end-1)/MD1r(end,end)*p(end-1)
% so we have the explicit expression of the i-th coefficient that has to
% multiply p(i). Note that it arrives only to p(end-1) which means that the
% last coefficient (which multiply p(end)) is null.
D=MD1r(end,:); %last row of MD1r
D1=D(1:end-1);
D2=-D1./D(end);
%%
CC3=eye(Nr); CC3(end,end)=0;
CC3(end,1:end-1)=D2;

CC4=eye(Nr); CC4(1,1)=0; % used to impose with a matrix: Ux_new(1)=1; which is equal to say appoX(1)=0; for Ux initial conditions

CC5=eye(Nr); CC5(end,end)=0; %used to impose: Ur_new(end)=0;

invrGLC=1./r;
invrGLC(end)=1e12;

CC6=eye(Nr); % CC6 is not used here because it impose the Boundary conditions to nutVarT which was evaluated only for the unperturbed system
D3=D./invrGLC.';
CC6(end,1:end)=D3;

nut=lm^2*sqrt(((MD1r*Ut1)-Ut1./r).^2+(CC1*(MD1r*Ux1)).^2)+nu_amb -...
    0*(deltax./Ux1).^.5.*(nut1.^1.5).*(0.09^.25)/.32;
nut(end)=nut(end-1); nut(1)=nut(2);%This was added

DnutDr=CC1*MD1r*nut;%DnutDr(end)=0;DnutDr(1)=0;

appoT=CC4*(-Ur1.*(MD1r*Ut1)-Ur1.*Ut1.*invrGLC+(1/Re + nut).*((MD1r*Ut1).*invrGLC+(MD2r*Ut1)...
    -Ut1.*invrGLC.^2)+(MD1r*nut).*((MD1r*Ut1)-Ut1.*invrGLC))./Ux1; 
appoT(1)=0;%BC Top
Ut_new=CC1*(Ut1+deltax*appoT);

appoP=CC1*Ut_new.^2.*invrGLC; %appoP(end)=0; appoP(1)=0;
p_new=CC3*cumtrapz(r,appoP);%p_new(end)=p_new(end-1); p_new(1)=0;

appoX=((-Ur1.*(MD1r*Ux1)-(p_new-P1)/deltax+(1/Re +nut).*((MD1r*Ux1).*invrGLC+(MD2r*Ux1))...
    +(MD1r*nut).*(MD1r*Ux1))./Ux1); appoX(1)=(-Ux1(1)+Ux1(2))/(r(1)-r(2));
Ux_new=CC3*(Ux1+deltax*appoX); 
% Ux_new(2:end)=.005*(Ux_new(2:end)<0.005)+(Ux_new(2:end)>0.005).*Ux_new(2:end);
Ux_new(1)=0;
% [~,BLind]=min(abs(0.0002-diff(Ux_new(1:15))))
% Ur_new=CC1*(flipud(cumtrapz(flipud(r),flipud(-r.*(Ux_new-Ux1)/deltax ) ))./r);
Ur_new=(flipud(cumtrapz(flipud(r),flipud(-r.*round(Ux_new-Ux1,1)/deltax ) ))./r);
Ur_new(end)=0;Ur_new(1:14)=0;

DtkeDr=CC1*MD1r*tke;% DtkeDr(end)=0;DtkeDr(1)=0;
D2tkeDr2=MD2r*tke;%D2tkeDr2=smooth(D2tkeDr2,3); 

appotke=(-Ur_new.*DtkeDr+nut.*((MD1r*Ux1)).^2)+(nut.*((MD1r*Ut1)-Ut1.*invrGLC)).*(MD1r*Ut1)...
    -0*(0.16*abs(tke).^1.5)/0.32+(MD1r*nut).*(MD1r*tke)+nut.*(MD2r*tke)./Ux_new;
tke_new=tke+deltax*appotke;tke_new(end)=tke_new(end-1);tke_new(1)=tke(1);
tke_new(find(tke_new<0))=0;
output=[Ux_new,Ur_new,Ut_new,p_new,tke_new,nut]; 