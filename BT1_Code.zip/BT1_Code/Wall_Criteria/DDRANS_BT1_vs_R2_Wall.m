%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DATA-DRIVEN RANS with ADM 
% Author: Giacomo Valerio Iungo
% 04/11/2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clear all; %close all; clc

% ij=12;
tsr=[6];
for ii=[6]
    [~,ij]=min(abs(tsr-ii));
%% INPUTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
FileOut='RANS_BT1_01'; % Prefix for all output files
FileLES='BT1.mat';
% FileF_nacelle_new='F_nacelle_new.mat';
deltax=.0001; % grid resolution for the RANS simulation
x_turbines=[2]; % streamwise position of the turbines
% TSR=[10]; % TSR i=1 unwaked turbine
TSR(1)=ii;
dx_last=5; % x/d downstream of the last turbine 7
Epsilon=1;% Epsilon/d spreading for Fthrust (x.x)  1.1
Eps_std_x=.5; %standard deviation of the spreading for Fthrust (x.x) 0.3
Eps_std_t=.05; %standard deviation of the spreading for Ftang (x.x).1 .05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  SIMULATION INPUTS No need to be changed by the user 
d_model=.894;
nac_model=.090;
Nr=65; % number of grid points in the radial direction 30
Rmax=1.515; % max r/d from the hub 4
maprad=1; %(0/1) linear mapping/algebraic mapping
Lr=1.38; % grid refinement for algebraic mapping
Re=103600;  %Reynolds number
nac=nac_model/d_model/2; %0.045 %Nacelle radius %0.15
naclnt_model=[-.0656 .6072];
naclnt=naclnt_model./d_model;
%% Mapping and Derivatives
[yGLC,D1y]=nodiD1chebGLC(Nr-1);  
switch maprad
    case 0
        rGLC=(yGLC+1)*(Rmax/2);        
        y1GLC=(2/Rmax)*ones(size(rGLC));
        y2GLC=(2/Rmax)^2*zeros(size(rGLC));
    case 1
        ymax=(2*Lr+Rmax)/Rmax;
        rGLC=Lr*(1+yGLC)./(ymax-yGLC);
        y1GLC=Lr*(ymax+1)./(rGLC+Lr).^2;
        y2GLC=-2*Lr*(ymax+1)./(rGLC+Lr).^3;
end
MD1r=diag(y1GLC)*D1y;
D2y=D1y*D1y;
MD2r=(diag(y1GLC)).^2*D2y+diag(y2GLC)*D1y;
%% MIXING LENGTH
N_turbines=length(TSR); % Number of turbines in a single column
x_farm=0:deltax:x_turbines(N_turbines)+dx_last;
x_turb_ind=zeros(N_turbines,1);
for i=1:N_turbines
    [~,b]=min(abs(x_farm-x_turbines(i)));
    x_turb_ind(i)=b;
end
MLcoef=[0.0000 0.3142 0.045];%   0.0002 0.3142 0.025   0.2 0.055
ML=MLcoef(1,1)+0*x_farm;
aML=MLcoef(1);dML=MLcoef(3);cML=MLcoef(2);
if N_turbines>1
for k=1:N_turbines-1
    
    ML(x_turb_ind(k):x_turb_ind(k+1)-1)=...
        (aML-dML)+2*dML*...
        (1+exp( -cML*(x_farm(x_turb_ind(k):x_turb_ind(k+1)-1)-x_turbines(k)))).^-1;
end
end
ML(x_turb_ind(end):end)=(aML-dML)+2*dML*...
        (1+exp(-cML*(x_farm(x_turb_ind(end):end)-x_turbines(end)))).^-1;

% for k=1:N_turbines-1
%     aML=ML(x_turb_ind(k)-1);dML=MLcoef(k,3);cML=MLcoef(k,2);
%     ML(x_turb_ind(k):x_turb_ind(k+1)-1)=...
%         (aML-dML)+2*dML*...
%         (1+exp( -cML*(x_farm(x_turb_ind(k):x_turb_ind(k+1)-1)-x_turbines(k)))).^-1;
% end
% aML=ML(x_turb_ind(end)-1);dML=MLcoef(end,3);cML=MLcoef(end,2);
% ML(x_turb_ind(end):end)=(aML-dML)+2*dML*...
%         (1+exp(-cML*(x_farm(x_turb_ind(end):end)-x_turbines(end)))).^-1;
% figure;plot(x_farm,ML)
% for i=1:N_turbines
%     hold on;plot([x_turbines(i) x_turbines(i)],[min(ML) max(ML)],'r-.')
% end
% grid on;box on;axis tight
% xlabel('x/d');ylabel('lm/d')
% saveas(gcf,[FileOut,'_1_ML.fig'],'fig')
% saveas(gcf,[FileOut,'_1_ML.tiff'],'tiff')
% close all
%% Matrix preparation
Nx=length(x_farm);
Ux_farm=ones(Nr,Nx);
Ux_farm(1,:)=0;
Ut_farm=zeros(Nr,Nx);
Ur_farm=zeros(Nr,Nx);
P_farm=zeros(Nr,Nx);
nu_amb_farm=zeros(Nr,N_turbines);
nu_t_farm=zeros(Nr,Nx);
tke_farm=zeros(Nr,Nx);
TI_farm=zeros(Nr,Nx);
U_infty=zeros(N_turbines,1);
Omega=zeros(N_turbines,1);
Vtan_rel=zeros(Nr,N_turbines);
Vrel=zeros(Nr,N_turbines);
alfa=zeros(Nr,N_turbines);
CL=zeros(Nr,N_turbines);
CD=zeros(Nr,N_turbines);
CThrust=zeros(Nr,N_turbines);
CTang=zeros(Nr,N_turbines);
g=zeros(N_turbines,1);
f_tip_x=zeros(Nr,N_turbines);
f_hub_x=zeros(Nr,N_turbines);
f_x=zeros(Nr,N_turbines);
f_tip_t=zeros(Nr,N_turbines);
f_hub_t=zeros(Nr,N_turbines);
f_t=zeros(Nr,N_turbines);
F_Thrust=zeros(Nr,N_turbines);
F_Tang=zeros(Nr,N_turbines);
F_nacelle=zeros(Nr,N_turbines);
TI_r=zeros(N_turbines,1);
clear Velfield;
%% Blade characteristics
Aerodyn=BlindTest1(rGLC); % r chord twist Airfoil_class
chord=Aerodyn(:,2);
twist=Aerodyn(:,3);
airfoil=Aerodyn(:,4);
% figure;plot(rGLC,chord)
% grid on;box on;xlim([0 .5])
% xlabel('r/d');ylabel('chordlength/d')
% saveas(gcf,[FileOut,'_2_c.fig'],'fig')
% saveas(gcf,[FileOut,'_2_c.tiff'],'tiff')
% close all
% figure;plot(rGLC,twist)
% grid on;box on;xlim([0 1])
% xlabel('r/d');ylabel('twist [deg]')
% saveas(gcf,[FileOut,'_3_twist.fig'],'fig')
% saveas(gcf,[FileOut,'_3_twist.tiff'],'tiff')
% close all
% figure;plot(rGLC,airfoil,'o')
% grid on;box on;xlim([0 .5])
% xlabel('r/d');ylabel('airfoil Type')
% saveas(gcf,[FileOut,'_4_airfoil.fig'],'fig')
% saveas(gcf,[FileOut,'_4_airfoil.tiff'],'tiff')
% close all
%% Turbine loads and spreading function
pd_x = makedist('Normal','mu',0,'sigma',Eps_std_x);
t_x=truncate(pd_x,-Epsilon,Epsilon);
Gaussian_trunc_x=pdf(t_x,-Epsilon:deltax:Epsilon);

Eps_ind=(length(Gaussian_trunc_x)-1)/2;

pd_t = makedist('Normal','mu',0,'sigma',Eps_std_t);
t_t=truncate(pd_t,-Epsilon,Epsilon);
Gaussian_trunc_t=pdf(t_t,-Epsilon:deltax:Epsilon);

% figure;plot(-Epsilon:deltax:Epsilon,Gaussian_trunc_x);
% hold on;;plot(-Epsilon:deltax:Epsilon,Gaussian_trunc_t,'r');
% grid on;box on;legend('Thrust','Tangent','Location','Best')
% xlabel('(x-x_T)/d');ylabel('Spreading function')

% saveas(gcf,[FileOut,'_5_Spread.fig'],'fig')
% saveas(gcf,[FileOut,'_5_Spread.tiff'],'tiff')
%close all
[~,R_ind]=min(abs(rGLC-.5));
if rGLC(R_ind)<0.5
    R_ind=R_ind-1;
end
[~,d_ind]=min(abs(rGLC-1));
[~,nac_ind]=min(abs(rGLC-nac));

%% RANS
% Upstream area
TI=0.003; %Same turbulence
tke=1.5*(TI)^2;
tke_farm(:,1)=ones(Nr,1)*tke;
nu_amb_farm(:,1)=.000000+.55*sqrt(tke_farm(:,1))*.817/.894*.41;%.817/.894*.41 
c_ML=ones(N_turbines,1)*1;
c_nu=ones(N_turbines,1)*1;
if (-2/rGLC(R_ind)^2*trapz(rGLC(R_ind:end),rGLC(R_ind:end).*nu_amb_farm(R_ind:end,1))/.0004)^0.5*1.875*0.35>1
    c_ML(1)=(-2/rGLC(R_ind)^2*trapz(rGLC(R_ind:end),rGLC(R_ind:end).*nu_amb_farm(R_ind:end,1))/.0004)^0.5*1.875*0.35;
end
correct_x=ones(N_turbines,1);
correct_t=ones(N_turbines,1);

tic
for i=1:x_turb_ind(1)-Eps_ind-1
    if i==1
    Velfield=RANS_MLSF_WT_CC_upstream(rGLC,deltax,Re,c_ML(1)*ML(i),MD1r,MD2r,Ux_farm(:,i),...
        Ur_farm(:,i),Ur_farm(:,i),Ut_farm(:,i),P_farm(:,i),nu_amb_farm(:,1),tke_farm(:,i),nu_t_farm(:,i));
    else 
      Velfield=RANS_MLSF_TKE_CC_upstream(rGLC,deltax,Re,c_ML(1)*ML(i),MD1r,MD2r,Ux_farm(:,i),...
        Ur_farm(:,i-1),Ur_farm(:,i),Ut_farm(:,i),P_farm(:,i),nu_amb_farm(:,1),tke_farm(:,i),nu_t_farm(:,i));
    end
    Ux_farm(:,i+1)=Velfield(:,1); Ur_farm(:,i+1)=Velfield(:,2);
    Ut_farm(:,i+1)=Velfield(:,3);P_farm(:,i+1)=Velfield(:,4);
    tke_farm(:,i+1)=Velfield(:,5);nu_t_farm(:,i+1)=Velfield(:,6);
    TI_farm(:,i+1)=(2/3*tke_farm(:,i+1)./(Ux_farm(:,i+1).^2+Ut_farm(:,i+1).^2+Ur_farm(:,i+1).^2)).^.5;
end
t=toc;display(['RANS UPSTREAM AREA s ' num2str(t)])
tf=1;

for k=1:N_turbines
    tic
    % CALCULATION OF THE AERODYNAMIC FORCES
    U_infty(k)=2/(rGLC(R_ind)^2)*trapz(flipud(rGLC(R_ind:end)),...
        flipud(rGLC(R_ind:end).*Ux_farm(R_ind:end,x_turb_ind(k)-Eps_ind)));
    Omega(k)=2*U_infty(1)*TSR(k); % angular velocity TSR * U_\infty/R
    Vtan_rel(:,k)=Omega(k)*rGLC-Ut_farm(:,x_turb_ind(k)-Eps_ind); % Relative tangential velocity 
    Vrel(:,k)=sqrt(Vtan_rel(:,k).^2+Ux_farm(:,x_turb_ind(k)-Eps_ind).^2); % Magnitude of the relative velocity
    alfa(:,k)=atand(Ux_farm(:,x_turb_ind(k)-Eps_ind)./Vtan_rel(:,k))-twist;
    AerodynForce=LiftDragBT1(rGLC,alfa(:,k),airfoil);
    CL(:,k)=AerodynForce(:,3);
    CD(:,k)=AerodynForce(:,4);
    CThrust(:,k)=CD(:,k).*sind(alfa(:,k)+twist)+CL(:,k).*cosd(alfa(:,k)+twist);
    CTang(:,k)=-CD(:,k).*cosd(alfa(:,k)+twist)+CL(:,k).*sind(alfa(:,k)+twist);
    CTang(:,k)=((rGLC>rGLC(nac_ind)).*(CTang(:,k)));
    CTang(:,k)=(CTang(:,k)>0).*CTang(:,k);
    CThrust(:,k)=((rGLC>rGLC(nac_ind)).*CThrust(:,k));
    

    g(k)=0.87*exp(-0.378*TSR(k))+.12;
%     g(k)=.13;
   % tip and hub corrections
    if TSR(k)>6
        fxt=-0.02*TSR(k)+0.72; 
%         fxh=-.01*TSR(k)+.11;
        
    else 
        fxt=0.0333*TSR(k)+0.4;
%         fxh=.05;
    end
    fxh=.01667*TSR(k)-.05;
    
%     fxt=.52;
%     fxh=0.1;
%    if TSR(k)>4.6
%         %ftt=1;
%         ftt=-0.0001503*TSR(k)^4+0.00225*TSR(k)^3 + 0.0006081*TSR(k)^2 - 0.1538*TSR(k) + 1.081; %wake A
%     else if TSR(k)<3.6
%         ftt=0.85;
%         else
%             
%         ftt=-0.3524*TSR(k)+2.185;
%         end
%     end
    fth=fxh;
    ftt=-.04*TSR(k)+.77;
%     ftt=.52;
    
    f_tip_x(:,k)=real(2/pi*acos(exp(-g(k)*3*(fxt-rGLC)./(2*rGLC.*sind(alfa(:,k)+twist)))));
    f_hub_x(:,k)=real(2/pi*acos(exp(-g(k)*3*(rGLC-fxh)./(2*rGLC.*sind(alfa(:,k)+twist)))));%.001
    f_x(:,k)=correct_x(k)*f_tip_x(:,k).*f_hub_x(:,k);
    f_tip_t(:,k)=real(2/pi*acos(exp(-g(k)*3*(ftt-rGLC)./(2*rGLC.*sind(alfa(:,k)+twist)))));
    f_hub_t(:,k)=real(2/pi*acos(exp(-g(k)*3*(rGLC-fth)./(2*rGLC.*sind(alfa(:,k)+twist)))));
    f_t(:,k)=correct_t(k)*f_tip_t(:,k).*f_hub_t(:,k);
    F_Thrust(:,k)=((2*pi*rGLC).^-1).*.5.*Vrel(:,k).^2.*chord.*f_x(:,k).*3.*CThrust(:,k);F_Thrust(end,k)=F_Thrust(end-1,k);
    F_Tang(:,k)=((2*pi*rGLC).^-1).*.5.*Vrel(:,k).^2.*chord.*f_t(:,k).*3.*(CTang(:,k));F_Tang(end,k)=0;
    F_nacelle(:,k)=.5.*Vrel(:,k).^2.*2*0.5;F_nacelle(end,k)=F_nacelle(end-1,k);%0.65 instead of nac*15
    F_nacelle(:,k)=(rGLC<nac).*F_nacelle(:,k);
    if F_nacelle(nac_ind)==0
        nac_ind=nac_ind+1;
    end
%     F_nacelle(nac_ind:end,k)=flipud(F_nacelle(nac_ind:end,k));  % New modification to F_nacelle
    F_nacelle_g(:,k)=.8*(F_nacelle(end,k)).*exp(-((rGLC-0.0)/(0.14)).^2);% (-1.7*nac+0.2105)
    F_nacelle_g(:,k)=(rGLC<.18).*F_nacelle_g(:,k); %.23  

%     F_nacref(:,k)=Vrel(:,k).^2.*0.68;F_nacref(end,k)=F_nacref(end-1,k); %18 %4 %.68
%     F_nacref(:,k)=(rGLC<nac(k)).*F_nacref(:,k);
%     F_nacelle_new1= (F_nacref(end,k)).*exp(-((rGLC-0.0)/(-1.7*nac+0.2105)).^2);
%     F_nacelle_new1=(rGLC<.23).*F_nacelle_new1; %.23
   
    
%    F_nacelle(nac_ind:end,k)=flipud(F_nacelle(nac_ind:end,k));
    [~,hubx_ind]=min(abs(f_hub_x));
    [~,xmax_ind]=max(F_Thrust(:,k));
    [~,tmax_ind]=max(F_Tang(:,k));
    a_x=diff(F_Thrust(xmax_ind:Nr),1);
    a_t=diff(F_Tang(tmax_ind:Nr),1);
    [~,Fxm_ind]=max(abs(a_x));
    [~,Ftm_ind]=max(abs(a_t));
    [~,Fxz_ind]=min(abs(a_x));
    Fxz_ind=Fxz_ind+xmax_ind-1;
    Fxm_ind=Fxm_ind+xmax_ind;
    Ftm_ind=Ftm_ind+tmax_ind;

    % RANS WITH FORCING
    for i=x_turb_ind(k)-Eps_ind:x_turb_ind(k)+Eps_ind
        
        Fx_eff=zeros(Nr,1);
        Ft_eff=Gaussian_trunc_t(i-x_turb_ind(k)+Eps_ind+1)*F_Tang(:,k);
        if (x_farm(i)-x_turbines(k))<naclnt(1) || (x_farm(i)-x_turbines(k))>naclnt(2) %-.15 .05 %-.09 0.4658
        Fx_eff=0*F_nacelle(:,k)+Gaussian_trunc_x(i-x_turb_ind(k)+Eps_ind+1)*F_Thrust(:,k);
%           Fx_eff(Fxz_ind:Nr-1)=interp1(rGLC([Fxz_ind-1 Nr]),Fx_eff([Fxz_ind-1 Nr]),rGLC(Fxz_ind:Nr-1));
%         Fx_eff(Fxm_ind:end)=Fx_eff(Fxm_ind-1);
%         Ft_eff(Ftm_ind:nac_ind)=Ft_eff(Ftm_ind-1);
%         Fx_eff(xmax_ind:end)=smooth(Fx_eff(xmax_ind:end));
%         Fx_eff(R_ind:xmax_ind)=smooth(Fx_eff(R_ind:xmax_ind));%new
%         Ft_eff(tmax_ind:end)=smooth(Ft_eff(tmax_ind:end));
%         Ft_eff(R_ind:tmax_ind)=smooth(Ft_eff(R_ind:tmax_ind));%new
        else
          Fx_eff=F_nacelle_g(:,k)+Gaussian_trunc_x(i-x_turb_ind(k)+Eps_ind+1)*F_Thrust(:,k);
%           Fx_eff(xmax_ind:end)=smooth(Fx_eff(xmax_ind:end));
%           Fx_eff(R_ind:xmax_ind)=smooth(Fx_eff(R_ind:xmax_ind));%new
%           Ft_eff(tmax_ind:end)=smooth(Ft_eff(tmax_ind:end));
%           Ft_eff(R_ind:tmax_ind)=smooth(Ft_eff(R_ind:tmax_ind));%new
        end
        
        if k==1;
            nu_amb_input=nu_amb_farm(:,k);ML_coef=c_ML(k);
        else

        if i==x_turb_ind(k)-0.3/deltax;
        der=((MD1r*Ux_farm(:,i)).^2+(MD1r*Ut_farm(:,i)-Ut_farm(:,i)./rGLC).^2).^0.5;
        c_ML(k)= 59.28*(nu_t_farm(R_ind,i)./der(R_ind))^0.5+1;
          if c_ML(k)<1
                c_ML(k)=1
          elseif c_ML(k)>8
                c_ML(k)=8;
          end
        end
            if  i<x_turb_ind(k)
                nu_amb_input=nu_amb_farm(:,k-1);ML_coef=c_ML(k-1);
            else
                if i==x_turb_ind(k)
                    nu_amb_farm(:,k)=nu_t_farm(:,i);ML_coef=c_ML(k);
                end
                nu_amb_input=nu_amb_farm(:,k);
            end
        end
    
        Velfield=RANS_ADM_MLSF_WT_CC(rGLC,deltax,Re,ML_coef*ML(i),MD1r,MD2r,Ux_farm(:,i),Ur_farm(:,i-1),Ur_farm(:,i),Ut_farm(:,i),P_farm(:,i),...
            Fx_eff,Ft_eff,nu_amb_input,tke_farm(:,i),nu_t_farm(:,i));
        Ux_farm(:,i+1)=Velfield(:,1);        Ur_farm(:,i+1)=Velfield(:,2);
        Ut_farm(:,i+1)=Velfield(:,3);        P_farm(:,i+1)=Velfield(:,4);
        tke_farm(:,i+1)=Velfield(:,5);      nu_t_farm(:,i+1)=Velfield(:,6);
        TI_farm(:,i+1)=(2/3*tke_farm(:,i+1)./(Ux_farm(:,i+1).^2+Ut_farm(:,i+1).^2+Ur_farm(:,i+1).^2)).^.5;
        tf=isreal(Velfield);
        if tf==0
            display('CRASHED!!')
            break;
        end   
    end
if tf==0
    break;
end   
    % RANS FOR WAKE RECOVERY
    if k<N_turbines
        lim=x_turb_ind(k+1)-Eps_ind-1;
    else
        lim=Nx-1;
    end
    for i=x_turb_ind(k)+Eps_ind+1:lim
         Velfield=RANS_MLSF_WT_CC(rGLC,deltax,Re,c_ML(k)*ML(i),MD1r,MD2r,Ux_farm(:,i),Ur_farm(:,i-1),Ur_farm(:,i),Ut_farm(:,i),P_farm(:,i),nu_amb_input,tke_farm(:,i),nu_t_farm(:,i));
        Ux_farm(:,i+1)=Velfield(:,1);        Ur_farm(:,i+1)=Velfield(:,2);
        Ut_farm(:,i+1)=Velfield(:,3);        P_farm(:,i+1)=Velfield(:,4);
        tke_farm(:,i+1)=Velfield(:,5);      nu_t_farm(:,i+1)=Velfield(:,6);
        TI_farm(:,i+1)=(2/3*tke_farm(:,i+1)./(Ux_farm(:,i+1).^2+Ut_farm(:,i+1).^2+Ur_farm(:,i+1).^2)).^.5;
        tf=isreal(Velfield);
        if tf==0
            display('CRASHED!!')
            break;
        end
    end
if k<N_turbines
c_nu(k+1)=(-2/rGLC(R_ind)^2*trapz(rGLC(R_ind:end),rGLC(R_ind:end).*nu_t_farm(R_ind:end,i+1))/.0001377)^0.5;   
TI_r(k+1)=2/((rGLC(R_ind))^2)*trapz(flipud(rGLC(R_ind:end)),flipud(rGLC(R_ind:end).*TI_farm(R_ind:end,i)));
if (TI_r(k+1)-TI)>=0
correct_x(k+1,1)=  0.6 *exp(-0.085*100*(TI_r(k+1)-TI))+0.4; % Fit with TI_r
correct_t(k+1,1)=  0.2094 *exp(-0.1*100*(TI_r(k+1)-TI))+0.79; % TI_r  R13
end
end
t=toc;display(['RANS Turbine' num2str(k) ' s ' num2str(t)])

end
display('RANS DONE')
%% MAPS
load(FileLES)
% xLES=xLES+x_turbines(1);
% Ux_LES_int=flipud(interp2(xLES,rLES,Ux_LES,x_farm,flipud(rGLC)));
% Ut_LES_int=flipud(interp2(xLES,rLES,Ut_LES,x_farm,flipud(rGLC)));
% Ur_LES_int=flipud(interp2(xLES,rLES,Ur_LES,x_farm,flipud(rGLC)));
x = x_turbines(1);
% figure;
% subplot(3,1,1);
% pcolor(x_farm,rGLC(d_ind:end),Ux_LES_int(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([0 1.1]);ylim([0 .75]);
% xlabel('x/d');ylabel('r/d');title('U_x LES')

% grid on;box on;subplot(3,1,2);
% pcolor(x_farm,rGLC(d_ind:end),Ux_farm(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([0 1.1])
% xlabel('x/d');ylabel('r/d');title('U_x DD-RANS')
% grid on;box on;ylim([0 0.8]);
% saveas(gcf,[FileOut,'_Uxmap.fig'],'fig')
% saveas(gcf,[FileOut,'_Uxmap.tiff'],'tiff')

% subplot(3,1,3);pcolor(x_farm,rGLC(d_ind:end),Ux_LES_int(d_ind:end,:)-Ux_farm(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([-.2 .2])
% xlabel('x/d');ylabel('r/d');title('U_x LES-DD-RANS')
% grid on;box on;ylim([0 .75]);
% saveas(gcf,[FileOut,'_6_Uxmap.fig'],'fig')
% saveas(gcf,[FileOut,'_6_Uxmap.tiff'],'tiff')
% close all

% figure;subplot(3,1,1);pcolor(x_farm,rGLC(d_ind:end),Ut_LES_int(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([0 .2])
% xlabel('x/d');ylabel('r/d');title('U_t LES')
% grid on;box on;
% subplot(3,1,2);pcolor(x_farm,rGLC(d_ind:end),-Ut_farm(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([0 .2])
% xlabel('x/d');ylabel('r/d');title('U_t DD-RANS')
% grid on;box on;
% subplot(3,1,3);pcolor(x_farm,rGLC(d_ind:end),Ut_LES_int(d_ind:end,:)+Ut_farm(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([-.05 .05])
% xlabel('x/d');ylabel('r/d');title('U_t LES - DD-RANS')
% grid on;box on;
% saveas(gcf,[FileOut,'_7_Utmap.fig'],'fig')
% saveas(gcf,[FileOut,'_7_Utmap.tiff'],'tiff')
% close all
% 
% figure;subplot(3,1,1);pcolor(x_farm,rGLC(d_ind:end),Ur_LES_int(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([0 .2])
% xlabel('x/d');ylabel('r/d');title('U_r LES')
% grid on;box on;
% subplot(3,1,2);pcolor(x_farm,rGLC(d_ind:end),Ur_farm(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([0 .2])
% xlabel('x/d');ylabel('r/d');title('U_r DD-RANS')
% grid on;box on;
% subplot(3,1,3);pcolor(x_farm,rGLC(d_ind:end),Ur_LES_int(d_ind:end,:)-Ur_farm(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;caxis([-.05 .05])
% xlabel('x/d');ylabel('r/d');title('U_r LES-DD-RANS')
% grid on;box on;
% saveas(gcf,[FileOut,'_8_Urmap.fig'],'fig')
% saveas(gcf,[FileOut,'_8_Urmap.tiff'],'tiff')
% close all
% 
% figure;subplot(3,1,1)
% pcolor(x_farm,rGLC(d_ind:end),P_farm(d_ind:end,:));
% shading flat;colormap coolwarm;colorbar;
% xlabel('x/d');ylabel('r/d');title('P DD-RANS')
% grid on;box on;
% subplot(3,1,2);pcolor(x_farm,rGLC(d_ind:end),tke_farm(d_ind:end,:));
% shading flat;colormap jet;colorbar;
% xlabel('x/d');ylabel('r/d');title('tke DD-RANS')
% grid on;box on;axis tight;%caxis([0 .035])
% subplot(3,1,3);pcolor(x_farm,rGLC(d_ind:end),nu_t_farm(d_ind:end,:));
% shading flat;colormap jet;colorbar;
% xlabel('x/d');ylabel('r/d');title('\nu_t DD-RANS')
%grid on;box on;axis tight;%caxis([0 .035])
% saveas(gcf,[FileOut,'_9_p_tke_nut.fig'],'fig')
% saveas(gcf,[FileOut,'_9_p_tke_nut.tiff'],'tiff')
% close all
    
%% PLOT
%  [~,bb]=min(abs(x_farm-4));figure;hold all;plot(rGLC,tke_farm(:,bb));xlim([0 1]);plot(r_LES,TKE_LES(:,2))
% figure;
% plot(rGLC,nu_amb_farm);grid on;xlim([0 2])
% figure;
% plot(r_LES,TKE_LES);grid on;xlim([0 2])
load('BT1_Exp.mat')
 figure('units','normalized','outerposition',[0 0 1 1]);set(gcf,'Color','White');set(gcf,'color',[1 1 1]);
% plot(TSR3_U_1d(:,1),-TSR3_U_1d(:,2)+1,'rx-');hold on;
% plot(TSR3_U_3d(:,1),-TSR3_U_3d(:,2)+1,'bx-');hold on;
% plot(TSR3_U_5d(:,1),-TSR3_U_5d(:,2)+1,'gx-');hold on;
% plot(TSR6_U_1d(:,1),-TSR6_U_1d(:,2)+1,'bx-');hold on;
% plot(TSR6_U_3d(:,1),-TSR6_U_3d(:,2)+1,'rx-');hold on;
% plot(TSR6_U_5d(:,1),-TSR6_U_5d(:,2)+1,'yx-');hold on;
% plot(TSR10_U_1d(:,1),-TSR10_U_1d(:,2)+1,'bx-');hold on;
% plot(TSR10_U_3d(:,1),-TSR10_U_3d(:,2)+1,'rx-');hold on;
% plot(TSR10_U_5d(:,1),-TSR10_U_5d(:,2)+1,'yx-');hold on;

for k=1:N_turbines
    x_sel=x_turbines(k) + [1 2 3 4 5];
    x_sel_ind=zeros(length(x_sel),1);
%     figure;hold all
    for i=1:length(x_sel)
        [~,ind]=min(abs(x_farm-x_sel(i)));x_sel_ind(i)=ind;
%         plot(rGLC,tke_farm(:,ind));grid on;axis tight
    end
%     xlim([0 1])

for i=1:length(x_sel)
        % Put Uavg1 and tke1 for 1D and Uavg3 and tke3 for 3D
        
        hold on;plot(vertcat(-rGLC,flip(rGLC(1:end-1))),vertcat(Ux_farm(:,x_sel_ind(i)),flip(Ux_farm(1:end-1,x_sel_ind(i)))),'--d');
        title(['U_x']);grid on;box on;
        ylabel('U_x'); xlabel('r/d'); set(gca,'FontSize',16,'FontName','Arial','FontWeight','normal');
       %         
%         figure('units','normalized','outerposition',[0 0 1 1]);set(gcf,'Color','White');set(gcf,'color',[1 1 1]);
%         plot(rGLC,1-Ux_farm(:,x_sel_ind(i)),'d');xlim([-.1 1]) 
%         hold on;%plot(D1,Uavg1,'ro');%plot(D0,Uavg0,'k*');
%         title(['1D U_x x/d=' num2str(x_farm(x_sel_ind(i)))]);grid on;box on;
%         ylabel('U_x'); xlabel('r/d'); set(gca,'FontSize',16,'FontName','Arial','FontWeight','normal');
%         legend('1D RANS','1D DATA')    
         
%           figure('units','normalized','outerposition',[0 0 1 1]);set(gcf,'Color','White');set(gcf,'color',[1 1 1]);  
%           plot(rGLC,Ux_farm(:,x_sel_ind(i)),'d');xlim([-.1 1]) 
%           hold on;plot(D3,Uavg3,'ro');%plot(D00,Uavg00,'k*');
%           title(['3D  U_x x/d=' num2str(x_farm(x_sel_ind(i)))]);grid on;box on;
%           ylabel('U_x'); xlabel('r/d');set(gca,'FontSize',16,'FontName','Arial','FontWeight','normal');
%           legend('3D RANS','3D DATA') 
% % %           
%        
%         figure;
%         plot(rGLC,tke_farm(:,x_sel_ind(i)),'d');xlim([0 1])
%         hold on;%plot(D3,tke3,'ro');
%         xlabel('x/d');ylabel('r/d');title('tke DD-RANS');grid on;box on;


%         subplot(1,2,2);loglog(rGLC,tke_farm(:,x_sel_ind(i)),'d'); xlim([-.1 1]) 
%         hold on;plot(D4,tke3,'ro');
%         xlabel('x/d');ylabel('r/d');title('tke DD-RANS');grid on;box on;
%         
        
%         figure('units','normalized','outerposition',[0 0 1 1])
%         set(gcf,'color',[1 1 1])

%         subplot(2,3,1);plot(rGLC,Ux_farm(:,x_sel_ind(i)),'d');xlim([-.1 1]) 
%         hold on;plot(D3,Uavg3,'ro');
%         title(['U_x x/d=' num2str(x_farm(x_sel_ind(i)))]);grid on

%         subplot(2,3,2);plot(rGLC,-Ut_farm(:,x_sel_ind(i)),'d');xlim([-.1 1])
%         hold on;plot(rGLC,Ut_LES_int(:,x_sel_ind(i)),'ro');
%         title(['U_t x/d=' num2str(x_farm(x_sel_ind(i)))]);grid on

%         subplot(2,3,3);plot(rGLC,Ur_farm(:,x_sel_ind(i)),'d');xlim([-.1 1])
%         hold on;plot(D,Uavg,'ro');
%         title(['U_r x/d=' num2str(x_farm(x_sel_ind(i)))]);grid on;

%         subplot(2,3,4);plot(rGLC,P_farm(:,x_sel_ind(i)),'d');xlim([-.1 1])
%         hold on;plot(rGLC,nut(:,x_sel_ind(i)),'ro');
%         xlabel('x/d');ylabel('r/d');title('P DD-RANS')
%         grid on;box on;

%         subplot(2,3,5);loglog(rGLC,tke_farm(:,x_sel_ind(i)),'d');%xlim([-.1 1])
%         hold on;plot(D4,tke4,'ro');
%         xlabel('x/d');ylabel('r/d');title('tke DD-RANS')
%         grid on;box on;

%         subplot(2,3,6);loglog(rGLC,nu_t_farm(:,x_sel_ind(i)),'d');%xlim([-.1 1])
%         hold on;plot(rGLC,nut(:,x_sel_ind(i)),'ro');
%         xlabel('x/d');ylabel('r/d');title('\nu_t DD-RANS')
%         grid on;box on;

%         saveas(gcf,[FileOut,'_10_RANSLESplot_T',num2str(k),'_',num2str(i),'.fig'],'fig')
%         saveas(gcf,[FileOut,'_10_RANSLESplot_T',num2str(k),'_',num2str(i),'.tiff'],'tiff')
%         pause
%         close all
    end
end
% xlim([-1 1])
%   legend('1d Exp','3d Exp','5d Exp','1d RANS','3d RANS','5d RANS')


%% Report plots
 %Ux_LES_mean=zeros(Nx,1);
% Ux_RANS_mean=zeros(Nx,1);
% for i=1:Nx
%      %Ux_LES_mean(i)=2/(rGLC(R_ind)^2)*trapz(flipud(rGLC(R_ind:end)),flipud(rGLC(R_ind:end).*Ux_LES_int(R_ind:end,i)));
%     Ux_RANS_mean(i)=2/(rGLC(R_ind)^2)*trapz(flipud(rGLC(R_ind:end)),flipud(rGLC(R_ind:end).*Ux_farm(R_ind:end,i)));
% end
% figure;plot(x_farm,Ux_LES_mean,'r')
% hold on;plot(x_farm,Ux_RANS_mean);
% grid on;box on;axis tight;
% for i=1:N_turbines
%     hold on;plot([x_turbines(i) x_turbines(i)],[min(Ux_LES_mean) max(Ux_LES_mean)],'r-.')
% end
% grid on;box on;axis tight;ylim([0 1.2])
% xlabel('x/d');ylabel('Ux mean');legend('LES','RANS','Location','Best')
% saveas(gcf,[FileOut,'_11_Uxmean.fig'],'fig')
% saveas(gcf,[FileOut,'_11_Uxmean.tiff'],'tiff')
% close all
% 
% Vel_LES_mean=zeros(Nx,1);
% Vel_RANS_mean=zeros(Nx,1);
% for i=1:Nx
%     Vel_LES_mean(i)=2/(rGLC(R_ind)^2)*trapz(flipud(rGLC(R_ind:end)),...
%         flipud(rGLC(R_ind:end).*sqrt(Ux_LES_int(R_ind:end,i).^2+Ut_LES_int(R_ind:end,i).^2+Ur_LES_int(R_ind:end,i).^2)));
%     Vel_RANS_mean(i)=2/(rGLC(R_ind)^2)*trapz(flipud(rGLC(R_ind:end)),...
%         flipud(rGLC(R_ind:end).*sqrt(Ux_farm(R_ind:end,i).^2+Ut_farm(R_ind:end,i).^2+Ur_farm(R_ind:end,i).^2)));
% end
% figure;plot(x_farm,Vel_LES_mean,'r')
% hold on;plot(x_farm,Vel_RANS_mean);
% grid on;box on;axis tight;
% for i=1:N_turbines
%     hold on;plot([x_turbines(i) x_turbines(i)],[min(Vel_LES_mean) max(Vel_LES_mean)],'r-.')
% end
% grid on;box on;axis tight;ylim([0 1.2])
% xlabel('x/d');ylabel('Vel mag mean');legend('LES','RANS','Location','Best')
% saveas(gcf,[FileOut,'_12_Velmean.fig'],'fig')
% saveas(gcf,[FileOut,'_12_Velmean.tiff'],'tiff')
% close all
% 
% figure;
% plot(rGLC,alfa)
% xlim([0 .5])
% grid on;box on;axis tight;xlim([0 1]);legend show
% xlabel('r/d');ylabel('\alpha [deg]');
% saveas(gcf,[FileOut,'_13_alpha.fig'],'fig')
% saveas(gcf,[FileOut,'_13_alpha.tiff'],'tiff')
% %close all
% 
% Eff=zeros(Nr,N_turbines);
% for k=1:N_turbines
%     Eff(:,k)=CL(:,k)./CD(:,k);
% end
% figure;
% subplot(3,1,1);plot(rGLC,CThrust);axis tight;xlim([0 .6])
% grid on;box on;
% xlabel('r/d');ylabel('C_{thrust}');
% subplot(3,1,2);plot(rGLC,CTang);axis tight;xlim([0 .6])
% grid on;box on;
% xlabel('r/d');ylabel('C_{tang}');
% subplot(3,1,3);plot(rGLC,Eff);axis tight;xlim([0 .6])
% grid on;box on;legend show
% xlabel('r/d');ylabel('C_L/C_D');
% saveas(gcf,[FileOut,'_14_cf.fig'],'fig')
% saveas(gcf,[FileOut,'_14_cf.tiff'],'tiff')
% %close all
% 
% 
% figure;set(gcf,'Color','White');
% subplot(2,1,1);plot(rGLC,f_x);axis tight;xlim([0 0.6])
% grid on;box on;xlabel('r/d');ylabel('f_x');
% subplot(2,1,2);plot(rGLC,f_t);axis tight;xlim([0 .6])
% grid on;box on;xlabel('r/d');ylabel('f_t');
% saveas(gcf,[FileOut,'_15_f.fig'],'fig')
% saveas(gcf,[FileOut,'_15_f.tiff'],'tiff')
% %close all

%% Power calculation
% Create a psuedo grid mapping
r=flip(0:0.005:.52)';
% Psuedo blade characteristics
Aerodyn_P=BlindTest1(r); % r chord twist Airfoil_class
chord_P=Aerodyn_P(:,2);
twist_P=Aerodyn_P(:,3);
airfoil_P=Aerodyn_P(:,4);
% Finding indices for R
[~,R_ind_P(1)]=min(abs(r-.5));
% [~,R_ind_P(2)]=min(abs(r-.5));
for k=1:N_turbines
    if r(R_ind_P(k))<0.5
        R_ind_P(k)=R_ind_P(k)-1;
    end
    [~,temp]=min(abs(r-nac(k)));
    nac_ind_P(k)=temp;
    Vrel_P(:,k)=interp1(rGLC,Vrel(:,k),r);
    alfa_P(:,k)=interp1(rGLC,alfa(:,k),r);
    g(k)=0.87*exp(-0.378*TSR(k))+.12;
    if TSR(k)>6
        fxt=-0.02*TSR(k)+0.72;         
    else 
        fxt=0.0333*TSR(k)+0.4;
    end
    fxh=.01667*TSR(k)-.05;
    fth=fxh;
    ftt=-.04*TSR(k)+.77;
    AerodynForce_P=LiftDragBT1(r,alfa_P(:,k),airfoil_P);
    CL_P(:,k)=AerodynForce_P(:,3);
    CD_P(:,k)=AerodynForce_P(:,4);
    CThrust_P(:,k)=CD_P(:,k).*sind(alfa_P(:,k)+twist_P)+CL_P(:,k).*cosd(alfa_P(:,k)+twist_P);
    CTang_P(:,k)=-CD_P(:,k).*cosd(alfa_P(:,k)+twist_P)+CL_P(:,k).*sind(alfa_P(:,k)+twist_P);
    CTang_P(:,k)=((r>r(nac_ind_P(k))).*(CTang_P(:,k)));
    CTang_P(:,k)=(CTang_P(:,k)>0).*CTang_P(:,k);
    CThrust_P(:,k)=((r>r(nac_ind_P(k))).*CThrust_P(:,k));

    f_tip_x_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(fxt-r)./(2*r.*sind(alfa_P(:,k)+twist_P)))));
    f_hub_x_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(r-fxh)./(2*r.*sind(alfa_P(:,k)+twist_P)))));%.001
    f_x_P(:,k)=correct_x(k)*f_tip_x_P(:,k).*f_hub_x_P(:,k);
    f_tip_t_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(ftt-r)./(2*r.*sind(alfa_P(:,k)+twist_P)))));
    f_hub_t_P(:,k)=real(2/pi*acos(exp(-g(k)*3*(r-fth)./(2*r.*sind(alfa_P(:,k)+twist_P)))));
    f_t_P(:,k)=correct_t(k)*f_tip_t_P(:,k).*f_hub_t_P(:,k);
    F_Thrust_P(:,k)=((2*pi*r).^-1).*.5.*Vrel_P(:,k).^2.*chord_P.*f_x_P(:,k).*3.*CThrust_P(:,k);F_Thrust_P(end,k)=F_Thrust_P(end-1,k);
    F_Tang_P(:,k)=((2*pi*r).^-1).*.5.*Vrel_P(:,k).^2.*chord_P.*f_t_P(:,k).*3.*(CTang_P(:,k));F_Tang_P(end,k)=0;
    F_nacelle_P(:,k)=.5.*Vrel_P(:,k).^2.*2*0.5;F_nacelle_P(end,k)=F_nacelle_P(end-1,k);%0.65 instead of nac*15
    F_nacelle_P(:,k)=(r<nac(k)).*F_nacelle_P(:,k);
    if F_nacelle_P(nac_ind_P(k))==0
        nac_ind_P(k)=nac_ind_P(k)+1;
    end
    F_nacelle_g_P(:,k)=.6*(F_nacelle_P(end,k)).*exp(-((r-0.0)/(0.14)).^2);% (-1.7*nac+0.2105)
    F_nacelle_g_P(:,k)=(r<(.18)).*F_nacelle_g_P(:,k); %.23  
end
    Nr_P=length(r);
    Power_P=zeros(Nr_P,N_turbines);
    Power_total_P=zeros(N_turbines,1);
    F_Thrust_total_P=zeros(N_turbines,1);
    for k=1:N_turbines
        Power_P(:,k)=Omega(k)*r.*F_Tang_P(:,k);
        Power_total_P(k)=2*pi*trapz(flipud(r(R_ind_P(k):end)),...
            flipud(r(R_ind_P(k):end).*Power_P(R_ind_P(k):end,k)));
        F_Thrust_total_P(k)=2*pi*trapz(flipud(r(R_ind_P(k):end)),...
            flipud(r(R_ind_P(k):end).*(F_Thrust_P(R_ind_P(k):end,k)+F_nacelle_g_P(R_ind_P(k):end,k))));

%         [~,wake_ind]=min(U_infty(1)-Ux_farm(:,x_turb_ind(k)+Eps_ind));wake_ind=wake_ind-1;
%         Ct_vel(k)=(8/.5.^2)*trapz(flipud(rGLC(wake_ind:end)),...
%         flipud(rGLC(wake_ind:end).*Ux_farm(wake_ind:end,x_turb_ind(k)+Epsilon/deltax/10).*...
%         (U_infty(k)-Ux_farm(wake_ind:end,x_turb_ind(k)+Epsilon/deltax/10))/U_infty(k)^2));
    end

    
Power=zeros(Nr,N_turbines);
Power_total=zeros(N_turbines,1);
F_Thrust_total=zeros(N_turbines,1);

for k=1:N_turbines
    Power(:,k)=Omega(k)*rGLC.*F_Tang(:,k);
    Power_total(k)=2*pi*trapz(flipud(rGLC(R_ind:end)),...
        flipud(rGLC(R_ind:end).*Power(R_ind:end,k)));
    Power_cum(:,k)=2*pi*cumtrapz(flipud(rGLC(R_ind:end)),...
        flipud(rGLC(R_ind:end).*(Power(R_ind:end,k))));
    F_Thrust_total(k)=2*pi*trapz(flipud(rGLC(R_ind:end)),...
        flipud(rGLC(R_ind:end).*(F_Thrust(R_ind:end,k)+0.5*F_nacelle(R_ind:end,k))));
    [~,wake_ind]=min(U_infty(k)-Ux_farm(:,x_turb_ind(k)+Eps_ind));wake_ind=wake_ind-1;
%     Ct_vel(k)=(8/.5.^2)*trapz(flipud(rGLC(wake_ind:end)),...
%     flipud(rGLC(wake_ind:end).*Ux_farm(wake_ind:end,x_turb_ind(k)+Epsilon/deltax/10).*...
%     (U_infty(1)-Ux_farm(wake_ind:end,x_turb_ind(k)+Epsilon/deltax/10))/U_infty(1)^2));
end
% 
% figure;set(gcf,'Color','White');
% subplot(4,1,1);plot(rGLC,F_Thrust);axis tight;xlim([0 .6])
% grid on;box on;xlabel('r/d');ylabel('F_{thrust}/m');
% hold on;plot(r,F_Thrust_P,'--');
% subplot(4,1,2);plot(rGLC,F_Tang);axis tight;xlim([0 .6])
% grid on;box on;xlabel('r/d');ylabel('F_{tang}/m');
% hold on; plot(r,F_Tang_P,'--');
% subplot(4,1,3);plot(rGLC,F_nacelle_g);axis tight;xlim([0 .6])
% grid on;box on;xlabel('r/d');ylabel('F_{nacelle}/m');
% hold on;plot(r,F_nacelle_g_P,'--')
% subplot(4,1,4);plot(rGLC,Power);axis tight;xlim([0 .6])
% grid on;box on;xlabel('r/d');ylabel('Power/m');
% hold on;plot(r,Power_P,'--');
% saveas(gcf,[FileOut,'_16_Force.fig'],'fig')
% saveas(gcf,[FileOut,'_16_Force.tiff'],'tiff')
% %close all
% 
% figure; set(gcf,'Color','White');
% subplot(3,2,1);plot(U_infty,'o');axis tight;ylabel('U_\infty');grid on;box on;
% subplot(3,2,2);plot(Omega,'o');axis tight;ylabel('\Omega [rad/s]');grid on;box on;
% subplot(3,2,3);plot(g,'o');axis tight;ylabel('g');grid on;box on;
% subplot(3,2,4);plot(1.225*Power_total,'o');axis tight;ylabel('Power [W]');grid on;box on;
% subplot(3,2,5);plot(1.225*F_Thrust_total,'o');axis tight;ylabel('Thrust [N]');grid on;box on;
% subplot(3,2,6);plot(((.5*U_infty.^3*pi*.5^2).^(-1)).*Power_total,'o');
% hold on;plot(((.5*U_infty.^2*pi*rGLC(R_ind)^2).^(-1)).*F_Thrust_total,'rs')
% legend('C_P','C_T','Location','Best')
% axis tight;grid on;box on;
% saveas(gcf,[FileOut,'_17_Report.fig'],'fig')
% saveas(gcf,[FileOut,'_17_Report.tiff'],'tiff')
% %close all
Cp=((.5*U_infty(1).^3*pi*(rGLC(R_ind)).^2).^(-1)).*Power_total
Ct=((.5*U_infty(1).^2*pi.*(rGLC(R_ind)).^2).^(-1)).*F_Thrust_total
Cp_farm=sum(Cp)

Cp_recal=((.5*U_infty(1).^3*pi*(r(R_ind_P)).^2).^(-1)).*Power_total_P
Ct_recal=((.5*U_infty(1).^2*pi.*(r(R_ind_P)).^2).^(-1)).*F_Thrust_total_P
Cp_farm_recal=sum(Cp_recal)
cp_recal_out(ij)=Cp_recal;
ct_recal_out(ij)=Ct_recal;
cp_out(ij)=Cp;
ct_out(ij)=Ct;
end
% 
% figure;plot(tsr,cp_out);
% figure;plot(tsr,ct_out);
% figure;plot(tsr,ct_vel);

