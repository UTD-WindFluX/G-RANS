%function [] = turbineplot_xz(xxs,xxl,yys,yyl,yyc,Zhub)

xxs=2;
xxl=10;
yys=1;
yyl=20;
yyc=-0;
Zhub=10;
wtR = 20;
xs=xxs;
ys=yys/(2*wtR);
yc=yyc/(2*wtR);
xl=0.01*xxl;
yl=yyl/(2*wtR);
m=40; n=m/2;

yt1 = ys:yl/(n-1):ys+yl;
yt2 = ys+yl:-0.9*yl/(n-1):ys+0.1*yl;
yt = [yt1 yt2];
xt(1:n) = xs+0.2*xl*(1-cos((yt(1:n)-ys)./yl*(pi/2)));
xt(n+1:2*n) = xs+0.4*xl+0.4*xl*(1-cos((yt(n+1:2*n)-ys-yl)/yl*(pi/2)));
xt(m+1)=xt(1)+0.25*xl;
yt(m+1)=yt(1)+0.05*yl;
xt(m+2)=xt(1)+0.25*xl;
yt(m+2)=yt(1);
ytc=[2*yc-ys:2*(ys-yc)/(10*n):ys];
xtc=xs-0.5*xl+1.0*xl*abs(ytc-yc).^3/max(abs(ytc-yc).^3);

xtm(1)=xs+0.5*xl;
ytm(1)=yc+(ys-yc);
xtm(2)=xs+0.5*xl+2.5*xl;
ytm(2)=yc+(ys-yc);
xtm(3)=xs+0.5*xl+2.3*xl;
ytm(3)=yc+(ys-yc)*0.1;


xtm(4)=xs+0.5*xl+2.0*xl;
ytm(4)=yc-(ys-yc);
xtm(5)=xs+0.5*xl;
ytm(5)=yc-(ys-yc);;

xtb(1)=xs+1.2*xl;
ytb(1)=yc-(ys-yc)-Zhub;
xtb(2)=xs+1.2*xl+0.7*xl;
ytb(2)=yc-(ys-yc)-Zhub;
xtb(3)=xs+1.2*xl+0.55*xl;
ytb(3)=yc-(ys-yc);
xtb(4)=xs+1.2*xl+0.15*xl;
ytb(4)=yc-(ys-yc);

Delta=.3*(xtm(5)-xtm(4));
xstem=[xtm(4)+Delta xtm(5)-Delta xtm(5)-Delta xtm(4)+Delta xtm(4)+Delta];
ystem=[ytm(4:5) -1 -1 ytm(4)];
hold on;
h=patch(xt,yt,'c'); set(h,'FaceColor',[0.8,0.8,0.8]);
%h=patch(xt,2*yc-yt,'c'); set(h,'FaceColor',[0.8,0.8,0.8]);
 h=patch(xtc,ytc,'g'); set(h,'FaceColor',[0.8,0.8,0.8]);
 h=patch(xtm,ytm,'g'); set(h,'FaceColor',[0.8,0.8,0.8]);
% h=patch(xtb,ytb,'g'); set(h,'FaceColor',[0.8,0.8,0.8]);
% h=patch(xstem,ystem,'g'); set(h,'FaceColor',[0.8,0.8,0.8]);
% axis equal