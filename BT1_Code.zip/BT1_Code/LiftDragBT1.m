function [output]= LiftDragBT1(r,AoA,Nfoil)
CL=zeros(length(r),1);
CD=zeros(length(r),1);
Filenames={'clcdalpha.txt'};

for i=1:length(r)
    if r(i)<=0.5
       AoA_CL_CD=importdata(Filenames{Nfoil(i)}); 
       AoA_CL_CD=AoA_CL_CD.data;
       [~,b]=min(abs(AoA(i)-AoA_CL_CD(:,1)));
       CL(i)=AoA_CL_CD(b,2);
       CD(i)=AoA_CL_CD(b,3);
    end
end
output=[r, AoA, CL,CD];
